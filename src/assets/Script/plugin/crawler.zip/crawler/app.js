/**
 * https://b-l-u-e-b-e-r-r-y.github.io/post/PTTCrawler/
 */
const request = require("request");
const cheerio = require("cheerio");
// const { resolve } = require("path/posix");

const CRYPTO_KEY_WORD = ['nft', '比特幣', '乙太', 'dao', '去中心化', 'usd'];

let pttTemp = {};
const pttCrawler = () => {
    request({
        url: "https://www.ptt.cc/bbs/Stock/index.html",
        method: "GET"
    }, (error, res, body) => {
        // 如果有錯誤訊息，或沒有 body(內容)，就 return
        if (error || !body) {
            return;
        }

        const data = [];
        const $ = cheerio.load(body); // 載入 body
        const list = $(".r-list-container .r-ent");
        for (let i = 0; i < list.length; i++) {
            const title = list.eq(i).find('.title a').text();
            // const author = list.eq(i).find('.meta .author').text();
            // const date = list.eq(i).find('.meta .date').text();
            const link = list.eq(i).find('.title a').attr('href');

            if (CRYPTO_KEY_WORD.some((w) => title.toLocaleLowerCase().indexOf(w) > -1)) {
                data.push({ title, link });
            }
            // data.push({ title, author, date, link });
        }

        data.forEach((d) => {
            let { tile, link } = d;
            // 重複的不要再貼
            if (!pttTemp[link]) {
                console.log(d);
                // 暫存起來
                pttTemp[link] = { title: tile, link: link };
            }
        });
        // console.log(data);
    });
};

// pttCrawler();

let blockBeatsUrl = 'https://www.theblockbeats.info/newsflash';
let blockBeatsTemp = {};
const blockBeatsCrawler = () => {
    request({
        url: blockBeatsUrl,
        method: "GET"
    }, (error, res, body) => {
        // 如果有錯誤訊息，或沒有 body(內容)，就 return
        if (error || !body) {
            return;
        }

        const data = [];
        const $ = cheerio.load(body); // 載入 body
        const list = $(".newsflash-module .contain .contain-lft .flash-list");
        for (let i = 0; i < list.length; i++) {
            const title = list.eq(i).find('.flash-item a').attr('title');
            const link = list.eq(i).find('.flash-item a').attr('href');

            if (CRYPTO_KEY_WORD.some((w) => title.toLocaleLowerCase().indexOf(w) > -1)) {
                data.push({ title, link });
            }
        }
        data.forEach((d) => {
            let { tile, link } = d;
            // 重複的不要再貼
            if (!blockBeatsTemp[link]) {
                console.log(d);
                // 暫存起來
                blockBeatsTemp[link] = { title: tile, link: `${blockBeatsUrl}${link}` };
            }
        });
        // console.log(data);
    });
};
blockBeatsCrawler();

function executeCrawler(methods) {
    return new Promise((resolve) => {
        methods.forEach((method) => method());
        resolve();
    })
        .then(() => setTimeout(() => executeCrawler(methods), 30000));
}

executeCrawler([pttCrawler, blockBeatsCrawler]);