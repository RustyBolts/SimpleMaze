const { initializeApp } = require('firebase/app'),
    { getAuth, signInWithEmailAndPassword } = require('firebase/auth'),
    { getDatabase, ref, child, onValue, get, set, update, push } = require('firebase/database');

const app = initializeApp({
    apiKey: "AIzaSyAc5PRwmE14gBH5az8TSoqs9aBrQ8YWa4o",
    authDomain: "fir-test-756e1.firebaseapp.com",
    databaseURL: "https://fir-test-756e1.firebaseio.com",
    projectId: "fir-test-756e1",
    storageBucket: "fir-test-756e1.appspot.com",
    messagingSenderId: "182531440628"
});
const PROJECT = 'YellowCard';
let database;
const signIn = function (email, password) {
    return signInWithEmailAndPassword(getAuth(), email, password)
        .then((userCredential) => {
            // console.log('userCredential:', userCredential);
            database = getDatabase(app);
            // let guid = getAuth().currentUser.uid;//TODO: 這邊不用寫，是client 要暫存才有用
            // console.log('uid:' ,uid);// 會拿到用google 帳號登入的unquineid "ZjNqTz0f28bVa2olOyrS3uiOj2j2" ，這邊當 guid 使用
            return userCredential.user.uid;
        })
        .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            // client todo 做regist()
            return errorMessage;
        });
};

const upload = (refPath, data) => set(ref(database, refPath), data);
const listen = (refPath, callback) => onValue(ref(database, refPath), (snapshot) => {
    const data = snapshot.val();
    data && callback && callback(data);
});
const read = function (refPath, idOrFoldName = '') {
    return new Promise((resolve) => {
        // console.log('refPath:', refPath, idOrFoldName);
        (idOrFoldName
            ? get(child(ref(database, refPath), idOrFoldName))
            : get(ref(database, refPath))
        ).then((snapshot) => {
            const data = snapshot.val();
            // data && resolve(data);
            resolve(data);
            console.log(idOrFoldName, '::::', data);
        });
    });
};
const addNew = (refPath, id, data = -1) => {
    if (!id) id = push(ref(database, refPath)).key;
    upload(`${refPath}${id}/`, data);
    return id;
};

const dbUsers = {
    getIds: (guid) => read(`${PROJECT}/U/`, guid),
    regist: (guid, id, buildTimestamp) => addNew(`${PROJECT}/U/${guid}/`, id, buildTimestamp),
    verify: (guid, id) => dbUsers.getIds(guid).then((data) => data[id] && data[id] > -1),
};
const dbConnect = {
    // login (client)
    login: (guid_id) => read(`${PROJECT}/C/${guid_id}/status/`),
    // 使用者線上狀態
    status: (guid_id, value) => upload(`${PROJECT}/C/${guid_id}/status/`, value),
    // 監聽請求 (applicate)
    listen: (callback) => listen(`${PROJECT}/C/`, callback),
    // client 發事件給 server (這邊主要測試c->s)
    applicate: (guid_id, key, value) => upload(`${PROJECT}/C/${guid_id}/input/`, value ? `${key} ${value}` : key),
    // applicate: (guid_id, key, value) => upload(`${PROJECT}/C/${guid_id}/command/`, 'input ' + value ? `${key} ${value}` : key),
    // server 發事件給 client
    broadcast: (guid_id, key, value) => upload(`${PROJECT}/C/${guid_id}/output/`, value ? `${key} ${value}` : key),
    // broadcast: (guid_id, key, value) => upload(`${PROJECT}/C/${guid_id}/command/`, 'output ' + value ? `${key} ${value}` : key),
    // 在 bridge 裡監聽連線動作，再發給有註冊的類別 (honst 監聽 input, client 對應 output 的)
    h_connection: (guid_id, callback) => listen(`${PROJECT}/C/${guid_id}/input/`, callback),
    c_connection: (guid_id, callback) => listen(`${PROJECT}/C/${guid_id}/output/`, callback),
    connection: (guid_id, callback) => listen(`${PROJECT}/C/${guid_id}/command/`, callback),
    // 斷線
    disconnect: (guid_id) => upload(`${PROJECT}/C/${guid_id}/`, null),
};
const dbRecord = {
    roomList: () => read(`${PROJECT}/D/ROOMS/`),
    newRoom: (rNum, dKey) => upload(`${PROJECT}/D/ROOMS/${rNum}/`, dKey),
    upload: (idOrFoldName, filename, data) => upload(`${PROJECT}/D/${idOrFoldName}/${filename}`, data),
    download: (guidOrFoldName, idOrFoldName) => read(`${PROJECT}/D/${guidOrFoldName}/`, idOrFoldName),
};
const test = {
    r: (n) => read('YellowCard/Question/', n),
    // r: () => read('YellowCard/'),
    // r: () => dbRecord.download('SKEY', 'ZjNqTz0f28bVa2olOyrS3uiOj2j2_-Mm1IoieueJXkbIwB4-6'),
    // r: () => read(`${PROJECT}/D/SKEY/`),
    w: (n, d) => upload('YellowCard/D/Question/' + n, d)
    // w: (n, d) => upload('YellowCard/Answer/'+n, d)
}
module.exports = {
    signIn,
    dbUsers,
    dbConnect,
    dbRecord,
    // test
};