const webhookURL = 'https://discord.com/api/webhooks/1076004498750840893/67FSzHmJdr9TYw_6N26N3UWFqb2q4Zl3GmJ9IxkM6wo9wOmeze2ByHShqkOTqncPC7JN'; // 請換成你自己的 webhook URL

class DiscordWebhook {
    constructor() {

    }

    sendDiscordMessage(content) {
        return require('axios').post(webhookURL, {
            content: content,
        })
            .then(() => {
                console.log('Message sent to Discord');
            })
            .catch(() => {
                console.error('Error sending message to Discord:', error.message);
            });
    }

}

module.exports = DiscordWebhook;