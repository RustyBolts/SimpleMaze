const { dbConnect } = require('./firebase.js');

/**
 * 連線工具
 */
var notifyKeymaps = {};
const connectListener = function (guid_id, isHonst) {
    console.log(isHonst ? 'honst' : 'client', 'connect to:', guid_id);
    const callback = (data) => onReceive(isHonst, guid_id, data);
    isHonst
        ? dbConnect.h_connection(guid_id, callback)
        : dbConnect.c_connection(guid_id, callback);
    // dbConnect.connection(guid_id, (data) => onReceive(isHonst, guid_id, data));
};

const onReceive = function (isHonst, guid_id, data) {
    let key = data, value = '';
    let spaceIndex = data.indexOf(' ');
    if (spaceIndex > 0) {
        //切第一個空格
        key = data.slice(0, spaceIndex);
        value = data.slice(spaceIndex + 1);
    }
    notifyKeymaps[guid_id].forEach((notifyKeymap) => notifyKeymap.onReceive(isHonst, guid_id, key, value));
    console.log(isHonst ? 'honst' : 'client', 'key:', key, 'value:', value);
};

const addDispatcher = function (guid_id, context, keymap) {
    // let notifyKeymap = new NotifyKeyMap(context, keymap);
    // (notifyKeymaps[guid_id] = notifyKeymaps[guid_id] || []).push(notifyKeymap);

    // console.log(Object.keys(keymap));
    if (notifyKeymaps[guid_id]) {
        !notifyKeymaps[guid_id].find((notifyKeymap, index, ary) => {
            if (notifyKeymap.context === context) {
                Object.keys(keymap).forEach((key) => notifyKeymap.callbackMap[key] = keymap[key]);
                return true;
            }
        }) && notifyKeymaps[guid_id].push(new NotifyKeyMap(context, keymap));// 找不到就要補一個
    } else {
        const notifyKeymap = new NotifyKeyMap(context, keymap);
        (notifyKeymaps[guid_id] = notifyKeymaps[guid_id] || []).push(notifyKeymap);
    }
    // console.log(Object.keys(notifyKeymaps).length, 'notifyKeymaps[', guid_id, ']:', notifyKeymaps[guid_id]);
};

const removeDispatcher = function (guid_id, context) {
    notifyKeymaps[guid_id].find((notifyKeymap, i) => {
        if (notifyKeymap.context == context) {
            notifyKeymaps[guid_id].splice(i, 1);
            return true;
        }
    });
};

function NotifyKeyMap(context, keymap) {
    this.context = context;
    this.callbackMap = keymap;
    this.onReceive = function (isHonst, guid_id, key, value) {
        if (isHonst != this.context.isHonst) return;//todo 這個寫法感覺不是很對

        const callback = keymap[key];
        callback && callback.call(context, isHonst, guid_id, key, value);
        // console.log(guid_id, ':', key, value);
    };
};

/**
 * 處理資料加密
 */
const crypto = require('crypto');

/**
 * 加密
 * @param {string} data 需要加密的內容
 * @param {string} key 密鑰
 * @param {string} iv 初始化向量
 * @returns {string}
 */
const aesEncrypt = function (data, key, iv) {
    // 給定的算法，密鑰和初始化向量（iv）創建並返回Cipher對象
    const cipher = crypto.createCipheriv('aes-192-cbc', key, iv);
    // Key length is dependent on the algorithm. In this case for aes192, it is 24 bytes (192 bits).
    // 指定要摘要的原始內容,可以在摘要被輸出之前使用多次update方法來添加摘要內容
    // 數據的編碼 utf8 返回值的編碼 hex
    let crypted = cipher.update(data, 'utf8', 'hex');
    crypted += cipher.final('hex');
    return crypted;
};

/**
 * 解密
 * @param {string} data 需要解密的內容
 * @param {string} key 密鑰
 * @param {string} iv 初始化向量
 * @returns {string}
 */
const aesDecrypt = function (data, key, iv) {
    // 給定的算法，密鑰和初始化向量（iv）創建並返回Cipher對象
    const decipher = crypto.createDecipheriv('aes-192-cbc', key, iv)
    // 數據的編碼 hex 返回值的編碼 utf8
    let decrypted = decipher.update(data, 'hex', 'utf8')
    decrypted += decipher.final('utf8');
    return decrypted
};

module.exports = {
    connectListener,
    addDispatcher,
    removeDispatcher,
    aesEncrypt,
    aesDecrypt,
};