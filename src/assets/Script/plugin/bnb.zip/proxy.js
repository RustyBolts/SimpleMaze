const { account, servertime } = require("./data/binance/api");
const { update, getTradeRules, getPrecisionVariation, getPrecisionPrice } = require("./data/binance/exchangeInfo");
const QuarterLevelStock = require("./trade/QuarterLevelStock");
const QuarterLevelTrader = require("./trade/QuarterLevelTrader");
const TicketOrder = require("./trade/TicketOrder");
// const { getOscillationRiseMax, oscillation, findTopList, riseRateFilter } = require("./data/binance/historicalAnalysis");
// const { kline, KLINE } = require("./data/binance/market");
// const { Interval } = require("./data/binance/request");
// const DashOscillationTrader = require("./trade/DashOscillationTrader");
// const LeapingOver = require("./trade/LeapingOver");
// const MarketTrader2 = require("./trade/MarketTrader");
// const MarketWatcher = require("./trade/MarketWatcher");
// const StockManager = require("./trade/StockManager");
// const { logcat } = require("./trade/dex/GoogleSpreadsheetRecord");

// // new TradeProxy().entrust();
// const testId = '123';
// update(testId)
//   .then(() => {
//     // var mw = new MarketWatcher(testId, 'ARBUSDT');
//     // mw.updateKlinesData();
//     // mw.updateOscillation()
//     //     .then(x => console.log(x));
//     // mw.updateCurrPrice();


//     // var symbols = ['ARBUSDT', 'BNBUSDT', 'ETHUSDT', 'BTCUSDT'];
//     // var list = symbols.map((symbol) => new MarketWatcher(testId, symbol));
//     // var resultList = {};
//     // const toFixedFloat = (symbol, v) => getPrecisionVariation(symbol, v);
//     // const loop = (times) => Promise.all(
//     //   list.map(x => x.updateOscillationByInterval(Interval.MINUTES_15))
//     // ).then((result) => {
//     //   times--;
//     //   console.log(times);
//     //   symbols.forEach((symbol, i) => {
//     //     if (!resultList[symbol]) resultList[symbol] = [];
//     //     var { rise, variationTrend, v, price } = result[i];
//     //     resultList[symbol].push([
//     //       rise,
//     //       variationTrend,
//     //       v,
//     //       price[1],
//     //       `+${toFixedFloat(symbol, price[0] - price[1])} -${toFixedFloat(symbol, price[1] - price[2])}`,
//     //     ]);
//     //   });
//     //   if (times > 0)
//     //     setTimeout(() => loop(times), 2 * 60 * 1000);
//     //   else {
//     //     const toRatio = (v) => `${parseFloat((v * 100).toFixed(3))}%`;
//     //     Object.keys(resultList).forEach((symbol) => console.log(`${symbol} price: ${resultList[symbol].map(x => x[3]).join(" | ")}`));
//     //     Object.keys(resultList).forEach((symbol) => console.log(`${symbol} range: ${resultList[symbol].map(x => x[4]).join(" | ")}`));
//     //     Object.keys(resultList).forEach((symbol) => console.log(`${symbol} rise : ${resultList[symbol].map(x => toRatio(x[0])).join(" | ")}`));
//     //     Object.keys(resultList).forEach((symbol) => console.log(`${symbol} trend: ${resultList[symbol].map(x => toRatio(x[2])).join(" | ")}`));
//     //   }
//     // });
//     // loop(1);


//     var symbol = 'BTCUSDT';
//     var funds = 10000;
//     new DashOscillationTrader(testId, symbol, funds).oscillationTrade(funds * 0.003);


//     // let price = 29207;
//     // this._marketTrader = new MarketTrader2('123', symbol, 1000);
//     // this._stockManager = new StockManager(symbol);
//     // this._stockManager.setQuarterLevelStock([29812, 29344, 29213, 29190], 1000 / 29279);

//     // let filling = this._stockManager.trade(price, 5);
//     // console.log('filling:', filling);
//     // var date = new Date();
//     // var creation = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
//     // logcat(symbol, creation, price, this._stockManager.getStock(price), this._marketTrader.getFunds(price), this._marketTrader.getAssets())
//     //   .then((x) => console.log('紀錄至google spread sheet'));

//     // // if (filling > 0)
//     // // this._marketTrader.buyIn(price, filling)
//     // //   .then(() => this._marketTrader.result(price))
//     // //   .then((ticketResult) => {
//     // //     console.log(ticketResult);

//     // //     ticketResult && this._stockManager.result(ticketResult, price);
//     // //     // console.log(this._marketTrader.getFunds(29401));

//     // //     // console.log('funds:', this._marketTrader.getFunds(price));
//     // //     // return this._marketTrader.result (price);
//     // //   });
//     // //     .then((ticketResult) => {
//     // //       console.log('ticketResult:', ticketResult);
//     // //       if (Math.abs(ticketResult.filling)!=ticketResult.filled){
//     // //         setTimeout(()=>{
//     // //           this._marketTrader.result(price)
//     // //             .then((ticketResult) => {
//     // //                 ticketResult && this._stockManager.result(ticketResult, price);
//     // //             }, 2*60*1000);
//     // //           });
//     // //       }
//     // //       else {
//     // //         var filling = this._stockManager.clean();
//     // //         console.log('filling:', filling);
//     // //         this._marketTrader.sellOut(price+5, -filling)
//     // //           .then((ticketResult) => {
//     // //             console.log('sellOut:', ticketResult);
//     // //               setTimeout(()=>{
//     // //                 this._marketTrader.result(price)
//     // //                   .then((ticketResult) => {
//     // //                       ticketResult && this._stockManager.result(ticketResult, price);
//     // //                   }, 2*60*1000);
//     // //                 });
//     // //            });
//     // //       }
//     // //     });

//     // new LeapingOver(testId).addObserve(symbol);
//   });

// 
const ownerId = 'xxfox0001';
const baseSymbol = 'MEME';
const quoteSymbol = 'USDT';
const symbol = baseSymbol + quoteSymbol;
const lunausdtOrder = new TicketOrder(ownerId, symbol);
update(ownerId)
  .then(() => servertime(ownerId))
  .then(() => new QuarterLevelTrader(ownerId, baseSymbol, quoteSymbol, 1000));
// .then(() => lunausdtOrder.update())
// .then((x) => console.log(x));
//   .then(() => account(ownerId, 5000))
//   .then(x => console.log(x));

// const ownerId = '123';
// const symbol = 'ARBUSDT';
// const arbusdtOrder = new TicketOrder(ownerId, symbol);
// update(ownerId)
//   .then(() => servertime(ownerId))
//   .then(() => {
//     new QuarterLevelStock(symbol);
//   });
