// const kline表徵= Enum({
// 短線波動//雜亂沒有表態，但有交易量且上下振盪，適用網格
// 底部整理//長時間盤踞在ema均線，交易量少。可進場等待大戶
// 空頭恐慌//明顯無支撐，大盤呈現下跌情勢
// 多頭樂觀//支撐位不斷向上攀升
// });
const { getPrecisionPrice, getPrecisionQuanity } = require('../data/binance/exchangeInfo');
const { Interval } = require('../data/binance/request');
const MarketWatcher = require('./MarketWatcher');
const MarketTrader = require('./MarketTrader');
const historicalAnalysis = require('../data/binance/historicalAnalysis');
const gridNum = 3;
class GridesTrader {
    constructor(ownerId, symbol, quoteAsset) {
        this.ownerId = ownerId;
        this.symbol = symbol;
        this._marketWatcher = new MarketWatcher(ownerId, symbol);
        this._marketTrader = new MarketTrader(ownerId, symbol, quoteAsset, this._marketWatcher);
        this._stocks = new Array(gridNum)
            .fill()
            .map((x) => ({
                price: { base: 0, avg: 0 },
                filled: 0,
                filling: 0,
                storage: 0
            }));
        this._resetStocks()
            .then(() => this._trade(Interval.MINUTES_15));
    }
    // 重設倉位: 
    _resetStocks() {
        const aaa = ([top, hub, bottom]) => {
            const toQty = (val) => getPrecisionQuanity(this.symbol, val);
            const toPrice = (val) => getPrecisionPrice(this.symbol, val);
            const field = top - bottom;
            const spacing = field / gridNum;
            const hubPrice = field / 2 + bottom;//hub 是kline 的平均中線價，計算不同所以另算 todo 評估是否需要多計算這個，是去頭尾的算法可能不是那麼需要
            const totalQuantity = this._marketTrader.getFunds() / hubPrice;// 用中間價大致抓一下能買幾顆，作為切分倉儲大小的依據
            const hubStorage = totalQuantity / gridNum;
            const storagePadding = hubStorage / gridNum;
            const midNum = Math.floor(gridNum / 2);
            let tempStocks = this._stocks.slice();
            // 倉位陣列: 越後面 pice 越小，sotrage 越大
            this._stocks.forEach((stockData, index, ary) => {
                // console.log('stockData:', stockData);
                const basePrice = toPrice(hubPrice + spacing * (midNum - index));
                // 處理合併倉位: 找出比stock price.avg 中可以被併入 basePrice 這階的倉位價格
                let filled = 0, filling = 0;
                let quote = tempStocks.reduce((sum, stock) => {
                    const avg = stock.price.avg;
                    if (avg >= basePrice) {
                        sum += stock.filled * avg;
                        filled += stock.filled;
                        filling += stock.filling;
                        tempStocks.pop();
                    }
                    return sum;
                }, 0);
                console.log('quote:', quote);
                const avgPrice = getPrecisionPrice(
                    this.symbol,
                    filled > 0
                        ? quote / filled
                        : basePrice + spacing / 2//沒有能搬的話，預設就是倉位底價加一半的價位區間
                );
                ary[index] = {
                    price: { base: basePrice, avg: avgPrice },
                    filled: toQty(filled),//已填倉: 從大到小處理，所以price 高於當前stock price 就併入
                    filling: toQty(filling),
                    storage: toQty(storagePadding * (1 + index * 2)),
                };
            });

            // 處理完 倉位重新排序後，仍然有未處理的倉位時:
            console.log('tempStocks:', tempStocks.length);
            let filled = 0, filling = 0, quote = tempStocks.reduce((sum, stock) => {
                filled += stock.filled;
                filling += stock.filling;
                return sum + stock.filled * stock.price.avg;
            }, 0);
            // 比最低倉位更低，併入最低倉位之中
            let lowestStock = this._stocks[gridNum - 1];
            lowestStock.filled += filled;
            lowestStock.filling += filling;
            if (filled > 0)
                lowestStock.price.avg = toPrice(quote / filled);
            // 變換後，檢查level(0是超過最高點，1是賣點水位)是否打在2以下(代表跌到一定程度，當初的買價已經變成倉位賣點，可以考慮認賠)
            // todo 這邊認賠點我想做intervale 7的版本，
            //      目前在想怎麼處理賣掉後又買的情況(當avgPrice level<=2時認賠出售，
            //      但又因為價格是在倉位低點才會變動倉位大小，而在買點level==3或-1的情況，有可能低價賣出又略高一點買入)
            const excision = 4,
                spacingValue = field / excision;
            const avgQuarterLevels = new Array(excision).fill().map((nul, idx) => top - spacingValue * (idx + 1));// 平均等分
            // console.log('avgQuarterLevels:', avgQuarterLevels);
            this._stocks.forEach((stockData) => {
                const avgPrice = stockData.price.avg;
                const level = avgQuarterLevels.findIndex((x) => x < avgPrice);
                // 止損認賠: 把買點跌到變賣單準備點，直接認賠
                if (level > -1 && level <= 2) {
                    if (stockData.filled > 0) {
                        console.log(stockData.price.base, '倉位的均價', avgPrice, '在 level:', level, '更新倉位後倉位均價過高，可能持續下跌，要進行清倉');
                        // this._marketTrader.sellOut(filled, avgPrice, sellPrice);// 測完再解開
                    }
                    // 應該是不會有，跌下去應該就買到了，而且目前寫法不好查，要的話就直接全面撤單
                    if (stockData.filling > 0) {
                        console.log('更新倉位後倉位均價過高，可能持續下跌，取消購入訂單');
                    }
                }
            });
            console.log('stocks:', this._stocks);
            // trade 的部份，用filter 出來跑抓出來並選擇交易週期，低於bottom 時再跑一次 kline 的symbol 搜索，找出交易振盪強的，如果沒找到就用 filter 再跑一次，找不到就休息2小時
            // 如果有變換symbol 的話，設flag 只能賣不能買 (所以跑 gridesTrader init 時要把flag 設成一般交易)
        };
        return this._marketWatcher
            .updateOscillationByInterval(Interval.DAYS_1)
            .then((oscillation) => {
                console.log(oscillation);
                // 用 Interval.DAYS_1 的場域做的倉位區間
                aaa(oscillation.price);
            });
    }
    _trade(interval) {
        historicalAnalysis
            .captureOscillation(this.ownerId, this.symbol, interval)
            .then((x) => {
                console.log(x);
                const currPrice = x.closing;
                const [top, hub, bottom] = x.price;//hub不適合做 hubPrice，這直接是最高/低的
                const hubPrice = (top - bottom) / 2 + bottom;
                console.log('短線價位波動:', top, hub, bottom);
                console.log('現價:', currPrice);
                const [highestRise, topRise, bottomRise, lowestRise] = x.riseQuarterLevel;
                // console.log('top price:', hub + hub * topRise);
                // console.log('bottom price:', hub + hub * bottomRise);
                const toAddHubPrice = (price) => getPrecisionPrice(this.symbol, hubPrice * (1 + price));
                // allowable 最基本的交易價格
                const allowableSellPrice = toAddHubPrice(topRise);
                const allowableBuyPrice = toAddHubPrice(bottomRise);
                // 找合適的倉位以進行交易
                if (allowableBuyPrice >= currPrice) {
                    // 買: 倉位還有置入空間，且現價在此倉位的區間
                    const buyInStock = this._stocks.find((x) => x.filled + x.filling < x.storage && x.price.base <= currPrice);
                    const buyAvgPrice = buyInStock ? buyInStock.price.avg : 0;
                    if (buyAvgPrice >= currPrice) {
                        const quantity = Math.max(x.storage / 5, x.filled);
                        // const expectedBuyPrice = getPrecisionPrice(symbol, hubPrice * (1+highestRise));
                        const expectedBuyPrice = toAddHubPrice(lowestRise);
                        this._marketTrader.buyIn(quantity, buyAvgPrice, expectedBuyPrice);
                        // 預期能買入的先佔位，避免無限填倉直到沒錢
                        buyInStock.filling += quantity;
                    }
                }
                else if (allowableSellPrice <= currPrice) {
                    // 賣: 倉位有庫存，且現價高於均價。有都拉出來處理
                    const sellOutStocks = this._stocks.filter((x) => x.filled > 0 && x.price.avg <= currPrice);
                    sellOutStocks.forEach(sellOutStock => {
                        const sellAvgPrice = sellOutStock.price.avg;
                        const sellPrice = Math.max(sellAvgPrice, allowableSellPrice);
                        if (sellPrice < currPrice) {
                            const quantity = sellOutStock.filled;
                            // const expectedSellPrice = getPrecisionPrice(symbol, hubPrice + hubPrice * lowestRise);
                            const expectedSellPrice = getPrecisionPrice(symbol, hubPrice + hubPrice * highestRise);
                            this._marketTrader.sellOut(quantity, sellPrice, expectedSellPrice);
                            // 預期能賣出，在顯示時 filled+filling 讓 storage 預期是清空的
                            sellOutStock.filling -= quantity;
                        }
                    });
                }
                else {
                    // 如果都不適合交易，就做擊穿檢查
                    // todo
                    // 跌過低，重整看看倉位的設置
                    // return this._resetStocks();
                }
                console.log('top price2:', highPrice);
                console.log('bottom price2:', lowPrice);
                console.log('hub 在偏', top - hub < hub - bottom ? '高' : '低', '水位');
            })
            .then(() => {
                // todo: 觀察這樣做好不好 ===> 換算一下interval 作為更新週期、如果 filter 的結果是沒有漂亮的漲勢就設只賣的flag/或換交易對(但這個應該是resort 那邊檢查比較好的感覺)
                let time = 60;
                setTimeout(() => this._trade, time * 1000);//todo this._trade 其實沒補 this._trade(interval)，想一下怎麼換算interval 跟 time以動態調整刷新交易頻率

            });
    }
    // // 在做好風險檢查後決定是否下單，如果不適合購買就不該要求 marketTrader 下單
    // _trade() {
    //     // todo 也要考慮一下整個倉位場域的邊綠狀態
    //     const storageInterval = 99;
    //     Promise.all([
    //         this._marketWatcher.updateCurrPrice(),
    //         this._marketWatcher.updateKlinesData()
    //     ]).then(([currPrice, klinesData]) => {
    //         // 先結算前一次掛單的結果
    //         this._marketTrader.ticketResult(this._stocks, currPrice)
    //             .then(() => {
    //                 // 跌出interval99倉位
    //                 if (this._marketWatcher.getFieldLevel(storageInterval, currPrice) === -1) {
    //                     // 跌過低，重整看看倉位的設置
    //                     this._resetStocks();
    //                     return;
    //                 }
    //                 // 先做一次下跌檢查，是的話就early return，並且先把手上的先賣光
    //                 if (this._isFallingLine()) {
    //                     const sellPrice = getPrecisionPrice(currPrice, -5);//向下5step 賣
    //                     this._stocks.forEach(({ price, filled }) => filled && this._marketTrader.sellOut(filled, price.avg, sellPrice));
    //                     console.log("下跌認賠止損狀態！");
    //                     return;
    //                 }
    //                 // todo 檢查是否已整理一段時間，可以切換到鯉躍龍門的狀態做噴發的抓取準備
    //                 // todo 可能試一下用深度圖確認再買
    //                 if (this._isFinishingLine()) {
    //                     const quantity = this._marketTrader.getFunds() - this._stocks.reduce((sum, x) => x.storage - x.filled, 0);
    //                     this._marketTrader.buyIn(quantity, getPrecisionPrice(currPrice, 5));// 把買價再升個5step，不然怕買不到
    //                     // ==> 要賣 this._marketTrader.sellOut(quantity,avgPrice, currPrice * 1.25, currPrice, 1.3);
    //                     // ==> 這邊直接交給 _shortLineCapeture 處理賣單趨勢去做，狂漲時有策略
    //                 }
    //                 else {
    //                     // 做短線振盪的交易
    //                     this._shortLineCapeture();
    //                 }
    //             });
    //     });
    //     // 一分鐘
    //     setTimeout(() => this._trade(), 60 * 1000);
    // }
    // // 檢查是否處理跌落的狀態
    // _isFallingLine() {
    //     const getField = (interval) => this._marketWatcher.getWaveField(interval);
    //     // 從上漲趨勢中取得 closing-opening 的值並加總，最後除以整個場域回來的結果
    //     // todo getRaiseTrend(interval, times) 被 getWaveVariations取代
    //     const variationRate = (interval) => this._marketWatcher.getWaveVariations(interval).reduce((prev, curr) => prev + curr, 0) / getField(interval);
    //     // ===TEST
    //     console.log("variationRate(3)", variationRate(3), '<-0.25跌爆');
    //     console.log("variationRate(7)", variationRate(7), '<0.2算跌');
    //     console.log("variationRate(15)", variationRate(15), '<-1是跌');
    //     console.log("variationRate(25)", variationRate(25), '<-2是跌');
    //     // ---TSET
    //     return variationRate(3) < -0.25    // 3分鐘內跌爆了
    //         // || variationRate(7) < 0.2 
    //         || variationRate(15) < -1
    //         || variationRate(25) < -2       // 25分鐘內都是跌
    // }
    // // 檢查是否正在整理
    // _isFinishingLine() {
    //     const mainFeild = this._marketWatcher.feild24hr;
    //     // 從上漲趨勢中取得 closing-opening 的值，個別除以整個場域回來的清單
    //     const checkLowVariation = (interval, rate) => {
    //         const feild = this._marketWatcher.getWaveField(interval);
    //         // 場域需要小於24小時交易量的2成 todo 也可能長期低迷，看能不能有個比較長期依據的
    //         if (feild / mainFeild > 0.2) return false;
    //         // todo getRaiseTrend(interval, times) 被 getWaveVariations取代
    //         // 先抓出需要的變動量
    //         let tempVariations = this._marketWatcher.getWaveVariations(interval);
    //         let top3 = tempVariations.splice(interval - 3);//分離最後3根k棒
    //         // 檢查前面的k棒變動量是否高於 rate 的值，以判定接近倉位最大最小值 (接近就代表很平均，而不是忽大忽小的短線波動振盪)
    //         if (tempVariations.every((x) => Math.abs(x) / feild > rate)) {
    //             // todo或用最大的20%
    //             // 算top3 有沒有大漲 todo 看數值怎麼算比較合適
    //             return top3.some((x) => x / mainFeild > 0.2);
    //         }
    //         return false;
    //     };
    //     // ===TEST
    //     console.log("checkLowVariation(7,0.8)", checkLowVariation(7, 0.8));
    //     console.log("checkLowVariation(15,0.7)", checkLowVariation(15, 0.7));
    //     console.log("checkLowVariation(25,0.7)", checkLowVariation(25, 0.7));
    //     // ---TSET
    //     //todo 可以直接忽略最後一枝k棒 (因為突然漲才是鯉躍龍門的起點)，抓到大漲起頭的話就可以大量買，抓到大跌的話就停止交易
    //     // return checkLowVariation(7, 0.8) && checkLowVariation(15, 0.7) && checkLowVariation(25, 0.7) // 25分鐘內的波動振盪都接近場域，但場域卻很小
    //     return checkLowVariation(25, 0.7) // 25分鐘內的波動振盪都接近場域，但場域要很小才行
    // }
    // _shortLineCapeture() {
    //     // 用小的場域做短線振盪
    //     const interval = 7;
    //     // 期望價格 (可以再想想是否要隨預測做調整)
    //     const [expectedSellPrice, allowableSellPrice,
    //         allowableBuyPrice, expectedBuyPrice] = this._marketWatcher.wavePriceFields[interval];
    //     // 觀測一下目前在小場域中處於什麼水位
    //     const level = this._marketWatcher.getFieldLevel(interval, currPrice);
    //     if (level > 2) {
    //         // todo 做個趨勢判斷, 可以加入ema 均線判斷
    //         // 取適當的倉儲來處理購入暫存
    //         const buyInStock = this._stocks.find((x) => x.filled + x.filling < x.storage && x.price.base <= currPrice);
    //         if (allowableBuyPrice > currPrice && buyInStock.price.avg > currPrice) {
    //             const quantity = Math.max(x.storage / 5, x.filled);
    //             this._marketTrader.buyIn(quantity, buyInStock.price.avg, expectedBuyPrice);
    //             // 預期能買入的先佔位，避免無限填倉直到沒錢
    //             buyInStock.filling += quantity;
    //         }
    //     }
    //     else if (level < 2) {
    //         let range = 0;//todo 做一個能賺的金額
    //         // todo 做個趨勢判斷，狂漲就先別急著賣，可能抓漲30%做準備
    //         // range = x.price.base * 0.3;
    //         // 取適當的倉儲來處理售出暫存
    //         const sellOutStock = this._stocks.find((x) => x.filled > 0 && x.price.base <= currPrice);
    //         const avgPrice = sellOutStock.price.avg;
    //         if (allowableSellPrice < currPrice && avgPrice + range < currPrice) {
    //             this._marketTrader.sellOut(sellOutStock.filled, avgPrice, allowableSellPrice, expectedSellPrice);
    //         }
    //     }
    // }
}
module.exports = GridesTrader;