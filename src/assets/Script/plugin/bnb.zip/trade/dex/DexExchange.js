const DiscordWebhook = require('../../communication/discordWebhook');
const Asys = require('./Asys');

const limitLength = 200;
const sdm = new DiscordWebhook().sendDiscordMessage;

class DexExchange {
    constructor() {
        this.priceData = { price: [], price5m: [], price1h: [], price6h: [], price24h: [] };
        this.priceTopAlert = 0;
        this.priceBottomAlert = 0;
        this.volumeRate = '';

        this._stageTimestamp = Date.now();
        this._5mklines = { [this._stageTimestamp]: [] };

        this.asys = new Asys();

        // let tsetPrice = 13;
        // console.log(this.asys.dev(tsetPrice, 4, [tsetPrice,11,12,11,9,10,12,11,10,9,9,11,10,11,12]));

        // sdm('Hello!!');
    }

    load(address, chain, symbol) {
        require('axios')({
            url: 'https://www.dextools.io/shared/data/pair',
            method: 'GET',
            params: {
                address,
                chain,
            }
        })
            .then((result) => {
                // console.log('result:', result.data.data[0]);
                this.loadData(result.data.data[0]);
                this.draw('', this.priceData.price, symbol);
                let p = this.priceData.price[0];//最新的都排在第一筆
                if (this.priceTopAlert && this.priceTopAlert <= p) {
                    this.priceTopAlert = 0;
                    sdm(`${symbol} 價格達到 ${p}`);
                }
                if (this.priceBottomAlert && this.priceBottomAlert >= p) {
                    this.priceBottomAlert = 0;
                    sdm(`${symbol} 價格降到 ${p}`);
                }
            });
    }

    addTopAlert(value) {
        this.priceTopAlert = value;
    }
    addBottomAlert(value) {
        this.priceBottomAlert = value;
    }

    loadData(raw) {
        let priceData = this.priceData;
        Object.keys(priceData).forEach((key) => {
            let d = raw[key];
            if (d) {
                priceData[key].unshift(Math.precisionRound(d.price || d));
                priceData[key].splice(limitLength);
            }
        });
        //如果沒有的話就是沒交易量
        const volume24 = raw.price24h.volume;
        const price = raw.price;
        if (raw.price5m)
            this.volumeRate = `5m $${Math.precisionRound(raw.price5m.volume * price, 2)} (${Math.precisionRound(raw.price5m.volume / volume24 * 100, 2)}%) bid[${raw.price5m.buys}/${raw.price5m.swaps} of ${raw.price24h.buys}/${raw.price24h.swaps} $${Math.precisionRound(volume24 * price, 2)}]`;
        else if (raw.price1h)
            this.volumeRate = `1h $${Math.precisionRound(raw.price1h.volume * price, 2)} (${Math.precisionRound(raw.price1h.volume / volume24 * 100, 2)}%) bid[${raw.price1h.buys}/${raw.price1h.swaps} of ${raw.price24h.buys}/${raw.price24h.swaps} $${Math.precisionRound(volume24 * price, 2)}]`;
        else if (raw.price6h)
            this.volumeRate = `6h $${Math.precisionRound(raw.price6h.volume * price, 2)} (${Math.precisionRound(raw.price6h.volume / volume24 * 100, 2)}%) bid[${raw.price6h.buys}/${raw.price6h.swaps} of ${raw.price24h.buys}/${raw.price24h.swaps} $${Math.precisionRound(volume24 * price, 2)}]`;
        else
            this.volumeRate = `24h $${Math.precisionRound(volume24 * price, 2)} (${Math.precisionRound(volume24 / volume24 * 100, 2)}%) bid[${raw.price24h.buys}/${raw.price24h.swaps}]`;


        const dateNow = Date.now();
        if (dateNow - this._stageTimestamp < 5 * 60000) {
            this._5mklines[this._stageTimestamp].push(Math.precisionRound(raw.price));
        }
        else {
            const kline = this._5mklines[this._stageTimestamp];
            const priceIn = kline[0], priceOut = kline[kline.length - 1], priceMin = Math.min(...kline), priceMax = Math.max(...kline);
            // 一直沒變化就不跑Kline 了
            if (Math.min(priceMin, priceMax) < priceMax) {
                const range = this.asys.range(kline);
                const excision = 4;
                const sliceRange = Math.precisionRound(range.dist / excision);
                let partIn = new Array(excision).findIndex((nul, idx) => range.min + sliceRange * idx > priceIn);
                let partOut = new Array(excision).findIndex((nul, idx) => range.min + sliceRange * idx > priceOut);

                console.log(`==> KLINE:[in ${priceIn} out ${priceOut} [${Math.precisionRound(priceOut - priceIn)}${priceOut > priceIn ? "▲" : "▽"} ${partIn}-${partOut}]](${priceMin} - ${priceMax}`);
            }
            //todo dev n of m
            this._stageTimestamp = dateNow;
            this._5mklines[this._stageTimestamp] = [];
        }
    }

    draw(color, values, symbol) {
        // "price5m":{
        //     "volume":688.519568,
        //     "swaps":9,
        //     "price":0.01988407118644068,
        //     "priceChain":0.0009170830102687831,
        //     "buys":1,
        //     "sells":8
        // },
        // let prices = values.map((v) => v.price).reverse();
        this.asys.driftLength++;
        const price = values[0];
        let devStr = '';
        if (values[1] != price) {
            devStr = this.asys.dev(4, values);
        } else {
            devStr = this.volumeRate;
        }

        values.length > 1
            ? console.log(`${symbol} ${price} ${price == values[1] ? " " : (price > values[1] ? "▲" : "▽")} (${Math.min(...values)} - ${Math.max(...values)} [${values.length}/${limitLength}]) ${devStr}`)
            : console.log(`${symbol} ${price}`);

    }
}
module.exports = DexExchange;
