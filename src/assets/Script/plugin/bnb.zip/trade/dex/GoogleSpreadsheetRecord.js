// // npm install --save form-data
// var FormData = require('form-data');
// var XMLHttpRequest = require('xhr2');
const scriptUrl = 'https://script.google.com/macros/s/AKfycbw12NY5MWn2NeIq8fd9VD3nvyVCR52aTk_uCcVzXVHct-5FT7RSbQi7UcEcAJMApper1A/exec';
function writeToGoogleScript(dataArray) {
    return require('axios').get(scriptUrl, {
        params: {
            action: 'writeDataFromSheet',
            dataArray: dataArray.join(','), // 將數據以逗號分隔
        }
    })
        .then(response => {
            console.log(response.data);
        })
        .catch(error => {
            console.error('發生錯誤：', error);
        });
}

// 以Google試算表存入交易紀錄
var logcat = ((symbol, creation, currPrice, stock, funds, assets) => {
    // 要寫入試算表的數據陣列
    const dataArray = [
        // 交易對，用於比對表格頁籤; 交易時間; 現價
        symbol, creation, currPrice,
        // 最高點; 賣出點; 買入點; 最低點; 認賠點
        stock.price.top, stock.price.gain, stock.price.avg, stock.price.bottom, stock.price.last,
        // 交易中倉位; 已填倉位; 總倉位庫存
        stock.filling, stock.filled, stock.storage,
        // 交易現有資金(用currPrice換算); 指定交易幣種[已鎖定]; 指定交易幣種[可動用]; 交易消費幣種[已鎖定]; 交易消費幣種[可動用]
        funds, assets.base.free, assets.base.lock, assets.quote.free, assets.quote.lock,
    ];

    // 呼叫函式
    return writeToGoogleScript(dataArray);
});


module.exports = {
    logcat,
};