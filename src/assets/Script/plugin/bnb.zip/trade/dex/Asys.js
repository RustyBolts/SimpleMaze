
class Asys {
    constructor() {
        this.part = -1;
        this.driftLength = 0;
        this._dataList = [];
    }

    range(dataList) {
        let driftList = [];
        dataList.slice(0, this.driftLength).forEach((d, i, a) => i + 1 < a.length && driftList.push(Math.abs(a[i + 1] - d)));
        // console.log('driftList:', this.driftLength, driftList);
        const max = Math.max(...dataList), min = Math.min(...dataList),
            //todo drift 可能要抓一個連入不同part 後的平均值作為分析
            driftMax = Math.precisionRound(Math.max(...driftList)),//todo 再加一個做最後一個的差距，用來判斷是不是飛天或瀑布
            driftAvg = Math.precisionRound(driftList.reduce((pre, cur) => pre + cur, 0) / driftList.length),
            diiftLast = Math.precisionRound(driftList[0]);
        return {
            max, min, driftMax, driftAvg, diiftLast,
            dist: max - min
        };
    }

    dev(excision, dataList) {
        const price = dataList[0];
        const range = this.range(dataList);
        // console.log('range:', range);
        const sliceRange = Math.precisionRound(range.dist / excision);
        // new Array(excision).fill(1).forEach((nul, idx) => console.log(range.min + sliceRange * idx , price));
        let part = new Array(excision).findIndex((nul, idx) => range.min + sliceRange * idx > price);

        // part === -1 && (part = excision);//todo
        // 一變換就先清掉 todo 要做成過每 part 中線才清
        // if (part != this.part) this.driftLength = 1;
        part = this.checkPartChange(this.part, part, excision);

        const bottom = Math.precisionRound(range.min + sliceRange * part);
        const top = Math.precisionRound(bottom + sliceRange);
        // return `get ${part} of ${excision} (${bottom}-${top} sliceRange: ${sliceRange}) drift: max- ${range.driftMax} avg- ${range.driftAvg} (佔整體 ${Math.precisionRound(range.driftAvg / range.dist * 100, 2)}%) ,last- ${range.diiftLast} (${Math.precisionRound(range.diiftLast / range.dist * 100, 2)}%)`;
        return `get ${part} of ${excision} (${bottom}-${top} : ${sliceRange}) drift: max- ${range.driftMax} avg- ${range.driftAvg} (變動佔比 ${range.diiftLast} [${Math.precisionRound(range.diiftLast / range.dist * 100, 2)}%])`;
    }

    // add(price, excision) {
    //     this._dataList.push(price);
    //     return this.dev(excision, this._dataList);
    // }

    // chekc chenge part up or down
    checkPartChange(ori, cur, excision) {
        cur == -1 && (cur = 5);
        const sign = Math.sign(cur - ori);

        // 一變換就先清掉 todo 要做成過每 part 中線才清
        if (sign != 0)
            this.driftLength = 1;

        console.log('partChange sign:', sign);
        this.part = cur;
        switch (cur) {
            case 1: // b-1
                // console.log('check buy');
                break;
            case 2: // b-2
                // console.log('maybe buy');
                break;
            case 3: // s-2
                // console.log('maybe sell');
                break;
            case 4: // s-1
                // console.log('check sell');
                break;
            default:
                // console.log('sell!!!!!??');
                this.part = excision;
                break;
        }

        return this.part;
    }

}
module.exports = Asys;