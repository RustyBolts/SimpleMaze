const units = [7, 25, 99];
class Ema {
    constructor(name, klines) {
        this.name = name;

        let closeingList = klines.map((kline) => kline.closing);
        this.emaPrices = units.map((unit) => closeingList.slice(0, unit).reduce((prev, curr) => prev + curr, 0) / unit);

        let valumeLisit = klines.map((kline) => kline.valume);
        this.emaValumes = units.map((unit) => valumeLisit.slice(0, unit).reduce((prev, curr) => prev + curr, 0) / unit);
    }
    // ema 均線
    addNew(kline) {
        const currPriceX2 = kline.closing * 2;
        this.emaPrices = units.map((unit, idx) => (this.emaPrices[idx] * (unit - 1) + currPriceX2) / (unit + 1));

        const currValumeX2 = kline.valume * 2;
        this.emaValumes = units.map((unit, idx) => (this.emaValumes[idx] * (unit - 1) + currValumeX2) / (unit + 1));
    }
    // 現價/ema均線比
    avgPriceEmaRate(currPrice) {
        return this.emaPrices.map((avg) => Math.precisionRound(currPrice / avg, 4));
    }
    // ema均線整理率
    avgTidyRate(klines) {
        return this.emaPrices.map((avg) => {
            const rate = klines.map((kline) => {
                const { highest, lowest, openning, closing } = kline;
                return (highest >= avg && avg >= lowest) + 0;
            })
                .reduce((prev, curr) => prev + curr, 0) / klines.length;
            return Math.precisionRound(rate, 4);
        });
    }
    // avgPriceEmaRate
    avgValumeDiffRate(kline) {
        return this.emaValumes.map((valume) => Math.precisionRound(kline.valume / valume, 4));
    }
}
module.exports = Ema;
