class Assets {
    constructor(symbol, captial, funds) {
        this.symbol = symbol;
        this._free = funds;
        this._lock = captial - funds;
    }
    // 取得資本
    get captial () {
        return this._free + this._lock;
    }
    // 取得可動資金
    get funds() {
        return this._free;
    }
    // 增加
    increase(value) {
        this._free += value;
    }
    // 減少
    decrease(value) {
        this._free -= value;
    }
    // 凍結
    freeze(value) {
        this._free -= value;
        this._lcok += value;
    }
    // 解凍
    thaw(value) {
        this._free += value;
        this._lock -= value;
    }
    // 解鎖被凍結的數量
    unlock(value) {
        this._lock -= value;
    }
}
module.exports = Assets;