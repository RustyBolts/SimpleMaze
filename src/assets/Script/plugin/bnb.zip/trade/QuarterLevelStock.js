const { getPrecisionPrice, getPrecisionQuanity } = require('../data/binance/exchangeInfo');
/**
 * 四分級倉位: 主要只用在一個倉位進行多次交易，可能同時存在買賣單
 */
class QuarterLevelStock {
    constructor(symbol) {
        this._toPrice = (value, stepFix) => getPrecisionPrice(symbol, value, stepFix);
        this._toQty = (value) => getPrecisionQuanity(symbol, value);
    }
    // 初始化價位設定
    initPrice(quarterLevel, gain = 0, last = 0) {
        const [highest, highier, lower, lowest] = quarterLevel;
        if (gain === 0)
            gain = highier;
        if (last === 0)
            last = this._toPrice(lowest - (lower - lowest));

        this.price = {
            top: highest,       // 倉位的最高點
            gain: gain,         // 用avg 推算可獲利的值
            heigh: highier,     // 倉位中驅近高點的平均值
            base: lower,        // 倉位中驅近低點的平均值
            avg: lower,         // 購買後的平均價，值低於低點平均值
            bottom: lowest,     // 倉位的最低點，跌破要發出警訊
            last: last,         // 擊破後設定認賠金額
        };
    }
    // 初始化倉位 Base assets
    initBaseStorage(quantity) {
        this.storage = this._toQty(quantity);
    }
    // 平均值整理 (filled 與 quantity 合併後使用)
    avarageParsing(price, quantity) {
        // (aPrice * aQty + bPrice * bQty) / (aQty + bQty) = price.avg;
        // (80*40 + 85 *60)/(40+60) = (3200+5100=8300)/100 = 83;

        // 花費的 Quote assets 價值
        const costQuote = price * quantity;

        // 已購入的 Quote assets 價值
        const quote = this.price.avg * (this.filled - quantity);

        // 總計預定花費與購入(含預定購入)，全部累加起來後換算出合理的平均價格
        const totalQuote = costQuote + quote;
        this.price.avg = totalQuote / this.filled;
    }
    // 下買單
    bid(price, quantity) {
        // 當前有買單
        if (this.buying / this.storage > 0.01) {
            let lave = this.storage - this.buying;
            if (lave < quantity) {
                console.log('當前買單與現有庫存已爆倉');
                return false;
            }
        }
        // 當前有賣單
        else if (this.selling / this.storage > 0.01) {
            // console.log('當前有賣單，先取消倉位賣單');
            // return false;
        }

        // 累計在預定購入的 Base assets
        this.buying += quantity;
        return true;
    }
    // 買單整理
    bidFinishing(price, quanity, executedQty, earn) {
        if ((quanity - this.buying) / this.storage > 0.01) {
            console.log(`下單購買數量${quanity}超出預定購入數量${this.buying}`);
        }

        this.buying -= quanity;
        this.filled += executedQty;

        // 計算平均價格
        this.avarageParsing(price, executedQty);
        // 調整獲利價格
        price.gain = Math.max(price.heigh, price.avg + earn);
    }
    // 下賣單
    ask(price, quantity) {
        if (this.filled < quantity) {
            console.log(`庫存不足無法完成指定數量${quantity}的訂單`);
            return false;
        }

        this.selling -= quantity;
        return true;
    }
    // 賣單整理
    askFinishing(price, quanity, executedQty) {
        this.selling += quanity;
        this.filled -= executedQty;

        // 恢復平均價格與獲利價格
        this.price.gain = this.price.heigh;
        this.price.avg = this.price.base;
    }
}
module.exports = QuarterLevelStock;