const { list, order, cancel, replace, check, testOrder, testCancel, testCheck } = require("../data/binance/ticket");

class TicketOrder {
    constructor(ownerId, symbol, lifeMins = 10) {
        // 訂單最大存留時間(分鐘)
        this._ticketLifeMins = lifeMins;
        // 下訂單後暫存，執行 update 會連過去的訂單都抓下來，做ticket.list 並暫存的訂單資料
        this._tradingTickets = {};
        // 完成交易後，等待後續處理的訂單
        this._tradeList = [];
        // 撤除訂單後，處理需要釋放的參數
        this._dropList = [];
        // 
        if (ownerId) {
            this._listHandler = () => list(ownerId, symbol);
            this._orderHandler = (side, quantity, price) => order(ownerId, symbol, side, quantity, price);
            this._checkHandler = (orderId) => check(ownerId, symbol, orderId);
            this._cancelHandler = (orderId) => cancel(ownerId, symbol, orderId);
            this._replaceHandler = (orderTicket, newPrice) => replace(ownerId, symbol, orderTicket, newPrice);
        }
        else {
            this._listHandler = () => Promise.resolve();
            this._orderHandler = (side, quantity, price) => testOrder(ownerId, symbol, side, quantity, price);;
            this._checkHandler = (orderId) => testCheck(ownerId, symbol, this._tradingTickets[orderId]);
            this._cancelHandler = (orderId) => testCancel(ownerId, symbol, this._tradingTickets[orderId]);
            this._replaceHandler = (orderTicket, newPrice) => Promise.resolve();
        }
    }
    update() {
        return this._listHandler()
            .then((orderTickets) => orderTickets.forEach(ticket => this._process(ticket)))
            .then(() => this._tradingTickets);
    }
    bid(quantity, price) {
        return this._orderHandler('BUY', quantity, price)
            .then((orderTicket) => this._process(orderTicket));
    }
    ask(quantity, price) {
        return this._orderHandler('SELL', quantity, price)
            .then((orderTicket) => this._process(orderTicket));
    }
    del(orderId) {
        return this._cancelHandler(orderId)
            .then((orderTicket) => this._process(orderTicket));
    }
    check(orderId) {
        return this._checkHandler(orderId)
            .then((orderTicket) => this._process(orderTicket));
    }
    replace(orderTicket, newPrice) {
        return this._replaceHandler(orderTicket, newPrice)
            .then((orderTicket) => this._process(orderTicket));
    }
    // 撤下所有掛單
    cancelAll() {
        return Promise.all(Object.keys(this._tradingTickets)
            .map((orderId) => this.del(orderId)));
    }
    // 代入現價，以期處理訂單
    checkAll() {
        const mins = this._ticketLifeMins;
        return Promise.all(
            Object.keys(this._tradingTickets).map((orderId) => {
                const { side, transactTime } = this._tradingTickets[orderId];
                // 超過 mins 分鐘的還是沒辦法完成訂單強制更新，_process 檢查如果還是未完成訂單就會執行撤單
                if (Date.now() - transactTime > mins * 60 * 1000) {
                    return this.check(orderId)
                        // 超過 mins 分鐘的還是沒辦法完成訂單就先撤掉了
                        .then(result => !result && this.del(orderId));
                }
                return this.check(orderId);
            })
        )
            // 若有處理訂單，回傳真值
            .then((result) => result.some((x) => x));
    }
    _process(orderTicket) {
        // status 處理訂單狀態       
        switch (orderTicket.status) {
            case 'NEW':                 //新建订单
            case 'PARTIALLY_FILLED':    //部分成交
                const { orderId, origQty, executedQty } = orderTicket;
                if (origQty === executedQty) {
                    this._onTicketFulled(orderTicket);
                    return true;
                }
                else {
                    // 訂單先更新一下狀態
                    this._transTicketContent(orderTicket);
                }
                break;
            case 'FILLED':              //全部成交
                this._onTicketFulled(orderTicket);
                return true;
            case 'CANCELED':            //已撤销       
                // 撤銷訂單時，檢查交易進度並更新資產
                this._onTicketCanceled(orderTicket);
                return true;
            case 'PENDING_CANCEL':      //正在撤销中(目前不会遇到这个状态)       
            case 'REJECTED':            //订单被拒绝       
            case 'EXPIRED':             //订单过期(根据timeInForce参数规则)       
            default:
                console.log('ticket status:', orderTicket.status);
                break;
        }
        return false;
    }
    _transTicketContent(orderTicket) {
        const { orderId } = orderTicket;
        if (this._tradingTickets[orderId] == null) {
            this._tradingTickets[orderId] = orderTicket;
        }
        else Object.keys(this._tradingTickets[orderId]).forEach((key) => {
            console.log('\t\t', key, ':', orderTicket[key]);
            this._tradingTickets[orderId][key] = orderTicket[key];
        });
    }
    _onTicketFulled(orderTicket) {
        if (this._tradingTickets[orderTicket.orderId] != null) {
            this._tradeList.push(orderTicket);
            delete this._tradingTickets[orderTicket.orderId];
        }
    }
    _onTicketCanceled(orderTicket) {
        if (this._tradingTickets[orderTicket.orderId] != null) {
            this._dropList.push(orderTicket);
            delete this._tradingTickets[orderTicket.orderId];
        }
    }
    // 提取處理完成的交易單
    takeTradeList() {
        const list = this._tradeList.slice();
        this._tradeList.length = 0;
        return list;
    }
    // 提取撤銷的交易單
    takeDropList() {
        const list = this._dropList.slice();
        this._dropList.length = 0;
        return list;
    }
}
module.exports = TicketOrder;