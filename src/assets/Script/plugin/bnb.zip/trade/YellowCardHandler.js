const { addDispatcher, removeDispatcher, connectListener } = require("../communication/bridge");
const { dbRecord, dbConnect } = require("../communication/firebase");
const { addNewRoom, getRoomInfo } = require("../data/ConnectionDataModal");
const loagestore = require('localStorage');
const GameStatus = {
    JOIN: 0,
    READY: 1,
    GAME: 2,
    VOTE: 3,
};
const Role = {
    PLAYER: 0,
    MASTER: 1
};
const DelayMS = 10000;

class YellowCardHandler {
    constructor(guid_id, isHonst) {
        this.isHonst = isHonst;
        // honst
        if (isHonst) {
            // this.players = {};
            // this.questions = [];
            // this.answers = [];
            this.cardMax = {
                q: 2,
                a: 5
            };
            this.roundIndex = 0;
            this.holderIds = [];

            this.gameReadyInterval;

            // this.addDispatchNotifies(guid_id);
            // this._tempCnt = 4;
            addDispatcher(guid_id, this, {
                'ping': this.notify_ping,
            });
        }
        else {
            // client
            this.uniquneid = guid_id;
            this.nickname = 'XXX';//todo
            this.questionHandCards = [];
            this.answerHandCards = [];
            this.masterQuestion = '';
            this.role = Role.PLAYER;
            this.coin = 0;//獲勝時累積1枚
            this.yellowCard = 0;
            this.answerCards = [];
            this.otherMergeCards = {};

            addDispatcher(guid_id, this, {
                'pong': this.notify_pong,
            });
        }

        this.addDispatchNotifies(guid_id);

        //test
        // if (!isHonst) {
        //     // dbConnect.applicate(this.uniquneid, 'roomList');
        // }
    }

    // ping(guid_id) {
    //     dbConnect.applicate(guid_id, 'ping', Date.now());
    // }

    testNewRoom() {
        dbConnect.applicate(this.uniquneid, 'newRoom');
        // dbConnect.applicate(this.uniquneid, 'roomList');
    }

    updateQuestion(index = -1) {
        const dataLength = 2;
        if (index === -1) index = Math.round(Math.random() * 1000 % dataLength);
        dbRecord.download('Question', index.toString())
            .then((data) => Object.keys(data).forEach((d) => this.roomInfo.questions.push(d)))
            .then(() => this.roomInfo.questions = this.roomInfo.questions.sort(() => Math.random() - 0.5));
    }
    updateAnswer(index = -1) {
        const dataLength = 3;
        if (index === -1) index = Math.round(Math.random() * 1000 % dataLength);
        dbRecord.download('Answer', index.toString())
            .then((data) => Object.keys(data).forEach((d) => this.roomInfo.answers.push(d)))
            .then(() => this.roomInfo.answers = this.roomInfo.answers.sort(() => Math.random() - 0.5));
    }

    leaveRoom() {
        if (isHonst) {
            this.roomInfo = null;
        }
        else {
            loagestore.removeItem('yellow_card');
            // room list
            dbConnect.applicate(this.uniquneid, 'roomList');
        }
        // removeDispatcher(this.uniquneid, this);
    }

    gameOver() {
        // 結束一局遊戲
    }

    // honst
    notify_ping(isHonst, guid_id, key, value) {
        if (isHonst) {
            // 每10秒檢查一次ping pong
            // const delayMS = 10000;
            console.log('ping', value);

            // 連線檢查: client 要接pong，然後等 DelayMS 的時間後再送出 ping 以保持連線確認
            dbConnect.broadcast(guid_id, 'pong', Date.now());

            // client 固定時間送出 ping ，計時未再送ping 的話就斷線 TODO: 看是不是多個幾次再斷線？
            const timestamp = parseInt(value, 10);
            this._timoutInterval && clearTimeout(this._timoutInterval);
            this._timoutInterval = setTimeout(() => {
                // 等待超時
                if (Date.now() - timestamp > DelayMS) {
                    console.log(guid_id, '等待超時');
                    // 結束登入狀態
                    // dbConnect.disconnect(guid_id);
                    const split = guid_id.split('::');
                    const guid = split[0];
                    const id = split[1];
                    dbConnect.status(guid, id, 'disconnect');
                }
            }, DelayMS + 1000);// 延遲時間再多1秒緩衝
        }
    }

    // client 這邊要做的，記得一開始要先送給Honst ping， 才不會被honst 移除連線
    notify_pong(isHonst, guid_id, key, value) {
        if (isHonst) {
        } else {
            console.log('pong');
            // 每10秒檢查一次ping pong
            // const DelayMS = 10000;
            setTimeout(() => {
                // 收到 DelayMS 後回送
                dbConnect.applicate(guid_id, 'ping', Date.now());
            }, DelayMS);
        }
    }

    addDispatchNotifies(guid_id) {
        addDispatcher(guid_id, this, {
            'roomList': this.notify_roomList,
            'newRoom': this.notify_newRoom,
            'knock': this.notify_knock,
            'reconnect': this.notify_reconnect,
            'join': this.notify_join,
            'gameReady': this.notify_gameReady,
            'readyCountdown': this.notify_readyCountdown,
            'gameStart': this.notify_gameStart,
            'gameRound': this.notify_gameRound,
            'licensing': this.notify_licensing,
            'drawQuestion': this.notify_drawQuestion,
            'drawAnswer': this.notify_drawAnswer,
            // 'fold': this.notify_fold,
            'question': this.notify_question,
            'answer': this.notify_answer,
            'urge': this.notify_urge,
            'chooseBestAnswer': this.notify_chooseBestAnswer,
            'bestAnswer': this.notify_bestAnswer,
            'showAnswers': this.notify_showAnswers,
            'vote': this.notify_vote,
            'voteResult': this.notify_voteResult,
            'alert': this.notify_alert,
            'gameNext': this.notify_gameNext,
            'gameOver': this.notify_gameOver,
            'leave': this.notify_leave,
        });
    }

    notify_roomList(isHonst, guid_id, key, value) {
        console.log('notify roomList');
        if (isHonst) {
            dbRecord.roomList()
                .then((list) => {
                    const rNums = Object.keys(list);
                    dbConnect.broadcast(guid_id, key, JSON.stringify(rNums));
                });
        } else {
            const rNums = JSON.parse(value);
            const local = JSON.parse(loagestore.getItem('yellow_card') || '{"r":0,"d":0}');
            if (local.r && rNums.indexOf(local.r) > -1) {
                console.log('local.rNum:', local.r);
                dbConnect.applicate(this.uniquneid, 'knock', JSON.stringify({ r: local.rNum, d: local.dKey }));
            } else {
                console.log('room list:', rNums);
                // todo 顯示房間清單 
                // 選房間敲門，受到歡迎時會拿到門鑰
                const callback = (rNum) => dbConnect.applicate(this.uniquneid, 'knock', JSON.stringify({ r: rNum }));
            }
        }
    }

    notify_newRoom(isHonst, guid_id, key, value) {
        // console.log('newroom', this.uniquneid, isHonst, this.isHonst);
        if (isHonst) {
            this.roomInfo = addNewRoom();
            dbRecord.newRoom(this.roomInfo.rNum, this.roomInfo.dKey);
            dbConnect.broadcast(guid_id, key, JSON.stringify({ r: this.roomInfo.rNum, d: this.roomInfo.dKey }));

            // this.updateQuestion();
            // this.updateAnswer();
        }
        else {
            // 房主建立房間後直接敲門做進入
            console.log('房主建立房間後直接敲門做進入', JSON.parse(value));
            dbConnect.applicate(guid_id, 'knock', value);
        }
    }

    notify_knock(isHonst, guid_id, key, value) {
        if (isHonst) {
            const { r, d } = JSON.parse(value);
            this.roomInfo = getRoomInfo(r);
            if (this.roomInfo.isWelcome) {
                dbConnect.broadcast(guid_id, key, JSON.stringify({ r: this.roomInfo.rNum, d: this.roomInfo.dKey }));
            } else {
                if (r && d) {
                    // 檢查門鑰是否正確
                    if (this.roomInfo.rNum === r && this.roomInfo.dKey === d) {
                        // 自動重連: 不確定玩家是否拿到房號後斷線，重新走一次join
                        // dbConnect.applicate(guid_id, 'join');
                        this.notify_join(isHonst, guid_id, 'join');
                    } else {
                        // 房號過期
                        // dbConnect.disconnect(guid_id);
                        this.leaveRoom();
                    }
                } else {
                    dbConnect.broadcast(guid_id, key);
                    // dbConnect.disconnect(guid_id);
                }
            }
        } else {
            if (value) {
                // 敲門後收到回應門號與鑰匙，代表歡迎進入
                const { r, d } = JSON.parse(value);
                // save loagestore
                loagestore.setItem('yellow_card', { r, d });
                // join
                dbConnect.applicate(guid_id, 'join', this.nickname);
            }
            else {
                console.log('door is close');
            }
        }
    }

    notify_reconnect(isHonst, guid_id, key, value) {
        if (isHonst) {
        } else {
            // 接收honst 暫存資訊，以回復斷線前所需資料
            const { questionHandCards, answerHandCards, role, yellowCard, coin, answerCards } = value;
            dbConnect.applicate(guid_id, 'licensing', JSON.stringify({ questionHandCards, answerHandCards }));
            this.role = role;
            this.coin = coin;
            this.yellowCard = yellowCard;
            this.answerCards = answerCards;
            // todo 把目前的cmd 丟給client
        }
    }

    notify_join(isHonst, guid_id, key, value) {
        if (isHonst) {
            // console.log('value:', value, this.roomInfo);
            const nickname = value;
            const player = this.roomInfo.players[guid_id];
            if (!player) {
                this.roomInfo.addPlayer(guid_id, nickname, GameStatus.JOIN);
                // 加入時，只處理此玩家的顯示。後續更新丟給 gameReady 的方法做
                dbConnect.broadcast(guid_id, 'gameReady', JSON.stringify(this.roomInfo.getGameStatusPlayers()));
            }
            else {
                // 斷線回來，個人遊戲資訊更新
                dbConnect.broadcast(guid_id, 'reconnect', JSON.stringify(player));
            }
        }
    }

    notify_gameReady(isHonst, guid_id, key, value) {
        if (isHonst) {
            clearTimeout(this.gameReadyInterval);

            const player = this.roomInfo.players[guid_id];
            if (player) {
                // this.roomInfo.players[guid_id].gameStatus = JSON.parse(value);
                player.gameStatus = JSON.parse(value);
                console.log('gameReady player:', player);
                // check "allReady"
                const idList = this.roomInfo.getPlayerIds();
                // 刷新所有玩家的就緒列表
                const broadcastAll = (cmd, val) => idList.forEach((uniquneid) => dbConnect.broadcast(uniquneid, cmd, val));
                broadcastAll(key, this.roomInfo.getGameStatusPlayers());
                // check all players are ready then set countdown timer
                const readys = this.roomInfo.filterPlayerIdsByGameStatus(GameStatus.READY);
                const allReady = readys.length === idList.length;
                if (allReady) {
                    const refresStatus = (countdown) => {
                        if (countdown > 0) {
                            broadcastAll('readyCountdown', countdown--);
                            this.gameReadyInterval = setTimeout(() => refresStatus(countdown), 1000);
                        } else {
                            this.notify_gameStart(isHonst, guid_id, 'gameStart');
                        }
                    }
                    refresStatus(5);
                }

            } else {
                console.log('no join:', guid_id);
            }
        }
        else {
            // hide countdown ui
            // set ready player
            const playerReadyInfos = Object.keys(value).map((key) => {
                const { nickname, gameStatus } = value[key];
                const isReady = gameStatus === GameStatus.READY;
                return { nickname, isReady };
            });

            // todo prepare function on ready button
            const callback = (isReady) => dbConnect.applicate(this.uniquneid, 'gameReady', isReady ? GameStatus.READY : GameStatus.JOIN);
        }
    }
    notify_readyCountdown(isHonst, guid_id, key, value) {
        if (isHonst) {
        } else {
            const countdown = parseInt(value, 10);
            // show countdown ui
            console.log('readyCountdown:', countdown);
        }
    }

    notify_gameStart(isHonst, guid_id, key, value) {
        if (isHonst) {
            const idList = this.roomInfo.getPlayerIds();
            const length = idList.length;
            let nums = [];
            for (let i = 1; i <= length; i++) nums.push(i);
            nums = nums.sort(() => Math.random() - 0.5);
            idList.forEach((uniquneid, index) => this.roomInfo.players[uniquneid].serialNumber = nums[index]);
            this.roundIndex = 0;
            // 發牌
            this.notify_drawAnswer(isHonst, guid_id, 'drawAnswer', this.cardMax.a);
            // 開始第一回合
            this.notify_gameRound(isHonst, guid_id, 'gameRound');
            // 遊戲開始後不再給新玩家加入
            this.roomInfo.isWelcome = false;
        }
    }

    notify_gameRound(isHonst, guid_id, key, value) {
        if (isHonst) {
            // broadcastAll
            this.roomInfo.getPlayerIds().forEach((uniquneid) => {
                const player = this.roomInfo.players[uniquneid];
                const role = player.serialNumber != this.roundIndex ? Role.PLAYER : Role.MASTER;
                player.role = role;
                player.gameStatus = GameStatus.GAME;
                dbConnect.broadcast(uniquneid, key, role);
            });
        }
        else {
            this.role = parseInt(value, 10);
            if (this.role === Role.MASTER) {
                // 栽判抽題目卡
                dbConnect.applicate(guid_id, 'drawQuestion', this.cardMax.q);
                // 啟動問題卡的顯示清單，並在點擊時跳出確認送出的callback
                const callback = (questionCard) => dbConnect.applicate(guid_id, 'question', questionCard);
            }
        }
    }

    notify_licensing(isHonst, guid_id, key, value) {
        if (isHonst) {
            // client 可能需要更新手牌的現況，這邊收到請求就直接送
            const { questionHandCards, answerHandCards } = this.roomInfo.getPlayerHandCards(guid_id);
            dbConnect.broadcast(guid_id, key, JSON.stringify({ questionHandCards, answerHandCards }));
        }
        else {
            const { questionHandCards, answerHandCards } = value;
            const func = (mainCards, newCards, delCards) => {
                let cnt = 0;
                // card in
                if (newCards.length) {
                    const addCards = newCards.filter((card) => {
                        if (mainCards.indexOf(card) == -1) {
                            mainCards.push(card);
                            return true;
                        } else cnt++;
                    });
                    console.log('add:', addCards);
                }
                // card out
                if (delCards.length) {
                    cnt = 0;
                    const removeCards = delCards.filter((card) => {
                        if (mainCards[cnt] === card) {
                            mainCards.splice(cnt, 1);
                            return true;
                        } else cnt++;
                    });
                    console.log('remove:', removeCards);
                }
            };
            func(
                this.questionHandCards,
                this.questionHandCards.filter((card) => questionHandCards.indexOf(card) == -1),
                questionHandCards.filter((card) => this.questionHandCards.indexOf(card) == -1)
            );
            func(
                this.answerHandCards,
                this.answerHandCards.filter((card) => answerHandCards.indexOf(card) == -1),
                answerHandCards.filter((card) => this.answerHandCards.indexOf(card) == -1)
            );
        }
    }

    notify_drawQuestion(isHonst, guid_id, key, value) {
        if (isHonst) {
            const cardNum = parseInt(value, 10);
            const length = this.roomInfo.questions.length;
            const startIndex = length - Math.min(this.cardMax.q - length, cardNum);
            // const startIndex = length - cardNum;
            const { questionHandCards, answerHandCards } = this.roomInfo.getPlayerHandCards(guid_id);
            questionHandCards.concat(this.roomInfo.questions.splice(startIndex, length));
            this.notify_licensing(isHonst, guid_id, 'licensing');
            // 卡片庫不足時重刷
            if (length < 5) this.updateQuestion();
        }
    }

    notify_drawAnswer(isHonst, guid_id, key, value) {
        if (isHonst) {
            const cardNum = parseInt(value, 10);
            const length = this.roomInfo.answers.length;
            const startIndex = length - Math.min(this.cardMax.a - length, cardNum);
            // const startIndex = length - cardNum;
            const { questionHandCards, answerHandCards } = this.roomInfo.getPlayerHandCards(guid_id);
            answerHandCards.concat(this.roomInfo.answers.splice(startIndex, length));
            this.notify_licensing(isHonst, guid_id, 'licensing');
            // 卡片庫不足時重刷
            if (length < 10) this.updateAnswer();
        }
    }

    notify_fold(isHonst, guid_id, key, value) {
        if (isHonst) {
            const foldCards = value;
            this.roomInfo.dropAnswerHandCards(guid_id, foldCards) || this.roomInfo.dropQuestionHandCards(guid_id, foldCards);
            this.notify_licensing(isHonst, guid_id, 'licensing');
        }
    }

    notify_question(isHonst, guid_id, key, value) {
        if (isHonst) {
            const { role, nickname } = this.roomInfo.players[guid_id];
            // 檢查身份
            if (role === Role.MASTER) {
                const { questionHandCards, answerHandCards } = this.roomInfo.getPlayerHandCards(guid_id);
                // const param = { masterid: guid_id, question: value, nickname };
                const param = JSON.stringify({ question: value, nickname });
                this.roomInfo.dropQuestionHandCard(guid_id, questionHandCards);// 演出順序問題，等master 出牌處理後再請求 licensing 刷新做丟牌
                this.roomInfo.getPlayerIds().forEach((uniquneid) => dbConnect.broadcast(uniquneid, key, param));
                // 整理栽判的題目卡
                // this.roomInfo.dropQuestionHandCard(guid_id, value);
                // 印象應該是抽2選1丟掉，無需紀錄，這邊先把題目卡手牌全做棄牌處理
                // questionHandCards.forEach((handCard) => this.notify_fold(isHonst, guid_id, 'fold', handCard));
                // this.notify_fold(isHonst, guid_id, 'fold', questionHandCards);
                // ===> 不過目前在 licensing 的處理中想把多餘的牌直接棄牌動畫方式處理，fold 應該是拿掉
                // this.notify_licensing(guid_id, 'licensing');// 演出順序問題，等master 出牌後再刷新做丟牌
            }
        } else {
            if (this.role === Role.PLAYER) {
                /** 出題後，為其他玩家準備答題介面 */
                // const { masterid, question, nickname } = value;
                const { question, nickname } = value;
                // 顯示答案卡手牌庫
                // todo 回答時要做的
                const callback = (answerCards, foldCards) => {
                    dbConnect.applicate(guid_id, 'answer', JSON.stringify(answerCards));
                    // 在需要棄牌時做 fold card
                    foldCards && dbConnect.applicate(guid_id, 'fold', JSON.stringify(foldCards));
                };
            } else {
                /** 出題後，栽判回傳自己成功送出，並做後續等待玩家的答題回應 */
                this.masterQuestion = value;
                // 出牌後清掉所有的問題卡手牌
                this.questionHandCards.length = 0;
                // todo show question card in the center(不能再動)
                // this.masterQuestion
                // todo 顯示urge 按鈕
                const callback = () => dbConnect.applicate(guid_id, 'urge');
                // 刷新(造就棄牌動畫)
                dbConnect.applicate(guid_id, 'licensing');
            }
        }
    }

    notify_answer(isHonst, guid_id, key, value) {
        if (isHonst) {
            const answerCards = value;
            this.roomInfo.players[guid_id].answerCards = answerCards;
            const idList = this.roomInfo.getPlayerIds();

            // 轉傳給栽判
            const masterid = this.roomInfo.findMasterRolePlayerId(Role.MASTER);
            const param = JSON.stringify({ playerid: guid_id, answerCards });
            dbConnect.broadcast(masterid, key, param);
            // 回傳自己成功送出
            this.roomInfo.dropAnswerHandCards(guid_id, answerCards);// 整理玩家的答案卡
            dbConnect.broadcast(guid_id, key, param);

            // 紀錄還有誰沒出答案牌，所有玩家(除了栽判外)都出答案卡時，流程指向栽判選擇出最佳的答案
            // const players = this.roomInfo.players;
            // this.roomInfo.holderIds = idList.filter((uniquneid) => players[uniquneid].answerCards.length === 0);
            this.holderIds = this.roomInfo.filterHoldPlayerIds();
            this.holderIds.length === 0 && dbConnect.broadcast(masterid, 'chooseBestAnswer');

            // 整理玩家的答案卡
            // // answerCards.forEach((card) => this.data.dropAnswerHandCards(guid_id, card));
            // this.data.dropAnswerHandCards(guid_id, answerCards);
            // this.notify_licensing(guid_id, 'licensing');
            // this.notify_fold(guid_id, 'fold', answerCards);
        }
        else {
            let { playerid, answerCards } = value;
            // 栽判先暫存起來，以決定 bestAnswer
            if (this.role === Role.PLAYER) {
                // 成功送出後執行畫面動作
                // drop card
                answerCards.forEach((card) => {
                    this.answerHandCards.find((handCard, i, ary) => {
                        if (handCard === card) {
                            ary.splice(i, 1);
                            return true;
                        }
                    });
                });
                // answerCards todo drop card animation

                // // 送出牌時要做的 todo 在需要棄牌時做 fold card
                // const callback = (foldCard) => dbConnect.applicate(guid_id, 'fold', foldCard);

                // 補牌
                dbConnect.applicate(guid_id, 'drawAnswer', answerCards.length);
            }
            else {
                // 合併問答卡片
                const color = '#ffcc00';
                const mergeCard = this.masterQuestion.replace(/_+/g, () => `<color=${color}>${answerCards.shift()}</c>`);
                this.otherMergeCards[playerid] = mergeCard;
                // todo 顯示出栽判方顯示的玩家問答卡內容，可以翻閱 (等 chooseBestAnser 時再做點擊callback)
            }
        }
    }

    notify_urge(isHonst, guid_id, key, value) {
        if (isHonst) {
            // master call dbConnect.applicate(guid_id, 'urge');
            if (this.roomInfo.players[guid_id].role === Role.MASTER) {
                // dbConnect.broadcast(guid_id, key, this.holderIds);
                this.holderIds.forEach((uniquneid) => dbConnect.broadcast(uniquneid, 'alert', JSON.stringify({ msg: 'HERRY!!' })));
            }
            // } else {
            //     Object.keys(value).find((sn) => {
            //         if (this.uniquneid === value[sn]) {
            //             // 被催了，亮一下
            //             this.notify_alert(uniquneid, 'alert', { msg: 'HERRY!!' });
            //             return true;
            //         }
            //     });
        }
    }

    notify_chooseBestAnswer(isHonst, guid_id, key, value) {
        if (isHonst) {
        } else {
            if (this.role === Role.MASTER) {
                // todo 隱藏urge 按鈕

                // 提示栽判決定最佳的牌
                const callback = (playerid) => dbConnect.applicate(guid_id, 'bestAnswer', playerid);
                // this.otherMergeCards todo 把問答卡處理成按鈕

            }
        }
    }

    notify_bestAnswer(isHonst, guid_id, key, value) {
        const winnerid = value;
        if (isHonst) {
            // 檢查身份
            if (this.roomInfo.players[guid_id].role === Role.MASTER) {
                this.roomInfo.addPlayerCoin(winnerid);
                // 栽判公布最佳，然後玩家要投出最差
                this.roomInfo.filterPlayerIdsByRole(Role.PLAYER)
                    .forEach((uniquneid) => dbConnect.broadcast(uniquneid, key, winnerid));
            }
        } else {
            if (this.uniquneid === winnerid) {
                // 亮一下提示
                this.notify_alert(isHonst, winnerid, 'alert', JSON.stringify({ msg: 'You are the best!' }));//todo client show alert
                // 加個分
                this.coin++;
            }
            if (this.role === Role.PLAYER) {
                // 大家投最差的
                // todo vote on merge card list (to show all)
                const callback = (playerid) => dbConnect.applicate(guid_id, 'vote', playerid);
            }
            else if (this.roomInfo.getPlayerIds().length > 2) {
                // 提示栽判要宣布所有人的答案
                const callback = () => dbConnect.applicate(guid_id, 'showAnswers', JSON.stringify(this.otherMergeCards));
            }
            else {
                // joined players are too less, next round
                this.notify_gameNext(isHonst, guid_id, 'gameNext');
            }
        }
    }

    notify_showAnswers(isHonst, guid_id, key, value) {
        // 公開每個玩家的答案
        if (isHonst) {
            // 檢查身份
            if (this.roomInfo.players[guid_id].role === Role.MASTER) {
                this.roomInfo.filterPlayerIdsByRole(Role.PLAYER)
                    .forEach((uniquneid) => dbConnect.broadcast(uniquneid, key, value));
            }
        } else {
            if (this.role === Role.PLAYER) {
                const mergeCards = JSON.parse(value);
                // todo merge card list
                const callback = (playerid) => dbConnect.applicate(guid_id, 'vote', playerid);
            }
        }
    }

    notify_vote(isHonst, guid_id, key, value) {
        const idList = this.roomInfo.getPlayerIds();
        // 投出最差的卡片組合
        if (isHonst) {
            const playerid = value;
            this.roomInfo.players[guid_id].gameStatus = GameStatus.VOTE;

            // 紀錄得票數
            this.roomInfo.addPlayerVote(playerid);

            const votes = this.roomInfo.filterPlayerIdsByGameStatus(GameStatus.VOTE);
            const allVote = votes.length > 0 && votes.length === idList.length - 1;//除了栽判自己不用投
            console.log('allVote:', allVote);
            if (allVote) {
                // 
                const loserid = this.roomInfo.getHeighestVotePlayerId();
                // 標上黃牌
                this.roomInfo.addPlayerYellowCard(loserid);
                dbConnect.broadcast(loserid, 'voteResult', loserid);
                const masterid = this.roomInfo.findMasterRolePlayerId(Role.MASTER);
                dbConnect.broadcast(masterid, 'voteResult', loserid);
            }
        }
    }

    notify_voteResult(isHonst, guid_id, key, value) {
        if (isHonst) {
            // 投完票，結算一下成績: 有結果就結束這局
            // const getScore = ({ coin, yellowCard }) => coin - yellowCard;
            // const loserid = this.data.getPlayerIds().sort((a, b) => getScore(this.players[a]) - getScore(this.players[b]))[0];
            // if (getScore(this.players[loserid]) <= -5) {
            const loserid = this.roomInfo.getLosePlayer();
            if (this.roomInfo.players[loserid].yellowCard <= -5) {
                this.notify_gameOver(isHonst, guid_id, 'gameOver', loserid);
            }
        } else {
            const loserid = value;
            if (this.uniquneid === loserid) {
                // 被點到名的會顯示
                this.yellowCard++;
            }
            else if (this.role === Role.MASTER) {
                // 讓栽判知道是誰被投中，可以自主做決定增加樂趣
                const voteCallback = () => dbConnect.applicate(guid_id, 'alert', JSON.stringify({ playerid: loserid, msg: '就是你！' }));

                // 請求交棒
                const nextCallback = () => dbConnect.applicate(guid_id, 'gameNext');
            }

            this.otherMergeCards = {};
        }
    }

    notify_alert(isHonst, guid_id, key, value) {
        const { playerid, msg } = JSON.parse(value);
        if (isHonst) {
            if (playerid) {
                dbConnect.broadcast(playerid, key, value);
            } else {
                this.roomInfo.getPlayerIds().forEach((uniquneid) => dbConnect.broadcast(uniquneid, key, value));
            }
        }
        else {
            // todo show alert
            console.log('show alert message:', msg);
        }
    }

    notify_gameNext(isHonst, guid_id, key, value) {
        if (isHonst) {
            // 進行下一輪
            this.roomInfo.roundClear();
            this.roundIndex = (this.roundIndex + 1) % (this.roomInfo.getPlayerIds().length + 1) + 1;//base 1
            this.notify_gameRound(isHonst, guid_id, 'gameRound');
        }
    }

    notify_gameOver(isHonst, guid_id, key, value) {
        const loserid = value;
        if (isHonst) {
            this.gameOver();
            this.roomInfo.getPlayerIds().forEach((uniquneid) => dbConnect.broadcast(uniquneid, key, loserid));
        }
        else {
            // 跳出最輸的
            // todo clicke on game over button: 結束遊戲，離開房間
            const callback = () => dbConnect.applicate(guid_id, 'leave');
        }
    }

    notify_leave(isHonst, guid_id, key, value) {
        if (isHonst) {
            if (this.roomInfo.players[guid_id]) {
                dbConnect.broadcast(uniquneid, key, JSON.stringify({ id: guid_id, nickname: this.roomInfo.players[guid_id].nickname }));
                this.roomInfo.delPlayer(guid_id);
            }
        } else {
            const { id, nickname } = value;
            // del player on table
        }
    }
}
module.exports = YellowCardHandler;