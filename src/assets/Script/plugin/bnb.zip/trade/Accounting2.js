const Assets = require("./Assets");

class Accounting2 {
    constructor(baseSymbol, quoteSymbol, base, quote) {
        this.symbol = baseSymbol + quoteSymbol;
        // 交易目標貨幣
        this.baseAssets = new Assets(baseSymbol, base, base);
        // 資本使用貨幣
        this.quoteAssets = new Assets(quoteSymbol, quote, quote);
    }
    /**
     * 取得此交易對的資本價值
     * @param price 代入現價，取得當前價值
     * @returns 
     */
    getCaptial(price) {
        return this.getQuoteAssets() + this.getBaseAssets() * price;
    }
    // 取得 base 資金，帶入 onlyFree = true 只取未凍結資金
    getBaseAssets(onlyFree = false) {
        if (onlyFree) return this.baseAssets.funds;
        return this.baseAssets.captial;
    }
    // 取得 quote 資金，帶入 onlyFree = true 只取未凍結資金
    getQuoteAssets(onlyFree = false) {
        if (onlyFree) return this.quoteAssets.funds;
        return this.quoteAssets.captial;
    }
    /**
     * 下買單
     * @param quote 下單花費
     */
    bid(quote) {
        this.quoteAssets.freeze(quote);
    }
    /**
     * 買單收單
     * @param quote 預定下單花費
     * @param executedBase 購入執行量
     * @param executedQuote 花費執行量
     */
    bought(quote, executedBase, executedQuote) {
        if (quote === executedQuote) {
            // 結單
            this.quoteAssets.unlock(executedQuote);
            this.baseAssets.increase(executedBase);
        }
        else {
            // 撤單
            this.quoteAssets.thaw(quote);
            this.quoteAssets.decrease(executedQuote);
            this.baseAssets.increase(executedBase);
        }
    }
    /**
     * 下賣單
     * @param base 下單售出量
     */
    ask(base) {
        this.baseAssets.freeze(base);
    }
    /**
     * 賣單收單
     * @param base 預定下單售出量
     * @param executeBase 售出執行量
     * @param executeQuote 轉換執行量
     */
    sold(base, executeBase, executeQuote) {
        if (base === executeBase) {
            // 結單
            this.baseAssets.unlock(executeBase);
            this.quoteAssets.increase(executeQuote);
        }
        else {
            // 撤單
            this.baseAssets.thaw(base);
            this.baseAssets.decrease(executeBase);
            this.quoteAssets.increase(executeQuote);
        }
    }
}
module.exports = Accounting2;