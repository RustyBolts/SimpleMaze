const { tickerPrice } = require("../data/binance/api");
const { getPrecisionPrice } = require("../data/binance/exchangeInfo");
const market = require("../data/binance/market");
const { Interval } = require("../data/binance/request");

// 鯉躍龍門的判斷
class LeapingOver {
    constructor(ownerId) {
        this._ownerId = ownerId;

        // 暫存交易對，並更新其紀錄
        // this._histories = {};
        this._emaPrice = {};
        // 暫存交易對的場域 (先抓3日的)
        this._fields = {};
        this._intervals = {};
        // test
        this._lowestPrice = {};
    }

    kline(symbol, interval, limit, emaLength) {
        const toPrice = (value, stepFix) => getPrecisionPrice(symbol, value, stepFix);

        // 四等級分量: 取出 最高/最高平均/最低平均/最低 四等級出來，帶入 hub 參數作為上下的均
        const setQuarterLevel = (values, hub) => {
            let highValues = [], lowValues = [];
            values.forEach(x => x > hub ? highValues.push(x) : lowValues.push(x));
            const highest = Math.max(...highValues) || Math.max(...values);
            const lowest = Math.min(...lowValues) || Math.min(...values);
            // console.log('setQuarterLevel hub:', hub);
            // console.log('top:', top, highValues);
            // console.log('bottom:', bottom, lowValues);
            return [
                toPrice(highest),
                toPrice((highValues.length > 0 ? highValues.reduce((sum, v) => sum + v, 0) / highValues.length : highest)),
                toPrice((lowValues.length > 0 ? lowValues.reduce((sum, v) => sum + v, 0) / lowValues.length : lowest)),
                toPrice(lowest)
            ];
        };
        // ===

        const lastUpdateTime = 0;
        const currTime = Date.now();
        const onlyResult = true;

        return market.kline(this._ownerId, symbol, lastUpdateTime, currTime, interval, limit, onlyResult)
            .then((rawData) => {
                let topPrice = 0, bottomPrice = rawData[0][market.KLINE.Lowest];
                const closingList = rawData.map((data) => {
                    // console.log('data', data);
                    const opening = data[market.KLINE.Opening];     // 开盘价 
                    const highest = data[market.KLINE.Highest];     // 最高价 
                    const lowest = data[market.KLINE.Lowest];       // 最低价 
                    const closing = data[market.KLINE.Closing];     // 收盘价(当前K线未结束的即为最新价)
                    if (topPrice < highest) topPrice = highest;
                    if (bottomPrice > lowest) bottomPrice = lowest;
                    return closing;
                });
                const length = closingList.length;
                const hubPrice = toPrice(closingList.reduce((v, s) => v + s, 0) / length);
                const emaPrice = closingList.slice(length - emaLength, length).reduce((prev, curr) => prev + curr, 0) / emaLength;

                /** [topPrice, highestPrice, highPrice, lowPrice, lowestPrice, bottomPrice, emaPrice] **/
                return [topPrice, ...setQuarterLevel(closingList, hubPrice), bottomPrice, emaPrice];
            });
    }

    addObserve(symbol) {
        const toPrice = (value, stepFix) => getPrecisionPrice(symbol, value, stepFix);//todo 這之後再改成ratio，看比例就好

        const interval = Interval.MINUTES_15;
        const delayMins = 15;
        const limit = 3 * 24 * 60 / delayMins;// 3日
        const emaLength = 99;
        this.kline(symbol, interval, limit, emaLength)
            .then(([topPrice, highestPrice, highPrice, lowPrice, lowestPrice, bottomPrice, emaPrice]) => {
                // 瞬間最高/低的價格差距，看極限的差距
                const maxField = topPrice - bottomPrice;
                // 以收盤價來看，最高/低收盤價的差距，作為基本的場域
                const field = highestPrice - lowestPrice;
                // 以收盤價來看，平均振盪時的最大/小價格，計算出平均的波動值
                const variation = highPrice - lowPrice;

                console.log('maxField:', toPrice(maxField), 'field:', toPrice(field), 'variation:', toPrice(variation), 'emaPrice:', toPrice(emaPrice));

                this._fields[symbol] = field;
                this._emaPrice[symbol] = emaPrice;
                this._lowestPrice[symbol] = lowestPrice;

                this._updatePrice(symbol, delayMins, emaLength);
            });
    }

    removeObserve(symbol) {
        clearTimeout(this._intervals[symbol]);
        delete this._intervals[symbol];

        delete this._fields[symbol];
        delete this._emaPrice[symbol];
        delete this._lowestPrice[symbol];
    }

    _updatePrice(symbol, delayMins, emaLength) {
        console.log(symbol, 'ema price:', this._emaPrice[symbol], '(', this.getEMAPriceRatio(symbol), '%)');
        this._intervals[symbol] = setTimeout(() => {
            tickerPrice(this._ownerId, symbol)
                .then((result) => {
                    const closingPrice = parseFloat(result.price);
                    this._emaPrice[symbol] = (this._emaPrice[symbol] * (emaLength - 1) + closingPrice * 2) / (emaLength + 1);
                    this._updatePrice(symbol, delayMins, emaLength);
                });
        }, delayMins * 60 * 1000);
    }

    getEMAPriceRatio(symbol) {
        return Math.round(
            (this._emaPrice[symbol] - this._lowestPrice[symbol]) / this._fields[symbol] * 100
        );
    }
}

module.exports = LeapingOver;