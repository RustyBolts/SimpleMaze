const { Interval, DelayMins } = require("../data/binance/request");
const { getPrecisionPrice, getPrecisionVariation, getTradeRules } = require("../data/binance/exchangeInfo");
const market = require("../data/binance/market");
const { tickerPrice } = require("../data/binance/ticket");
const LocalStorage = require('node-localstorage').LocalStorage,
    localStorage = new LocalStorage('./scratch');

class MarketWatcher {
    constructor(ownerId, symbol) {
        this._ownerId = ownerId;
        this._symbol = symbol;

        // 針對現價的暫存與更新相關
        this._currPrice = 0;
        this._priceLastUpdateTime = 0;          // 最後更新時間戳
        this.priceUpdateInterval = 6 * 1000;    // 更新暫存保留的時間

        // 針對kline 資料後處理的振盪資料
        this.oscillation = {};

        // 交易對的基本規範參數
        this._precision = getTradeRules(this._symbol).filters.price.precision;
        this._stepSize = getTradeRules(this._symbol).filters.price.step;
    }

    // 更新現價 
    updateCurrPrice() {
        const currTime = Date.now();
        if (currTime - this._priceLastUpdateTime < this.priceUpdateInterval) {
            return Promise.resolve(this._currPrice);
        }
        return tickerPrice(this._ownerId, this._symbol)
            .then((price) => {
                this._priceLastUpdateTime = currTime;
                // console.log('_currPrice:', price);
                return this._currPrice = price;
            });
    }

    _updateOscillation(interval, limit) {
        let lastUpdateTime = 0;
        let currTime = Date.now();
        let onlyResult = true;

        const toFloatFixed = (v, p = this._precision) => parseFloat(v.toFixed(p));
        // const toRadio = (v) => toFloatFixed(v, 4);
        return market.kline(this._ownerId, this._symbol, lastUpdateTime, currTime, interval, limit, onlyResult)
            .then((rawData) => {
                let klineData = rawData.map((data) => {
                    // console.log('data', data);
                    const opening = data[market.KLINE.Opening];     // 开盘价 
                    const highest = data[market.KLINE.Highest];     // 最高价 
                    const lowest = data[market.KLINE.Lowest];       // 最低价 
                    const closing = data[market.KLINE.Closing];     // 收盘价(当前K线未结束的即为最新价) 
                    const valume = data[market.KLINE.Valume];       // 成交量 
                    // const variation = highest - lowest;             // 振盪變動量 
                    // const rise = toRadio((closing - opening) / opening);  // 漲幅 
                    // const time = new Date(data[0]);
                    // console.log(time.getHours(), ':', time.getMinutes(), ':', time.getSeconds());
                    // return { opening, highest, lowest, closing, valume, variation, rise };
                    return { opening, highest, lowest, closing, valume };
                });
                // console.log('klineData rise:', klineData.map(x => x.rise));

                const dataLength = klineData.length;

                // 更新現價
                this._currPrice = klineData[dataLength - 1].closing;
                this._priceLastUpdateTime = currTime;
                // console.log('price:', this._currPrice);

                const average = (values) => values.reduce((sum, v) => sum + v, 0) / values.length;

                //// 四等級分量: 取出 最高/最高平均/最低平均/最低 四等級出來，帶入 hub 參數作為上下的均
                // 四等級分量: 取出 最高平均/較高平均/較低平均/最低平均 四等級出來，帶入 hub 參數作為上下的平均值
                const setQuarterLevel = (values, hub, precision) => {
                    let highValues = [], lowValues = [];
                    values.forEach(x => x > hub ? highValues.push(x) : lowValues.push(x));

                    const heigh = average(highValues);
                    const low = average(lowValues);

                    let higherValues = [], lowerValues = [];
                    values.forEach(x => {
                        if (x > heigh)
                            higherValues.push(x);
                        else if (x < low)
                            lowerValues.push(x);
                    });

                    // 高低點，用較高/低的平均，而不是最高/低
                    const top = higherValues.length > 0 ? average(higherValues) : Math.max(...highValues);
                    const bottom = lowerValues.length > 0 ? average(lowerValues) : Math.min(...lowValues);

                    // console.log('setQuarterLevel hub:', hub);
                    // console.log('top:', top, highValues);
                    // console.log('bottom:', bottom, lowValues);
                    return [
                        toFloatFixed(top, precision),
                        toFloatFixed(heigh, precision),
                        toFloatFixed(low, precision),
                        toFloatFixed(bottom, precision)
                    ];
                };

                // 價格最高/中心/最低紀錄
                const highestPrice = Math.max(...klineData.map(x => x.highest)),
                    lowestPrice = Math.min(...klineData.map(x => x.lowest)),
                    // hubPrice = toFloatFixed((klineData.map(x => x.closing).reduce((sum, v) => sum + v, 0) / klineData.length));
                    hubPrice = toFloatFixed(average(klineData.map(x => x.closing)));
                // console.log('hubPrice:', hubPrice);
                return {
                    price: [highestPrice, hubPrice, lowestPrice],
                    closingQuarterLevel: setQuarterLevel(klineData.map(x => x.closing), hubPrice, this._precision),
                };
            });
    }

    updateOscillation(interval) {
        let mins = DelayMins[interval];
        const updateOscillation = () => {
            switch (interval) {
                case Interval.WEEK_1: return this._updateOscillation(Interval.MINUTES_30, mins / 30);
                case Interval.DAYS_3: return this._updateOscillation(Interval.MINUTES_15, mins / 15);
                case Interval.DAYS_1: return this._updateOscillation(Interval.MINUTES_15, mins / 15);
                case Interval.HOURS_12: return this._updateOscillation(Interval.MINUTES_15, mins / 15);
                case Interval.HOURS_08: return this._updateOscillation(Interval.MINUTES_15, mins / 15);
                case Interval.HOURS_06: return this._updateOscillation(Interval.MINUTES_15, mins / 15);
                case Interval.HOURS_04: return this._updateOscillation(Interval.MINUTES_15, mins / 15);
                case Interval.HOURS_02: return this._updateOscillation(Interval.MINUTES_05, mins / 5);
                case Interval.HOURS_01: return this._updateOscillation(Interval.MINUTES_01, mins);
                case Interval.MINUTES_30: return this._updateOscillation(Interval.MINUTES_01, mins);
                case Interval.MINUTES_15: return this._updateOscillation(Interval.MINUTES_01, mins);
                default:
                    interval = Interval.MINUTES_05;
                    console.log(interval, '非預設時間，請進行設定:目前回傳', interval);
                    return this._updateOscillation(Interval.HOURS_01, 5);
            }
        }
        return updateOscillation();//.then((result) => this.oscillation[interval] = result);
    }
}

module.exports = MarketWatcher;