const MarketWatcher = require("./Marketwatcher");
const MarketTrader2 = require("./MarketTrader");
const StockManager = require("./StockManager");
const { Interval, DelayMins } = require("../data/binance/request");
const market = require("../data/binance/market");
const { getPrecisionPrice, getPrecisionQuanity } = require("../data/binance/exchangeInfo");
const { oscillation } = require("../data/binance/historicalAnalysis");
const { logcat } = require("./dex/GoogleSpreadsheetRecord");

const PRICE_TREND = {
    BreakDown: 0,
    SuddlyDescrease: 1,
    PositiveDescrease: 2,
    Decrease: 3,
    GentleDecrease: 4,
    GentleIncrease: 5,
    Increase: 6,
    PositiveIncrease: 7,
    SuddlyIncrease: 8,
    BreakOut: 9,
};

class DashOscillationTrader {

    constructor(ownerId, symbol, quoteAsset) {
        this._ownerId = ownerId;
        this._symbol = symbol;

        this._marketWatcher = new MarketWatcher(ownerId, symbol);
        this._marketTrader = new MarketTrader2(ownerId, symbol, quoteAsset, this._marketWatcher);
        this._stockManager = new StockManager(symbol);

        this._toPrice = (value, stepFix) => getPrecisionPrice(symbol, value, stepFix);
        this._toQty = (value) => getPrecisionQuanity(symbol, value);

        this._tradeInterval;

        this._dashOscillation;
        this._dashUpdateTime = 0;
        this._oscillationLevel = 6;//todo 先寫死3天
        this._dashOscillationLevel = 2;// todo 先寫死

        this._emaPrice = 0;
        this._emaLength = 15;

        this._trendCounts = new Array(10).fill(0);
    }

    // 振盪交易
    oscillationTrade(earn) {
        this.setEMAPrice()//先做 ema price 的設定後
            .then(() => this._oscillationFindBy(earn, this._oscillationLevel))//，再找合適的振盪
            .then(result => {
                if (result == null) {
                    return Promise.reject();
                }

                const { oscillation, index } = result;

                console.log(oscillation);

                // this._oscillationLevel = Math.min(0, index - 1);// 紀錄時往前一格

                // todo 硬拆結果 quanity 壞了…先補一個用 heigh 暫用，之後再改
                const [highestPrice, hubPrice, lowestPrice] = oscillation.price;
                let quanity = this._marketTrader.getFunds(hubPrice) / hubPrice;

                // 設定好倉位
                this._stockManager.setQuarterLevelStock(oscillation.closingQuarterLevel, quanity);

                const stock = this._stockManager.getStock(hubPrice);
                if (stock) {
                    let { price, filling } = stock;
                    // todo 去要list, 再更新交易狀態;
                    if (filling != 0) {
                        return {
                            price: price.avg,
                            filling: -filling,
                            filled: filling
                        }
                    }
                }
            })
            .then((ticketResult) => this._tradeResult(ticketResult))
            .then(() => this._oscillationTrade(earn))
            .catch(() => {
                console.log('找其他交易對');
            });
    }

    setEMAPrice() {
        const lastUpdateTime = 0;
        const currTime = Date.now();
        const onlyResult = true;

        let interval = Interval.MINUTES_01, limit = this._emaLength;

        return market.kline(this._ownerId, this._symbol, lastUpdateTime, currTime, interval, limit, onlyResult)
            .then((rawData) => {
                let closingList = rawData.map((data) => data[market.KLINE.Closing]);
                closingList.pop();//最後一個扔掉，因為updatePirce 時會加入最新的，這個值基本不會差太多才對
                this._emaPrice = this._toPrice(
                    closingList.reduce((prev, curr) => prev + curr, 0) / (limit - 1)//limit-1是因為closingList.pop()的關係
                );
            });
    }

    _oscillationFindBy(earn, index = 0) {
        const intervalList = [
            Interval.MINUTES_30,
            Interval.HOURS_01,
            Interval.HOURS_02,
            Interval.HOURS_08,
            Interval.HOURS_12,
            Interval.DAYS_1,
            Interval.DAYS_3,
            // Interval.WEEK_1
        ], interval = intervalList[index];//todo 可能會因為交易時間不同導致交易的振盪不同，可能要做一個 timeout 準備交換

        return this._marketWatcher
            .updateOscillation(interval)
            .then(oscillation => {
                // 從分佈抓高低點
                const [top, heigh, low, bottom] = oscillation.closingQuarterLevel;
                const [highestPrice, hubPrice, lowestPrice] = oscillation.price;
                const funds = this._marketTrader.getFunds(hubPrice);
                const quanity = funds / hubPrice;
                console.log(top, '/', heigh, '-', low, '/', bottom, 'field:', this._toPrice(heigh - low), '*', this._toQty(quanity), '=', ((heigh - low) * quanity).toFixed(2));

                // 抓變動量最少能賺 earn 鎂的
                if ((heigh - low) * quanity > earn) {
                    console.log(interval, ': earn - ', this._toPrice((heigh - low) * quanity), '[', earn, ']');
                    return { oscillation, index };
                }
                else {
                    index++;

                    if (index < intervalList.length)
                        return this._oscillationFindBy(earn, index);
                    else
                        return null;
                }
            });
    };

    updateDashOscillation(dashEarn) {
        if (Date.now() - this._dashUpdateTime < 15 * 60 * 1000)
            return Promise.resolve(this._dashOscillation);//todo 這邊的 currPrice 應該會保留在klineData 裡，所以應該要做到立刻拿currPrice，至少getCiurrPrice 可以拿到比較新一點的吧？

        this._dashUpdateTime = Date.now();
        // return this._oscillationFindBy(dashEarn, this._oscillationLevel)
        //     .then(({ oscillation, index }) => {
        //         this._oscillationLevel = index - 1;// 紀錄時往前一格
        //         console.log(dashEarn, 'dash:', oscillation);
        //         return this._dashOscillation = oscillation;
        //     });
        // ===> 把振盪做大後，因為最近是突然掉下來並保持在底盤，所以3天跟1天的差距很大，試著直接改用 index-1 後紀錄下來的 this._oscillationLevel
        const intervalList = [
            Interval.MINUTES_30,
            Interval.HOURS_01,
            Interval.HOURS_02,
            Interval.HOURS_08
            // ], interval = intervalList[Math.min(intervalList.length - 1, this._oscillationLevel)];
        ], interval = intervalList[Math.min(intervalList.length - 1, this._dashOscillationLevel)];

        return this._marketWatcher
            .updateOscillation(interval)
            .then(oscillation => {
                // 從分佈抓高低點
                const [top, heigh, low, bottom] = oscillation.closingQuarterLevel;
                const [highestPrice, hubPrice, lowestPrice] = oscillation.price;
                const funds = this._marketTrader.getFunds(hubPrice);
                const quanity = funds / hubPrice;
                console.log(interval, ':', top, '-', bottom, 'field:', this._toPrice(top - bottom), '*', this._toQty(quanity), '= earn', ((top - bottom) * quanity).toFixed(2), '[', dashEarn, ']');
                return this._dashOscillation = oscillation;
            });
    }

    trend(stockPrice, price, igoneBreak = false) {
        this._emaPrice = this._toPrice((this._emaPrice * (this._emaLength - 1) + price * 2) / (this._emaLength + 1));

        console.log('ema price:', this._emaPrice);

        // 比最低倉位更低
        if (stockPrice.bottom > price && !igoneBreak)
            return PRICE_TREND.BreakDown;

        // 因為只有一個倉位所以沒關係，但多倉位就要考慮getStock 拿到的是最低倉位
        if (stockPrice.top < price && !igoneBreak)
            return PRICE_TREND.BreakOut;

        const trendRatio = (price - this._emaPrice) / (stockPrice.top - stockPrice.bottom);
        console.log(Math.round(trendRatio * 10000) / 100, '%');

        const isDecrease = trendRatio < 0;
        // 消極交易
        if (Math.abs(trendRatio) < 0.01)
            return isDecrease ? PRICE_TREND.GentleDecrease : PRICE_TREND.GentleIncrease;
        // 暴漲/跌
        if (Math.abs(trendRatio) > 0.2)
            return isDecrease ? PRICE_TREND.SuddlyDescrease : PRICE_TREND.SuddlyIncrease;
        // 積極交易
        if (Math.abs(trendRatio) > 0.05)
            return isDecrease ? PRICE_TREND.PositiveDescrease : PRICE_TREND.PositiveIncrease;
        return isDecrease ? PRICE_TREND.Decrease : PRICE_TREND.Increase;
    }

    _countTrend(priceTrend, fourceRest = false) {
        // 以changePoint 當作趨勢變換的臨界值，先保留之前的計數
        const changePoint = 3;

        // 強制歸0，然後帶入的趨勢最終為1 (如果跑 rest 的話可以當作標記)
        if (fourceRest)
            this._trendCounts = new Array(10).fill(0);
        // 趨勢改變了，全部重置
        else if (this._trendCounts[priceTrend] >= changePoint) {
            let temp = this._trendCounts[priceTrend];
            this._trendCounts = new Array(10).fill(0);
            this._trendCounts[priceTrend] = temp;
        }

        this._trendCounts[priceTrend]++;
        console.log('price trend:', this._trendCounts, `[${priceTrend}]`);
    }

    _oscillationTrade(earn) {
        this._marketWatcher
            .updateCurrPrice()
            .then(currPrice => {
                const { price, filling, filled, storage } = this._stockManager.getStock(currPrice);
                console.log('=======', price.top, '|(h:', price.heigh, ',g:', price.gain, ')| [', currPrice, '] |(b:', price.base, ',a', price.avg, ')| ', price.bottom, ' =======');
                console.log('\t---', this._toQty(filled), '(', filling, ') /', this._toQty(storage), '---', this._marketTrader.getFunds(currPrice));

                const priceTrend = this.trend(price, currPrice);
                this._countTrend(priceTrend);

                switch (priceTrend) {
                    case PRICE_TREND.SuddlyDescrease:
                        /** 處理三個情況:
                         *  1. 連續第三次明顯下跌，在未回穩前冒險搶買一單; ==> 做在 increase 那邊連漲三次才買
                         *  2. 用 dash振盪 來檢查，價格尚在 heigh 之上先搶賣清倉賺一點;
                         *  3. 檢查是否跌破 last , 並進行認賠。
                         */
                        // const tradingPrice = this._toPrice(currPrice, -5);
                        const tradingPrice = this._toPrice(currPrice, 0);// todo 測試暫時不
                        return this._dropTickets(tradingPrice)
                            .then(() => this.updateDashOscillation(earn / 3))
                            .then((oscillation) => {
                                const [top, heigh, low, bottom] = oscillation.closingQuarterLevel;

                                // 用短線振盪的 price>heigh 當作條件，搶高點優先賣掉
                                if (filled > 0 && currPrice > top)
                                    return this._clearance(tradingPrice);

                                // 這邊檢查如果破last 會認賠的話就會全賣掉
                                if (currPrice < bottom)
                                    return this._clearance(tradingPrice);//todo

                                // 低於 avg 就快速買1/5倉位進來
                                if (filled === 0 && this._trendCounts[PRICE_TREND.SuddlyDescrease] >= 3)//todo
                                    return this._makeStockTradeTicket(tradingPrice, 5);
                            })
                            .then(() => this._delayResultTicketThenLoop(tradingPrice, earn));

                    case PRICE_TREND.SuddlyIncrease:
                        // 暴漲，那很可能有機會飛，用短線振盪先買一點，只要不要超過高點
                        if (filled == 0) {
                            // 覺得filling 這時候不太實際，還是先撤單
                            return this._dropTickets(currPrice)
                                .then(() => this.updateDashOscillation(earn / 3))
                                .then((oscillation) => {
                                    const [top, heigh, low, bottom] = oscillation.closingQuarterLevel;
                                    console.log('暴漲搶買，但需低於 dash heigh', heigh)
                                    if (currPrice < heigh) {
                                        // const tradingPrice = this._toPrice(currPrice, 5);
                                        const tradingPrice = this._toPrice(currPrice);//測試暫時不
                                        const fillingQty = this._stockManager.fill(tradingPrice, earn / 3, 5);// 不需買太多，有機會而已
                                        if (fillingQty > 0)
                                            this._marketTrader.buyIn(tradingPrice, fillingQty)
                                                .then((ticketResult) => this._tradeResult(ticketResult))
                                                .then(() => this._delayResultTicketThenLoop(tradingPrice, earn));
                                    }
                                    // 價格太高，不適合再買入了
                                    else this._delayResultTicketThenLoop(currPrice, earn);
                                });
                        }
                        else this._leapingOverTrade(price, earn);// todo 有庫存，放去跑看看鯉躍龍門
                        // // 這邊原本想立刻賣，但發現其實後來會繼續爬上去, 所以我先註解掉了，要再觀察這種連續上漲的情況 todo再看怎麼做比較好，先用連續暴漲三次就賣為主
                        // if (filled > 0 && this._trendCounts[PRICE_TREND.SuddlyIncrease] == 3) {
                        //     // // const tradingPrice = this._toPrice(currPrice, 5);
                        //     // const tradingPrice = this._toPrice(currPrice);//測試暫時不
                        //     // this._clearance(tradingPrice)
                        //     //     .then(() => this._delayResultTicketThenLoop(tradingPrice, earn));
                        //     // return;
                        //     break;// ===> 有沒有賺給 stockManager 判斷就好
                        // }==>todo 看是不是要做給 PositiveIncrease，因為後來覺得倉位拉很大的時候比較穩定

                        // 乾脆都不要賣(？   todo 或者需要有一個預測的賣點 26107賣掉後，連漲3次到26132看起來不錯，但實際最高是漲到 26203，如果能預測一下也許會很讚
                        return this._delayResultTicketThenLoop(currPrice, earn);

                    case PRICE_TREND.PositiveDescrease:
                        const count = this._trendCounts[PRICE_TREND.PositiveDescrease];
                        // ===> 如果 count>15就是不斷跌上去，也許能做點什麼
                        //      目前不斷跌就是抽身先賣清倉
                        if (count > 7 && filled > 0)//不再處理正常的交易
                            // return this._delayResultTicketThenLoop(currPrice, earn);
                            // return this._clearance(this._toPrice(currPrice, -5))//往下5個step 價位，要拼賣出
                            return this._clearance(this._toPrice(currPrice))// todo 測試暫時不往下5個step 價位，要拼賣出
                                .then(() => this._rest(priceTrend, Interval.MINUTES_05, earn));
                        // 連跌三次的話有機會止跌，正常走 stockManager.trade
                        else if (count === 3 && filled === 0)
                            break;
                        // 積極下跌的話，先暫時觀察, 怕走進 stockManager.trade
                        else
                            return this._delayResultTicketThenLoop(currPrice, earn);

                    case PRICE_TREND.PositiveIncrease:
                        // 處理下跌後快速上升
                        if (
                            // 先有下跌
                            this._trendCounts[PRICE_TREND.SuddlyDescrease]
                            + this._trendCounts[PRICE_TREND.PositiveDescrease]
                            + this._trendCounts[PRICE_TREND.Descrease] > 7
                            // 連漲3次
                            && this._trendCounts[PRICE_TREND.PositiveIncrease] == 3
                            && filled === 0
                        )
                            return this._dashBuyIn(currPrice, earn, 5)
                                .then(() => this._delayResultTicketThenLoop(currPrice, earn));

                        // 貪住不要賣，要賣的話等 Increase 再賣
                        return this._delayResultTicketThenLoop(currPrice, earn);
                    case PRICE_TREND.Increase:
                        // 處理下跌後快速上升
                        if (
                            // 先有下跌
                            this._trendCounts[PRICE_TREND.SuddlyDescrease]
                            + this._trendCounts[PRICE_TREND.PositiveDescrease]
                            + this._trendCounts[PRICE_TREND.Descrease] > 7
                            // 連漲3次
                            && this._trendCounts[PRICE_TREND.Increase] == 3
                            && filled === 0
                        )
                            return this._dashBuyIn(currPrice, earn, 5)
                                .then(() => this._delayResultTicketThenLoop(currPrice, earn));


                        // //一直漲會漲到高點然後狂跌, 不要再繼續買 todo 或者需要過半倉位有賺個幾鎂就趕快獲利
                        // if (this._trendCounts[PRICE_TREND.Increase] > 7)
                        //     return this._delayResultTicketThenLoop(currPrice, earn);

                        // ===> 如果 count>15就是不斷漲上去，也許能做點什麼
                        //      目前覺得，如果 filled>0 可以守住價格，等緩下來再賣;
                        //      或是貪心一點，趁這個機會用dash 抓 price<heigh 的買一單
                        //      這個做在 Increase+GentleIncrease>3, count>7就執行
                        // if (this._trendCounts[PRICE_TREND.Increase] + this._trendCounts[PRICE_TREND.GentleIncrease] > 3)
                        if (this._trendCounts[PRICE_TREND.PositiveIncrease] + this._trendCounts[PRICE_TREND.Increase] > 7) {//不再處理正常的交易
                            console.log('持續上漲');
                            if (filling === 0 && filled === 0)
                                // 這邊短線收購是用low
                                return this._dashBuyIn(currPrice, earn, 5)
                                    .then(() => this._delayResultTicketThenLoop(currPrice, earn));
                            else
                                return this._delayResultTicketThenLoop(currPrice, earn);
                        }

                        // 積極交易的話，正常走 stockManager.trade
                        break;

                    case PRICE_TREND.Decrease:
                        // 放這邊的條件可能比較好，至少不會繼續衝，有機會又會再往下跌
                        // 快速上漲3次以上，可能疲乏，後續有機會往下跌
                        // if (filled > 0 && filling != 0 && this._trendCounts[PRICE_TREND.SuddlyIncrease] >= 3) {
                        if (filled > 0 && this._trendCounts[PRICE_TREND.SuddlyIncrease] >= 3) {

                            if (filling == 0) {
                                // const tradingPrice = this._toPrice(currPrice, 5);// 向上推5格，不求立刻賣掉
                                const tradingPrice = this._toPrice(currPrice);// todo 測試暫時不向上推5格，不求立刻賣掉
                                this._dashSellOut(tradingPrice, price.gain, earn, 5)// 賣1/5, 不需太多，有機會而已
                                    .then(() => this._delayResultTicketThenLoop(tradingPrice, earn));
                                return;
                                // ===> 要考慮的是會被甩飛的問題
                            }
                            // filling 不為0就是有掛單，有賣單就暫時先正常走流程; 但有買單就是急漲，要撤單
                            else if (filling > 0) {
                                this._dropTickets(currPrice);
                                // ===> 下一輪再決定要不要賣
                                return;
                            }
                        }
                        break;

                    case PRICE_TREND.GentleDecrease:

                        // 跌緩，無其他掛單，做短線買入
                        if (filling === 0 && (filled === 0 || this._trendCounts[PRICE_TREND.GentleDecrease] % 10 === 9))
                            return this._dashBuyIn(currPrice, earn, 5)
                                .then(() => this._delayResultTicketThenLoop(currPrice, earn));

                        // 走大振盪的正常流程
                        break;

                    case PRICE_TREND.GentleIncrease:
                        // 漲緩，有購買庫存，且無其他掛單，做短線賣出
                        if (filling === 0 && filled > 0) {
                            const doSell = this._trendCounts[PRICE_TREND.GentleIncrease] % 10 === 3;//不要太快決定賣出，3輪都是緩漲再賣一點
                            if (doSell)
                                return this._dashSellOut(currPrice, price.gain, earn, 5)
                                    .then(() => this._delayResultTicketThenLoop(currPrice, earn));
                        }
                        break;

                    case PRICE_TREND.BreakOut:
                        // 抓基底，來做鯉躍龍門
                        var breakOutPrice = price;
                        // 大漲時做鯉躍龍門(但不再加倉避免被假訊號騙)，從噴發前的最低均價會基準，噴發後紀錄最高價格-最低均價為上漲區間，只要跌到區間的80%即可賣出
                        // 擊穿高點，可以做鯉躍龍門，從噴發前的最低均價會基準，噴發後紀錄最高價格-最低均價為上漲區間，只要跌到區間的80%即可賣出
                        // 真正能做鯉躍龍門的應該是擊破程度的暴漲，能在 PRICE_TREND.SuddlyIncrease 內設定未超過100%的漲幅都不是鯉躍龍門
                        var fillingQty = 0;
                        // 前2次都是猛衝，那很可能要飛了
                        if (this._trendCounts[PRICE_TREND.SuddlyIncrease] >= 2) {
                            // 有機會飛，梭哈
                            fillingQty = this._stockManager.fill(currPrice, earn, 1);
                        }
                        else {
                            // 感覺可以，買一半
                            fillingQty = this._stockManager.fill(currPrice, earn, 2);//用一半倉位來抓
                        }
                        if (fillingQty > 0) {
                            // const tradingPrice = this._toPrice(currPrice, 5);//向上5階價位，搶買
                            const tradingPrice = this._toPrice(currPrice, 0);// todo 測試暫時不向上5階價位，搶買
                            this._marketTrader.buyIn(tradingPrice, fillingQty)
                                .then((ticketResult) => this._tradeResult(ticketResult))
                                .then(() => this._leapingOverTrade(breakOutPrice, earn));
                            return;
                        }
                        return this._leapingOverTrade(breakOutPrice, earn);

                    case PRICE_TREND.BreakDown:
                        // 如果前面有大跌的情況了，直接清倉不猶豫
                        if (this._trendCounts[PRICE_TREND.SuddlyDescrease] > 2)
                            // return this._clearance(this._toPrice(currPrice, -5))//往下5個step 價位，要拼賣出
                            return this._clearance(this._toPrice(currPrice, 0))// todo 測試暫時不往下5個step 價位，要拼賣出
                                // .then(() => this._rest(priceTrend, Interval.MINUTES_15, earn));
                                .then(() => this._breakDownTrade(price, earn));

                        // 沒事的話就觀望，炸了就撤單
                        console.log('已擊破', this._trendCounts[PRICE_TREND.BreakDown], '次');
                        // if (this._trendCounts[PRICE_TREND.BreakDown] < 15) {
                        //     // 繼續正常走 stockManager.trade，如果只是低空徘徊的話，還是有機會漲回來
                        //     // 暴跌時要等跌出last 才會直接清倉
                        //     break;
                        // }
                        // else {
                        //     // 擊破後沒有回升，清倉先休息
                        //     this._clearance(currPrice)
                        //         .then(() => this._rest(priceTrend, Interval.HOURS_01, earn));
                        // }
                        // return;
                        if (this._trendCounts[PRICE_TREND.BreakDown] > 3) {
                            return this._breakDownTrade(price, earn);
                        }
                        break;
                }

                this._makeStockTradeTicket(currPrice, 5)
                    .then(() => this._delayResultTicketThenLoop(currPrice, earn));
            });
    }

    _delayResultTicketThenLoop(tradingPrice, earn) {
        this._tradeInterval && clearTimeout(this._tradeInterval);

        // 結算先前的掛單，完成後才繼續執行現價交易
        this._tradeInterval = setTimeout(() => {
            this._marketTrader.result(tradingPrice)
                .then((ticketResult) => this._tradeResult(ticketResult))
                .then(() => this._oscillationTrade(earn));
        }, 60 * 1000);
    }

    _tradeResult(ticketResult, msg = '') {
        if (!ticketResult)
            return Promise.resolve();

        const { price, filled, filling } = ticketResult;
        const stock = this._stockManager.getStock(price);

        if (filling == 0 && filled == 0) {
            if (stock.filling != 0)
                return this._recordOnGoogleSheet(stock, price);
            return Promise.resolve();
        }

        if (msg) console.log(msg);
        console.log('ticketResult:', ticketResult);

        this._stockManager.result(ticketResult, price);

        return this._recordOnGoogleSheet(stock, price);
    }

    _makeStockTradeTicket(tradingPrice, times = 5) {
        const fillingQty = this._stockManager.trade(tradingPrice, times);

        if (fillingQty > 0) //有breakDown 就先不要買入 && this._trendCounts[PRICE_TREND.BreakDown] == 0) todo 這個會卡 filling，所以又不能擋…
            return this._marketTrader.buyIn(tradingPrice, fillingQty)
                .then((ticketResult) => this._tradeResult(ticketResult));

        if (fillingQty < 0)
            return this._marketTrader.sellOut(tradingPrice, -fillingQty)
                .then((ticketResult) => this._tradeResult(ticketResult));

        // 都沒交易, 就繼續走流程
        return this._marketTrader.result(tradingPrice)
            .then((ticketResult) => this._tradeResult(ticketResult));
    }

    // 出清倉位庫存
    _clearance(tradingPrice) {
        return this._dropTickets()
            .then(() => {
                const fillingQty = this._stockManager.clean();
                if (fillingQty < 0)
                    return this._marketTrader.sellOut(tradingPrice, -fillingQty)
                        .then((ticketResult) => this._tradeResult(ticketResult, '!!!! 出清倉位庫存 !!!!!'));
            });
    }

    // 撤單
    _dropTickets() {
        // 目前沒辦法精細指定 orderId 撤單，先一次清全部
        return this._marketTrader.dropAllTickets()
            .then((ticketResult) => this._tradeResult(ticketResult, '!!! 撤消所有訂單 !!!'));
    }

    // 短線出售
    _dashSellOut(tradingPrice, gain, earn, times = 5) {//gain 保底
        return this.updateDashOscillation(earn / 3)
            .then((oscillation) => {
                const [top, heigh, low, bottom] = oscillation.closingQuarterLevel;
                gain = Math.min(gain, top);
                console.log('短線出售價:', gain);
                if (tradingPrice > gain) {
                    const fillingQty = this._stockManager.clean(tradingPrice, times);
                    if (fillingQty < 0)
                        this._marketTrader.sellOut(tradingPrice, -fillingQty)
                            .then((ticketResult) => this._tradeResult(ticketResult, `漲緩: 現價高於 ${top} ,先清 1/${times}倉`));
                }
            });
    }

    // 短線收購
    _dashBuyIn(tradingPrice, earn, times = 5) {
        // 有breakDown 就先不要買入
        if (this._trendCounts[PRICE_TREND.BreakDown] > 0)
            return Promise.resolve();

        return this.updateDashOscillation(earn / 3)
            .then((oscillation) => {
                const [top, heigh, low, bottom] = oscillation.closingQuarterLevel;
                console.log('短線收購價:', bottom);
                // 低於low
                if (tradingPrice < bottom) {
                    const fillingQty = this._stockManager.fill(tradingPrice, earn / 3, times);
                    if (fillingQty > 0)
                        this._marketTrader.buyIn(tradingPrice, fillingQty)
                            .then((ticketResult) => this._tradeResult(ticketResult, `跌緩: 現價低於 ${bottom} ,先買 1/${times}倉`));
                }
            });
    }

    // 鯉躍龍門 (DashOscillation 是單一倉位的紀錄方式所以可以用，多倉位時要另外考慮其他可能性)
    _leapingOverTrade(stockPrice, earn, highestPrice = 0) {
        this._tradeInterval && clearTimeout(this._tradeInterval);
        //todo 測看看是不是向上漲再掉下來2成就賣光
        console.log('鯉躍龍門');
        this._tradeInterval = setTimeout(() => {
            this._marketWatcher
                .updateCurrPrice()
                .then(currPrice => {
                    const priceTrend = this.trend(stockPrice, currPrice, true);// igoneBreak，已經突破的話就可以無視，繼續觀察趨勢
                    this._countTrend(priceTrend);

                    // // 期間最高價格
                    // if (highestPrice < currPrice)
                    //     highestPrice = currPrice;

                    // // riseRatio 應該都用倍數來算
                    // const field = stockPrice.top - stockPrice.bottom;
                    // const riseRatio = (highestPrice - stockPrice.bottom) / field;
                    // console.log('riseRatio:', riseRatio);

                    // const tradingPrice = this._toPrice(currPrice, -5);//往下5個step 價位，要拼賣出
                    const tradingPrice = this._toPrice(currPrice);// todo 測試暫時不往下5個step 價位，要拼賣出

                    // 突然爆跌就先賣了吧 (這邊 pricetrend 可能已經無效了, 但如果還能出現就代表在跌回原本的振盪區中)
                    if (priceTrend == PRICE_TREND.SuddlyDescrease) {
                        return this._clearance(tradingPrice)
                            .then(() => this.oscillationTrade(earn));
                    }
                    // // 如果超過1.5倍
                    // else if (riseRatio > 1.5) {
                    //     // 上去後，再往下掉大約8成就賣光
                    //     const sellRatio = ((currPrice - stockPrice.bottom) / field) / riseRatio;
                    //     console.log('超過1.5倍,', sellRatio, '正在等待漲幅的8成出售');
                    //     if (sellRatio < 0.8) {
                    //         console.log('鯉躍龍門獲利！');
                    //         return this._clearance(tradingPrice)
                    //             .then(() => this._oscillationTrade(earn))
                    //             .then(() => this._delayResultTicketThenLoop(tradingPrice, earn));
                    //     }
                    // }
                    // 如果變成比較和緩的價格狀態
                    else if (this._trendCounts[PRICE_TREND.GentleDecrease]
                        + this._trendCounts[PRICE_TREND.Decrease]
                        + this._trendCounts[PRICE_TREND.PositiveDescrease]
                        + this._trendCounts[PRICE_TREND.Increase]
                        + this._trendCounts[PRICE_TREND.GentleIncrease] >= 7) {
                        // 可能衝不上去了，先回歸振盪交易流程
                        return this.oscillationTrade(earn);
                    }
                    // 無盡的飆漲，重整振盪場域，確認是否範圍抓太小
                    else if (this._trendCounts[PRICE_TREND.SuddlyIncrease > 7])
                        return this.oscillationTrade(earn);
                    // todo PositiveIncrease 的流程感覺突破後價格有拉到很不錯的位置，然後一直拉上去挺不錯的，可以考慮加進來；好幾次掉到Increase 又被拉回去Positive，價格拉上去真的很不錯
                    //          但仔細看，鯉躍龍門本來就不會隨便賣掉，不走原本的方法，所以也不會很快就賣掉;上面>15的判斷看起來就可以

                    // 
                    this._leapingOverTrade(stockPrice, earn, highestPrice);
                });
        }, 60 * 1000);
    }

    // 擊破後交易: 超過15次比倉位最低更低時，觀察並停止購入
    _breakDownTrade(stockPrice, earn) {
        this._tradeInterval && clearTimeout(this._tradeInterval);
        this._tradeInterval = setTimeout(() => {
            this._marketWatcher
                .updateCurrPrice()
                .then(currPrice => {
                    const priceTrend = this.trend(stockPrice, currPrice, true);// igoneBreak，已經擊破的話就可以無視，繼續觀察趨勢
                    this._countTrend(priceTrend);

                    // 穩定上漲，恢復 oscillationTrade
                    if (this._trendCounts[PRICE_TREND.Increase]
                        + this._trendCounts[PRICE_TREND.PositiveIncrease]
                        + this._trendCounts[PRICE_TREND.SuddlyIncrease] > 15
                    ) this.oscillationTrade(earn);

                    // 沒有回升，直接清倉, 恢復 oscillationTrade
                    else if (this._trendCounts[PRICE_TREND.Decrease]
                        + this._trendCounts[PRICE_TREND.PositiveDescrease]
                        + this._trendCounts[PRICE_TREND.SuddlyDescrease] > 15
                    ) this._clearance(currPrice)// 擊破後沒有回升，清倉
                        .then(() => this.oscillationTrade(earn));

                    // 繼續觀察, 若回升至倉位 bottom 以上會交易; 若跌破last 便清倉認賠
                    else this._makeStockTradeTicket(currPrice, 5)
                        .then(() => this._breakDownTrade(stockPrice, earn));

                });
        }, 60 * 1000);
    }

    _rest(priceTrend, interval, earn) {
        // 重置，並標記 priceTrend 的count 為1
        this._countTrend(priceTrend, true);

        const delayMins = DelayMins[interval];
        console.log(delayMins, '分鐘後再來');
        this._tradeInterval && clearTimeout(this._tradeInterval);
        this._tradeInterval = setTimeout(() => {
            console.log('繼續交易，檢查交易振盪');
            this.oscillationTrade(earn);
        }, delayMins * 60 * 1000);
    }

    _recordOnGoogleSheet(stock, price) {
        // 在測Accounting 的lock free檢查，以及test 買入為什麼會存雙倍的問題
        const date = new Date(),
            symbol = this._symbol,
            creation = `${date.toLocaleDateString()} ${date.toTimeString()}`,
            funds = this._marketTrader.getFunds(price),
            assets = this._marketTrader.getAssets();
        return logcat(symbol, creation, price, stock, funds, assets);
    }
}

module.exports = DashOscillationTrader;