LocalStorage = require('node-localstorage').LocalStorage,
    localStorage = new LocalStorage('./scratch');
const { getPrecisionPrice } = require('../data/binance/exchangeInfo');
class Accounting {
    constructor(symbol, quoteAsset) {
        this.symbol = symbol;
        // 交易目標貨幣
        this.baseAssets = {
            free: 0,
            lock: 0
        };
        // 資本使用貨幣
        this.quoteAssets = {
            free: quoteAsset,
            lock: 0
        };

        this._dataSave = () => {
            let saveData = JSON.stringify({ base: this.baseAssets, quote: this.quoteAssets });
            localStorage.setItem(`${symbol}_ACCOUNTING`, saveData);
        };
        this._dataLoad = () => {
            let loadData = localStorage.getItem(`${symbol}_ACCOUNTING`);
            if (loadData) {
                let data = JSON.parse(loadData);
                this.baseAssets = data.base;
                this.quoteAssets = data.quote;
            }
        };
        // 有存檔時，會直接覆蓋預設給的 quoteAsset
        this._dataLoad();
    }
    getFunds(price) {
        return getPrecisionPrice(this.symbol, this.getQuoteAssets() + this.getBaseAssets() * price);
    }
    getBaseAssets(onlyFree = false) {
        if (onlyFree) return this.baseAssets.free;
        return this.baseAssets.lock + this.baseAssets.free;
    }
    getQuoteAssets(onlyFree = false) {
        if (onlyFree) return this.quoteAssets.free;
        return this.quoteAssets.lock + this.quoteAssets.free;
    }
    buy(quote) {
        console.log('buy:', quote);
        // 買單 凍結住quote預算
        this.quoteAssets.lock += quote;
        // 錢沒有消失，只是變成凍結的樣子
        this.quoteAssets.free -= quote;
        this._roundFixed();
        this._dataSave();
    }
    bought(base, quote) {
        console.log('bought:', base, quote);
        // 完成買單 解凍quote預算
        this.quoteAssets.lock -= quote;
        // 新增購入的base
        this.baseAssets.free += base;
        if (this.quoteAssets.lock < 0) {
            console.log('this.quoteAssets:', this.quoteAssets);
            process.exit();
        }
        this._roundFixed();
        this._dataSave();
    }
    sell(base) {
        console.log('sell:', base);
        // 賣單 凍結住base預算
        this.baseAssets.lock += base;
        // 錢沒有消失，只是變成凍結的樣子
        this.baseAssets.free -= base;
        this._roundFixed();
        this._dataSave();
    }
    sold(base, quote) {
        console.log('sold:', base, quote);
        // 完成賣單 解凍base預算
        this.baseAssets.lock -= base;
        // 新增收入的quote
        this.quoteAssets.free += quote;
        if (this.baseAssets.lock < 0) {
            console.log('this.baseAssets:', this.baseAssets);
            process.exit();
        }
        this._roundFixed();
        this._dataSave();
    }
    dropBid(bidQuote, base, quote) {
        console.log('dropBid:', bidQuote, base, quote);
        // 先把quote 預算取消掉
        this.quoteAssets.lock -= bidQuote;
        this.quoteAssets.free += bidQuote;
        // 然後直接同步 base, quote 有實際完成交易的結果
        this.baseAssets.free += base;   // 買入的 executeQty
        this.quoteAssets.free -= quote; // 買入花費的 executeQty*price
        if (this.quoteAssets.lock < 0 || this.quoteAssets.free < 0) {
            console.log('this.baseAssets:', this.baseAssets);
            process.exit();
        }
        this._roundFixed();
        this._dataSave();
    }
    dropAsk(askBase, base, quote) {
        console.log('dropAsk: ', askBase, base, quote);
        // 先把base 預算取消掉
        this.baseAssets.lock -= askBase;
        this.baseAssets.free += askBase;
        // 然後直接同步 base, quote 有實際完成交易的結果
        this.baseAssets.free -= base;   // 賣出的 executeQty
        this.quoteAssets.free += quote; // 賣出獲得的 executeQty*price
        if (this.baseAssets.lock < 0 || this.baseAssets.free < 0) {
            console.log('this.baseAssets:', this.baseAssets);
            process.exit();
        }
        this._roundFixed();
        this._dataSave();
    }
    _roundFixed() {
        this.baseAssets = {
            free: this.precisionRound(this.baseAssets.free),
            lock: this.precisionRound(this.baseAssets.lock)
        };
        // 資本使用貨幣
        this.quoteAssets = {
            free: this.precisionRound(this.quoteAssets.free),
            lock: this.precisionRound(this.quoteAssets.lock)
        };
    }

    precisionRound(value, precision = 8) {
        if (precision === 0) return Math.round(value);
        const expand = Math.pow(10, precision);
        return Math.round(value * expand) / expand;
    };
}
module.exports = Accounting;