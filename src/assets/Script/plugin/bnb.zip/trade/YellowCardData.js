function YellowCardData() {
    this.questions = [];
    this.answers = [];
    this.players = {};
    this.rNum = 'YC-' + Math.round(Math.random() * 1000000).toString();
    this.dKey = Math.round(Math.random() * 100000000).toString();
    this.isWelcome = true;
}
YellowCardData.prototype = {
    addPlayer(guid_id, nickname, gameStatus) {
        // console.log('nickname:', nickname);
        // this.players[guid_id].nickname = nickname;
        // this.players[guid_id].gameStatus = gameStatus;
        // this.players[guid_id].coin = 0;
        // this.players[guid_id].yellowCard = 0;
        // this.players[guid_id].answerCards.length = 0;
        // this.players[guid_id].answerHandCards.length = 0;
        // this.players[guid_id].questionHandCards.length = 0;
        // this.players[guid_id].vote = 0;
        this.players[guid_id] = {
            serialNumber: 0,
            nickname: nickname,
            gameStatus: gameStatus,
            coin: 0,
            yellowCard: 0,
            answerCards: [],        // 答題時暫存的答案卡
            answerHandCards: [],
            questionHandCards: [],
            vote: 0,
            role: 0,
        };
    },
    delPlayer(guid_id) {
        delete this.players[guid_id];
    },

    getPlayerIds() {
        return Object.keys(this.players);
    },

    filterPlayerIdsByRole(role) {
        return this.getPlayerIds().filter((uniquneid) => this.players[uniquneid].role === role);
    },

    findMasterRolePlayerId(role) {
        return this.getPlayerIds().find((uniquneid) => this.players[uniquneid].role === role);
    },

    getPlayerHandCards(guid_id) {
        return {
            answerHandCards: this.players[guid_id].answerHandCards,
            questionHandCards: this.players[guid_id].questionHandCards
        };
    },

    filterPlayerIdsByGameStatus(gameStatus) {
        return this.getPlayerIds().filter((uniquneid) => this.players[uniquneid].gameStatus === gameStatus);
    },

    getGameStatusPlayers() {
        return this.getPlayerIds().map((uniquneid) => {
            const { nickname, gameStatus } = this.players[uniquneid];
            return { nickname, gameStatus };
        });
    },

    roundClear() {
        this.getPlayerIds().forEach((uniquneid) => {
            this.players[uniquneid].answerCards.length = 0;
            this.players[uniquneid].vote.length = 0;
        });
    },

    filterHoldPlayerIds() {
        return this.getPlayerIds().filter((uniquneid) => this.players[uniquneid].answerCards.length === 0);
    },

    addPlayerVote(guid_id) {
        this.players[guid_id].vote++;
    },
    addPlayerCoin(guid_id) {
        this.players[guid_id].coin++;
    },
    addPlayerYellowCard(guid_id) {
        this.players[guid_id].yellowCard++;
    },

    dropAnswerHandCards(guid_id, cards) {
        this.dropHandCard(this.players[guid_id].answerHandCards, cards);
    },
    dropQuestionHandCards(guid_id, cards) {
        this.dropHandCard(this.players[guid_id].questionHandCards, cards);
    },
    dropHandCard(handCards, cards) {
        return cards.every((card) => {
            return handCards.find((handCard, i, ary) => {
                if (handCard === card) {
                    ary.splice(i, 1);
                    return true;
                }
            });
        });
    },

    getHeighestVotePlayerId() {
        return this.getPlayerIds().sort((a, b) => this.players[a].vote - this.players[b].vote)[0];
    },

    getLosePlayer() {
        const getScore = ({ coin, yellowCard }) => coin - yellowCard;
        return this.getPlayerIds().sort((a, b) => getScore(this.players[a]) - getScore(this.players[b]))[0];
    },
};
module.exports = YellowCardData;
