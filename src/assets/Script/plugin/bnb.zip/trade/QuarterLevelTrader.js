LocalStorage = require('node-localstorage').LocalStorage,
    localStorage = new LocalStorage('./scratch');

const { getPrecisionPrice, getPrecisionQuanity } = require('../data/binance/exchangeInfo');
const { Interval } = require('../data/binance/request');
const Accounting = require("./Accounting2");
const QuarterLevelStock = require("./QuarterLevelStock");
const TicketOrder = require('./TicketOrder');
const Marketwatcher = require('./Marketwatcher');
const EMAPrice = require('./EMAPrice');

class QuarterLevelTrader {
    constructor(ownerId, baseSymbol, quoteSymbol, quoteAsset) {
        this._ownerId = ownerId;
        this._symbol = baseSymbol + quoteSymbol;
        const saveName = `${this._symbol}_TRADER`;

        this._ticketOrder = new TicketOrder(ownerId, this._symbol, 10);
        this._marketWatcher = new Marketwatcher(ownerId, this._symbol);

        this._emaPrice = new EMAPrice(ownerId, this._symbol);

        // 精度
        this._toPrice = (value, stepFix) => getPrecisionPrice(this._symbol, value, stepFix);
        this._toQty = (value) => getPrecisionQuanity(this._symbol, value);

        // 存檔
        this._dataSave = () => {
            // 理論上 stock.filled 應該要等於 accounting.baseAssets
            let saveData = JSON.stringify({
                tradePrice: {
                    gain: this._stock.price.gain,
                    avg: this._stock.price.avg,
                },
                baseAssets: this._accounting.baseAssets,
                quoteAssets: this._accounting.quoteAssets,
            });

            localStorage.setItem(saveName, saveData);
        };

        let avgPrice, gainPrice;

        let loadData = localStorage.getItem(saveName);
        if (loadData) {
            const { tradePrice, baseAssets, quoteAssets } = JSON.parse(loadData);
            // 帳戶資產
            this._accounting = new Accounting(baseSymbol, quoteSymbol, baseAssets, quoteAssets);

            // 設定倉位
            this._stock = new QuarterLevelStock(this._symbol);
            // 倉位庫存的變動紀錄
            this._stock.filled = baseAssets;

            avgPrice = tradePrice.avg;
            gainPrice = tradePrice.gain;
        }
        else {
            // 帳戶資產
            this._accounting = new Accounting(baseSymbol, quoteSymbol, 0, quoteAsset);

            // 設定倉位
            this._stock = new QuarterLevelStock(this._symbol);
        }

        this._ticketOrder.update()
            .then((tradingTickets) => {
                Object.keys(tradingTickets).map((orderId) => {
                    const { side, origQty, executedQty, status, price } = tradingTickets[orderId];
                    const quote = this._toQty(origQty * price);
                    if (side === 'BUY') {
                        this._accounting.bid(origQty, quote);
                        this._stock.bid(price, origQty);
                    }
                    else if (side === 'SELL') {
                        this._accounting.ask(origQty, quote);
                        this._stock.ask(price, origQty);
                    }
                });

                //先做 ema price 的設定後
                return this._emaPrice.reset();
            })
            .then(() => this._marketWatcher.updateOscillation(Interval.DAYS_1))
            .then(oscillation => {
                console.log(oscillation);

                const [highestPrice, hubPrice, lowestPrice] = oscillation.price;
                this.refreshStock(hubPrice, oscillation.closingQuarterLevel);

                // 將紀錄的獲利與均價覆蓋，直到做出交易
                if (avgPrice && gainPrice) {
                    this._stock.price.avg = avgPrice;
                    this._stock.price.gain = gainPrice;
                }

                this._dataSave();
            });
    }

    refreshStock(currPrice, quarterLevel) {
        // 處理倉位的四分級價位
        // quarterLevel = [100, 98, 43, 40];
        this._stock.initPrice(quarterLevel);

        // 設定倉位的最大庫存
        this._stock.initBaseStorage(this._toQty(this._accounting.getQuoteAssets() / currPrice));
    }
}
module.exports = QuarterLevelTrader;
