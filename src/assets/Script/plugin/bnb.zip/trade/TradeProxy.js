const PromptSync = require("prompt-sync")();
const LocalStorage = require('node-localstorage').LocalStorage,
    localStorage = new LocalStorage('./scratch');
const exchangeInfo = require("../data/binance/exchangeInfo");
const MarketWatcher = require("./MarketWatcher");
class TradeProxy {
    // 委托 
    entrust() {
        var ownerId = '';
        var apiKey = '';
        var secretKey = '';
        var keys = JSON.parse(localStorage.getItem('secret_api_keys') || '{}');
        ownerId = PromptSync('輸入擁有者識別碼:');
        const inputKeys = () => {
            apiKey = PromptSync('輸入 API KEY:');
            secretKey = PromptSync('輸入 SECRET KEY:');
            if (PromptSync('是否紀錄輸入內容(Y/n):').toLowerCase() === 'y') {
                // { [ownerId]: { apiKey, secretKey } }; 
                keys[ownerId] = { apiKey, secretKey };
                localStorage.setItem('secret_api_keys', JSON.stringify(keys));
                console.log('已紀錄', ownerId, '的金鑰');
            }
            // todo 用交易所指令檢查是否成功 
            const { servertime, account } = require("../data/binance/api");
            // 走驗證 
            servertime(ownerId)
                .then((serverTime) => account(ownerId))
                .then((result) => {
                    if (result.code === -2014) {
                        delete keys[ownerId];
                        localStorage.setItem('secret_api_keys', JSON.stringify(keys));
                        if (PromptSync('金鑰無效，是否重新輸入金鑰(Y/n):').toLowerCase === 'y') {
                            inputKeys();
                        }
                    } else {
                        console.log('test ok', result);
                    }
                });
        };
        if (!keys[ownerId]) {
            inputKeys();
        }
        else {
            // const { kline } = require("./data/binance/market"); 
            // kline(ownerId, 'BNBBTC') 
            // const MarketWatcher = require("./trade/MarketWatcher"); 
            // const exchangeInfo = require("./data/binance/exchangeInfo"); 
            var marketWatcher;
            exchangeInfo.update(ownerId)
                .then(() => marketWatcher = new MarketWatcher(ownerId, 'ARBUSDT'))
                .then(() => marketWatcher.updateCurrPrice())
                .then(() => marketWatcher.updateKlinesData())
                .then(() => {
                    console.log(marketWatcher.getFieldLevel(7, marketWatcher.getCurrPrice()));
                    console.log(marketWatcher.wavePriceFields);
                    console.log(marketWatcher.getWaveVariations(7));
                });
        }
    }
}
module.exports = TradeProxy;