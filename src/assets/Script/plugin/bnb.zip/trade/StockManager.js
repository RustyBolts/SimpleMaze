LocalStorage = require('node-localstorage').LocalStorage,
    localStorage = new LocalStorage('./scratch');
const { getPrecisionPrice, getPrecisionQuanity } = require("../data/binance/exchangeInfo");

class StockManager {
    constructor(symbol) {
        this._toPrice = (value, stepFix) => getPrecisionPrice(symbol, value, stepFix);
        this._toQty = (value) => getPrecisionQuanity(symbol, value);

        // 由高價位到低價格的先後順序
        this._stocks = [];

        this._dataSave = () => {
            let saveData = JSON.stringify(this._stocks);
            localStorage.setItem(`${symbol}_STOCKS`, saveData);
        };
        this._dataLoad = () => {
            let loadData = localStorage.getItem(`${symbol}_STOCKS`);
            if (loadData) {
                this._stocks = JSON.parse(loadData);
            }
        };
        this._dataLoad();
    }

    getStock(price) {
        // stocks 由價高開始排序
        return this._stocks.find(x => x.price.bottom <= price)
            || this._stocks[this._stocks.length - 1];// 返回最底倉位
    }

    /** 取得填倉數量 */
    getStorageQuanity() {
        return this._stocks.reduce((pre, sum) => pre.filled + sum, 0);
    }

    getDataFormat(closingQuarterLevel, storageQuantity, gain = 0, filledQuantity = 0, fillingQuantity = 0) {
        const [highest, highier, lower, lowest] = closingQuarterLevel;
        if (gain == 0) gain = highier;
        return {
            price: {
                top: highest,                   // 倉位的最高點
                gain: gain,                     // 用avg 推算可獲利的值
                heigh: highier,                 // 倉位中驅近高點的平均值
                base: lower,                    // 倉位中驅近低點的平均值
                avg: lower,                     // 購買後的平均價，值低於低點平均值
                bottom: lowest,                 // 倉位的最低點，跌破要發出警訊
                last: this._toPrice(
                    lowest - (lower - lowest)   // 擊破後設定認賠金額，
                ),
            },
            filled: this._toQty(filledQuantity),
            filling: this._toQty(fillingQuantity),
            storage: this._toQty(storageQuantity),
            // priceTrend: [],// 把每次trade 輸入的價格暫存起來，做一個漲跌的趨勢換算 Math.round(price/top*100)，取十位數來比較就好
        };
    }

    getQuarterLevelStock(closingQuarterLevel, storageQuantity) {
        const oriStock = this._stocks[0];// QuarterLevelStock吃一筆整理自 klineData 中一段時間的振盪切出來的 QuarterLevel 資料，只有一筆
        if (oriStock)
            return [this.getDataFormat(closingQuarterLevel, storageQuantity, oriStock.price.gain, oriStock.filled, oriStock.filling)];
        return [this.getDataFormat(closingQuarterLevel, storageQuantity)];
    }

    setQuarterLevelStock(closingQuarterLevel, storageQuantity) {
        this._stocks = this.getQuarterLevelStock(closingQuarterLevel, storageQuantity);
        console.log(this._stocks, closingQuarterLevel);
    }

    /**
     * 交易
     * @param {float} price 現價代入價格參數，來決定倉儲是開賣/買單
     * @param {int} times 若不急著一次買完，可分數次買入
     * @returns 
     */
    trade(price, times = 1) {
        let filling = 0;

        /** 掛賣倉儲 */
        // const sellOutStock = this._stocks.filter(x => x.price.heigh < price);// 改用 gain ，避免dash 出售沒賺到
        const sellOutStock = this._stocks.filter(x => x.price.gain < price);
        if (sellOutStock.length > 0) {
            // todo: 掛買的時候衝上去，應該也要考慮到把掛買的單暫時結算後再買吧 (目前倒數十分鐘沒弄好…金害)
            sellOutStock.forEach((stock) => {
                filling -= stock.filled;
                stock.filling -= stock.filled;
                stock.filled = 0;// todo 理論上應該是轉移到filling 紀錄，所以要先砍，可能忘記砍這邊補；記得accounting 確認一下
            });
        }

        // 有賣單，filling 為負值，然後立即回傳，不用管 buyIn
        if (filling < 0) {
            this._dataSave();
            return this._toQty(filling);
        }

        /** 止損檢查 */
        this._stocks.forEach(stock => {
            if (stock.last > price) {
                console.log('低於', stock.last, ', 認賠!');
                if (stock.filled > 0) {
                    console.log(', 所以清倉賣掉');
                    filling -= stock.filled;
                    stock.filling -= stock.filled;
                }
            }
        });

        // 有認賠，這次先不做 buyIn
        if (filling < 0) {
            this._dataSave();
            return this._toQty(filling);
        }

        /** 掛買倉儲 */
        // avg, base 取小，作為條件 (短線搶買會拉高avg)
        const buyInStock = this._stocks.find(x => Math.min(x.price.avg, x.price.base) > price && x.price.bottom <= price);
        // const buyInStock = this._stocks[0];//TEST
        if (buyInStock) {
            // 當 buyInStock.filling 不為0時，可能正在掛買或掛賣:
            // 若正在掛買，金額要向下比 avg 更低的話應該就做完買單了，所以不處理 buyInStock.filling >0 的情況；
            // 若正在掛賣，金額掉下來變成可以買，已經可以準備撤單了 todo 看怎麼從處理中看撤單，或不處理(10分鐘未完成交易會被TicketOrder撤單)
            if (buyInStock.filling != 0) return 0;//卡掛單，回傳0 不做新買單

            // 如果不想要一直買太接近的價格，限制一個價格
            // let rang = (buyInStock.price.avg - buyInStock.price.bottom) / times;//times是每倉庫存切幾次買，越買avg會越接近bottom
            let rang = (buyInStock.price.avg - buyInStock.price.bottom) / 3;
            console.log('追低價格:', this._toPrice(buyInStock.price.avg - rang), '>', price);
            if (buyInStock.price.avg - rang < price) return 0;//價格太接近上次買的，回傳值為0
            //

            let emptyStorage = buyInStock.storage - buyInStock.filled;// - buyInStock.filling;
            if (emptyStorage > 0) {
                filling = Math.min(buyInStock.storage / times, emptyStorage);
                buyInStock.filling += filling;

                // 調整avg: 下單前先算好avg，避免未調整時一直下同樣價格的買單
                var quote = buyInStock.filled * buyInStock.price.avg + filling * price;
                console.log('quote:', quote, '(', filling, 'x', price, ')', '-----', (buyInStock.filled * buyInStock.price.avg));
                buyInStock.price.avg = this._toPrice(quote / (buyInStock.filled + buyInStock.filling));
                console.log('預計買入後avg:', buyInStock.price.avg);

                // 有加倉的時候，原本dash 下單的 gain 就要重新考慮了
                buyInStock.price.gain = Math.max(buyInStock.price.gain, buyInStock.price.heigh);
            }
        }

        if (filling > 0) {
            this._dataSave();
        }

        // 買單沒有比賣單優先，沒賣也沒買回傳值為0
        return this._toQty(filling);
    }

    /**
     * 出清: 代入 price 與 times 指定售出的價位與拆分倉位的分母
     * @param {number} price 
     * @param {number} times 
     * @returns 
     */
    clean(price = 0, times = 1) {
        let filling = 0;
        // 記得重置avg 為base
        if (price > 0) {
            const stock = this.getStock(price);

            // 如果現價無法獲利，返回0
            // if (price < stock.price.gain) return 0;
            if (price < stock.price.avg) return 0;//暫時這樣
            console.log('現價可獲利');
            // todo 現在有點懶得處理同時掛賣又掛買的情況，暫時先返回0
            if (stock.filling != 0) return 0;
            console.log('現價可獲利', stock.filling);

            // 出售剩餘庫存，或 1/times 的庫存
            filling -= Math.min(stock.filled, stock.storage / times);

            stock.filling += filling;

            stock.price.avg = stock.price.base;
            // stock.price.gain = stock.price.heigh;// 這個別用， dashSellOut 是分段賣
        }
        else {
            // 完全出清所有庫存
            this._stocks.forEach((stock) => {
                if (stock.filled > 0) {
                    let fillingQty = 0;

                    // 覺的還是不要同時買又同時賣，或重疊單，會亂掉，外面要想辦法處理撤單
                    // todo 現在有點懶得處理同時掛賣又掛買的情況，暫時先返回0
                    if (stock.filling != 0) return 0;

                    // /** !! 請先撤單把 filling 清除為0，再出清 !! **/
                    // // 正掛買 : 最好能先撤單，不然買了就是準備賠掉 (雖然可能出清是一波大跌，早就買到了…)
                    // if (stock.filling > 0)
                    //     fillingQty -= stock.filled - stock.filling;
                    // // 正掛賣 : 最好能先撤單，不然賣不掉又無法認賠
                    // else if (stock.filling < 0)
                    //     fillingQty -= stock.filled + stock.filling;
                    // // 應該要能正確走到此流程，前面是無法避免未取消的情況
                    // else
                    fillingQty -= stock.filled;

                    // filling 在賣出時會是負值， filling+filled 會空出 storage ，所以 stock.filled 先不清， 在結算時才清
                    stock.filling += fillingQty;
                    filling += fillingQty;

                    stock.price.avg = stock.price.base;
                    stock.price.gain = stock.price.heigh;
                }
            });
        }
console.log('fillingfillingfilling:', filling);
        if (filling < 0)
            this._dataSave();

        return this._toQty(filling);
    }

    // 購入
    fill(price, earn, times = 1) {
        let filling = 0;

        if (price > 0) {
            const stock = this.getStock(price);
            const emptyStorage = stock.storage - stock.filled;

            // todo 測試中，這邊如果想在連續上漲時卻沒有買到很可惜才下單的，但卡heigh 就會造成這個短線策略失敗；目前有加 gain 希望可以補足這個問題
            // if (stock.price.heigh < price) {
            //     // 如果購買價還是比大振盪的 heigh 更高，還是別買
            //     // todo 但如果想弄一個硬要買的可能就要加個flag
            //     console.log('購入價高於倉位出購價', stock.price.heigh, ',太危險，不能買');
            //     return filling;
            // }

            // 正在掛買/賣 todo 現在有點懶得處理同時掛賣又掛買的情況，暫時先返回0
            if (stock.filling != 0) return 0;

            // 購入剩餘倉位空間，或 1/times 的倉位空間
            filling = Math.min(emptyStorage, stock.storage / times);

            stock.filling += filling;

            // 調整avg: 下單前先算好avg，避免未調整時一直下同樣價格的買單
            var quote = stock.filled * stock.price.avg + filling * price;
            console.log('quote:', quote, '(', filling, 'x', price, ') .....', (stock.filled * stock.price.avg));
            stock.price.avg = this._toPrice(quote / (stock.filled + stock.filling));
            console.log('預計買入後avg:', stock.price.avg);

            // 調整gain: avg 後換算可以賺 1鎂( todo earn由外部代入) 的價格
            // let earn = 1;
            stock.price.gain = earn / stock.storage + stock.price.avg;

            // ===> fill 的時候才改 gain，其他只有賣完結算才會回復 price.gain 為 price.height; 在後續繼續購買仍然不會改變，但如果這邊符合短線賺錢的話，要能夠接受gain 在賣出後才回歸heigh
        }
        // 靠…發現buy 一定要有price 去算avg，所以全倉購買要再想一下(DashOscillationTrader 暫時先不用擔心)
        // else {
        //     // 完全填滿所有倉位
        //     this._stocks.forEach((stock) => {
        //         let fillingQty = 0;
        //         const emptyStorage = stock.storage - stock.filled;


        //         // 覺的還是不要同時買又同時賣，或重疊單，會亂掉，外面要想辦法處理撤單
        //         // 正在掛賣 todo 現在有點懶得處理同時掛賣又掛買的情況，暫時先返回0
        //         if (stock.filling < 0) return filling;
        //         // todo 掛買也是
        //         if (stock.filling > 0) return filling;

        //         // /** !! 請先撤單把 filling 清除為0，再出清，如果又是賣又是買，這樣filling 會相抵消造成看不出正在買或賣 !! **/
        //         // // 正在掛買: 排除先前掛買的預留倉位，不讓這個倉位爆倉
        //         // if (stock.filling > 0)
        //         //     fillingQty = emptyStorage - stock.filling;
        //         // // 正在掛賣: 還沒賣掉所以沒有空出倉位，依舊用目前剩餘的倉位來補
        //         // else if (stock.filling < 0)
        //         //     fillingQty = emptyStorage;
        //         // // 正確流程 (fill 執行前應該先完成撤單)
        //         // else
        //         fillingQty = emptyStorage;

        //         stock.filling = this._toPrice(fillingQty + stock.filling);
        //         filling += fillingQty;

        //         // 調整avg: 下單前先算好avg，避免未調整時一直下同樣價格的買單
        //         var quote = stock.filled * stock.price.avg + fillingQty * price;
        //         console.log('quote:', quote);
        //         stock.price.avg = this._toPrice(quote / (stock.filled + stock.filling));
        //         console.log('預計買入後avg:', stock.price.avg);

        //         // 調整gain: 這邊有大振盪打平1/5 的倉位成本，就無視掉gain
        //         stock.price.gain = stock.price.heigh;
        //     });
        // }

        if (filling > 0)
            this._dataSave();

        return this._toQty(filling);
    }

    // 結算掛單
    result({ filled, filling }, resultPrice) {
        if (filled === 0 && filling === 0) return;
        console.log('filled, filling, price:', filled, filling, resultPrice);

        if (Math.abs(filling) > Math.abs(filled)) {
            /**
             * 處理撤單的情況，filiing 是 origQty 的數量，
             * 但因為撤單只有 executedQty 完成交易，也就是 filled 的數量
             */
            let stocks = [];
            console.log('撤單');
            if (filling < 0) {
                console.log('買單，要處理avg');
            }
            else if (filling > 0) {
                console.log('賣單，要處理avg');

            }
            stocks = this._stocks.filter(x => x.price.bottom < resultPrice && x.filling != 0);

            // todo 這邊這個還沒測完

            // // 處理avg 用的
            // stocks.forEach((stock) => {
            //     let emptyStorage = stock.storage - stock.filled;
            //     let filledQuantity = 0;
            //     if (emptyStorage >= filled) {
            //         filledQuantity = filled;
            //         filled = 0;
            //     }
            //     else {
            //         // 一次無法填滿
            //         filledQuantity = emptyStorage;
            //         filled -= emptyStorage;
            //     }
            //     // 這樣的話，先暫時這樣
            //     if (filledQuantity != 0) {
            //         stock.filled += filledQuantity;
            //         stock.price.avg = stock.price.base;
            //     }

            //     // todo 未來多倉位時要測一下這個
            //     let fillingRestQuantity = stock.filling + filling;
            //     stock.filling += filling - fillingRestQuantity;
            //     if (fillingRestQuantity != 0)
            //         filling = fillingRestQuantity;
            // });
            // 買入
            if (filled > 0) {
                stocks.forEach((stock) => {
                    // 取出 filled、filling 暫存，用來減去庫存與交易值
                    const emptyStorage = stock.storage - stock.filled;

                    // stock.filled += filled;
                    let filledQty = Math.min(filled, emptyStorage);
                    stock.filled += filledQty;
                    // 處理 filling 的，這邊會是負值
                    let fillingQty = Math.min(stock.filling, -filling);
                    stock.filling -= fillingQty;
                    console.log('filledQty:', filledQty, 'fillingQty:', fillingQty);

                    filled -= filledQty;
                    filling += fillingQty;
                });
            }
            // 賣出
            else if (filled < 0) {
                stocks.forEach((stock) => {
                    // 取出 filled、filling 暫存，用來減去庫存與交易值
                    let filledQty = stock.filled;
                    let fillingQty = stock.filling;
                    console.log('filledQty:', filledQty, 'fillingQty:', fillingQty);

                    // 情況1 - filled 填完後還有 庫存:     Math.max(-10 + 20, 0)
                    // 情況2 - 庫存 消減完後還有 filled:   Math.max(-20 + 10,0)
                    stock.filled = Math.max(filled + filledQty, 0);

                    // 情況1 - filling 填完後還有 預售:     Math.max(10 - 20, 0)
                    // 情況2 - 預售 消減完後還有 filling:   Math.max(20 - 10,0)
                    stock.filling = Math.min(filling + fillingQty, 0);
                    filled = Math.min(0, filled + filledQty);//filled 為負值, filledQty 為正值
                    filling = Math.max(0, filling + fillingQty);//filling 為正值, fillingQty 為負值
                    console.log('filled:', filled, 'filling:', filling);
                    // 成功賣掉後，把 avg 回歸 base
                    stock.price.avg = stock.price.base;

                    // 成功賣掉後，把 gain 回歸 hiegh
                    stock.price.gain = stock.price.heigh;
                });
            }
        }
        else {
            /** 
             * filled: 完成交易的，可進出倉位
             * filling: 待交易的，完成後需清除
             **/

            // 買入
            if (filled > 0) {
                const buyInStock = this._stocks.find(x => x.price.top >= resultPrice && x.price.bottom <= resultPrice);
                if (buyInStock) {

                    buyInStock.filled += filled;
                    // 處理 filling 的，這邊會是負值
                    buyInStock.filling += filling;

                    filled = 0;
                    filling = 0;
                }
            }
            // 賣出
            else if (filled < 0) {
                const sellOutStocks = this._stocks.filter(x => x.price.bottom < resultPrice);
                sellOutStocks.forEach((stock) => {
                    // 取出 filled、filling 暫存，用來減去庫存與交易值
                    let filledQty = stock.filled;
                    let fillingQty = stock.filling;

                    // 情況1 - filled 填完後還有 庫存:     Math.max(-10 + 20, 0)
                    // 情況2 - 庫存 消減完後還有 filled:   Math.max(-20 + 10,0)
                    stock.filled = Math.max(filled + filledQty, 0);

                    // 情況1 - filling 填完後還有 預售:     Math.max(10 - 20, 0)
                    // 情況2 - 預售 消減完後還有 filling:   Math.max(20 - 10,0)
                    stock.filling = Math.min(filling + fillingQty, 0);
                    filled = Math.min(0, filled + filledQty);//filled 為負值, filledQty 為正值; 取小，若filledQty>0
                    filling = Math.max(0, filling + fillingQty);//filling 為正值, fillingQty 為負值; 取大，若fillingQty<0且相加後為為負值

                    // 成功賣掉後，把 avg 回歸 base
                    stock.price.avg = stock.price.base;

                    // 成功賣掉後，把 gain 回歸 hiegh
                    // stock.price.gain = stock.price.heigh;// 這個別用， dashSellOut 是分段賣
                });

                if (filled + filling != 0) {
                    console.log('錯誤: filled 與 filling 在代入各自與stock 中的filled、filling 相加應，應為0:', filled, filling);
                    process.exit();
                }
            }
        }

        this._stocks.forEach(stock => {
            stock.price.gain = this._toPrice(stock.price.gain);
            stock.price.avg = this._toPrice(stock.price.avg);
            stock.filled = this._toQty(stock.filled);
            stock.filling = this._toQty(stock.filling);
        });

        console.log('Stock:', this._stocks[0], 'filled:', filled, 'filling:', filling);
        this._dataSave();
    }
}
module.exports = StockManager;