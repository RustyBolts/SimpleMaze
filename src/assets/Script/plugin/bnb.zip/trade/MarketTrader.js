const TicketOrder = require('./TicketOrder');
const Accounting = require('./Accounting');
const { getPrecisionQuanity } = require('../data/binance/exchangeInfo');
// 功能是確保能買入，用短期紀錄觀察合適的買入價格
class MarketTrader2 {
    constructor(ownerId, symbol, quoteAsset) {
        // this._ticketOrder = new TicketOrder(ownerId, symbol);
        this._ticketOrder = new TicketOrder('', symbol, 10);//test 不代 ownerId 就不會真的交易
        this._accounting = new Accounting(symbol, quoteAsset);

        this._toQty = (value) => getPrecisionQuanity(symbol, value);

        // 用在結算後處理 filling跟 filled
        this._orderids = [];
    }

    getFunds(currPrice) {
        return this._accounting.getFunds(currPrice);
    }

    getAssets() {
        // {"base":{"free":0.000020000000000000052,"lock":0},"quote":{"free":-179.01826849999983,"lock":1174.0395885}}
        return {
            base: this._accounting.baseAssets,
            quote: this._accounting.quoteAssets,
        };
    }

    buyIn(price, baseQuantity) {
        let quote = this._toQty(price * baseQuantity);
        this._accounting.buy(quote);
        return this._ticketOrder.bid(baseQuantity, price)
            .then((orderId) => this._orderids.push(orderId))
            .then(() => this._result());
    }

    sellOut(price, baseQuantity) {
        // let quote = price * baseQuantity;
        this._accounting.sell(baseQuantity);
        return this._ticketOrder.ask(baseQuantity, price)
            .then((orderId) => this._orderids.push(orderId))
            .then(() => this._result());
    }

    dropAllTickets() {
        return this._ticketOrder.cancelAll()
            .then(() => this._result());
    }

    result(price) {
        if (this._orderids.length > 0)
            return this._ticketOrder.check(price) // check 交易單
                .then((hadTicketResult) => {
                    // if (!hadTicketResult) return;//擋了其實會在買/賣/撤單後沒有 TicketOrder._tradingTickets 的處理，check 的結果會是false
                    hadTicketResult && console.log('this._ticketOrder.check(', price, ')');
                    return this._result();
                });
        // 沒有交易結果，僅用以走流程
        else return Promise.resolve({
            price,
            filling: 0,
            filled: 0
        });
    }
    _result() {
        var filled = 0, filling = 0;
        // 結單
        var orderPrice = 0;
        this._ticketOrder.takeTradeList().forEach((order) => {
            const { orderId, side, executedQty, status, price } = order;
            const quote = this._toQty(executedQty * price);
            if (side === 'BUY') {
                this._accounting.bought(executedQty, quote);

                filled += executedQty;
                filling -= executedQty;
            }
            else if (side === 'SELL') {
                // 交易結果返回 assets, 處理freeze assets
                this._accounting.sold(executedQty, quote);

                filled -= executedQty;
                filling += executedQty;
            }

            console.log('takeTradeList status:', status);
            // 處理完刪 orderId
            this._orderids.splice(this._orderids.findIndex(x => x.orderId === orderId), 1);
            orderPrice = price;//todeo 多倉時要算avg
        });
        if (orderPrice > 0)
            return {
                price: orderPrice,
                filling: this._toQty(filling),
                filled: this._toQty(filled)
            };

        // 撤單
        var dropPrice = 0;
        this._ticketOrder.takeDropList().forEach((order) => {
            const { orderId, side, origQty, executedQty, price } = order;
            const quote = this._toQty(executedQty * price);
            // const oriQuote = this._toQty(origQty * price);   // 好像弄錯了，把"dropBid(origQty"當作是oriQuote在處理
            if (side === 'BUY') {
                // 撤單結果返回 assets, 處理freeze assets
                this._accounting.dropBid(origQty * price, executedQty, quote);

                filled += executedQty;
                filling -= origQty;
            }
            else if (side === 'SELL') {
                // 撤單結果返回 assets, 處理freeze assets，並針對已執行的baseAsset 數量進行買賣結果的換算
                this._accounting.dropAsk(origQty, executedQty, quote);

                filled -= executedQty;
                filling += origQty;
            }

            // 處理完刪 orderId
            this._orderids.splice(this._orderids.findIndex(id => id === orderId), 1);
            dropPrice = price;//todeo 多倉時要算avg
        });

        return {
            price: dropPrice,
            filling: this._toQty(filling),
            filled: this._toQty(filled)
        };
    }
}

module.exports = MarketTrader2;