const { getPrecisionPrice } = require("../data/binance/exchangeInfo");
const market = require("../data/binance/market");
const { Interval } = require("../data/binance/request");

class EMAPrice {
    // 預設為 15分鐘 的EMA均線週期
    constructor(ownerId, symbol, interval = Interval.MINUTES_01, limit = 15) {
        this.value = 0;

        this._ownerId = ownerId;
        this._symbol = symbol;

        this._interval = interval;
        this._limit = limit;

        this._toPrice = (value, stepFix) => getPrecisionPrice(this._symbol, value, stepFix);
    }

    // 重置 ema price
    reset() {
        const lastUpdateTime = 0;
        const currTime = Date.now();
        const onlyResult = true;

        return market.kline(this._ownerId, this._symbol, lastUpdateTime, currTime, this._interval, this._limit, onlyResult)
            .then((rawData) => {
                let closingList = rawData.map((data) => data[market.KLINE.Closing]);
                // closingList.pop();//最後一個扔掉，因為 update 時會加入最新的，這個值基本不會差太多才對
                this.value = this._toPrice(
                    closingList.reduce((prev, curr) => prev + curr, 0) / (this._limit - 1)//limit-1是因為closingList.pop()的關係
                );
            });
    }

    // 更新一個價格
    update(price) {
        this.value = this._toPrice((this.value * (this._limit - 1) + price * 2) / (this._limit + 1));
    }
}
module.exports = EMAPrice;