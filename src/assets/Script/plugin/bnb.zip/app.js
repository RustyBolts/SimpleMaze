// var express = require('express'),
//   // request = require('request'),
//   bodyParser = require('body-parser'),
//   app = express();


// var myLimit = typeof (process.argv[2]) != 'undefined' ? process.argv[2] : '10kb';
// console.log('Using limit: ', myLimit);

// app.use(bodyParser.json({ limit: myLimit }));

// app.all('*', function (req, res, next) {
//   // Set CORS headers: allow all origins, methods, and headers: you may want to lock this down in a production environment
//   res.header("Access-Control-Allow-Origin", "*");
//   res.header("Access-Control-Allow-Methods", "GET, PUT, PATCH, POST, DELETE");
//   res.header("Access-Control-Allow-Headers", req.header('access-control-request-headers'));

//   if (req.method === 'OPTIONS') {
//     // CORS Preflight
//     res.send();
//   } else {
//     var targetURL = req.header('Target-URL');
//     console.log('targetURL:', targetURL);
//     if (!targetURL) {
//       res.send(500, { error: 'There is no Target-Endpoint header in the request' });
//       return;
//     }
//     var headers = {};
//     var apikey = req.header('X-MBX-APIKEY');
//     if (apikey)
//       headers['X-MBX-APIKEY'] = apikey;

//     // console.log(targetURL);
//     require('axios')({
//       url: targetURL,
//       method: req.method,
//       // json: req.body,
//       headers: headers,
//       // followAllRedirects: true,
//       // params: req.params
//     },
//       // function (error, response, body) {
//       //   if (error) {
//       //     console.error('error: ' + response)
//       //   }
//       //   console.log('body:', body);
//       // }
//     ).then(function (response) {
//       // response.data.pipe(res)
//       res.send(response.data);
//     })
//       .catch(err => {
//         if (err.response) {
//           res.status(err.response.status).send(err.response.data);
//         } else {
//           res.status(401).send();
//         }
//       });
//   }
// });
// // var path = '/api/v1/ping';
// // require('axios')({
// //   url: 'https://api.binance.com' + path,
// //   method: 'GET',
// //   headers: {
// //     // 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
// //     // 'accept-encoding': 'gzip, deflate, br',
// //     // 'accept-language': 'zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7',
// //   },
// // })
// //   .then(raw => console.log('raw:', raw))
// //   .catch(err => console.log('err:', err));

// var port = process.env.PORT || 3000;

// app.listen(port, function () {
//   console.log('Proxy server listening on port ' + port);
// });



// // 測試加解密
// const { aesEncrypt, aesDecrypt } = require('./communication/bridge');
// const IV = 'f720b45f04e37c09' // 初始化向量（iv）
// const data = '{"akey":"0fCIOiKsQtzDsQ4UR1zk7KuHzU1oE43tikHYmnTV1Z2cThR2TaTd6L67YhXdFoDY"}' // 需要加解密的內容
// const key = '123456789987654321123456' // 24 位密鑰
// let encryptData = aesEncrypt(data, key, IV);
// let decryptData = aesDecrypt(encryptData, key, IV);
// console.log(encryptData)
// console.log(decryptData)




// function pingpong(isHonst, guid_id) {
//   this.isHonst = isHonst;

//   const { addDispatcher, connectListener } = require('./communication/bridge.js');

//   let cnt = 3;

//   this.notify_ping = (boo, key) => {
//     if (boo != isHonst) return;
//     console.log(key, boo, isHonst);
//     if (!isHonst) return;
//     if (cnt == 0) return;
//     cnt--;
//     // console.log('ping');
//     setTimeout(() => dbConnect.broadcast(guid_id, 'pong', Date.now()), 5000);
//   };
//   addDispatcher(guid_id, this, {
//     'ping': this.notify_ping,
//   });

//   this.notify_pong = (boo, key) => {
//     if (boo != isHonst) return;
//     console.log(key, boo, isHonst);
//     if (isHonst) return;
//     if (cnt == 0) return;
//     cnt--;
//     // console.log('pong');
//     setTimeout(() => dbConnect.applicate(guid_id, 'ping', Date.now()), 5000);
//   };
//   addDispatcher(guid_id, this, {
//     'pong': this.notify_pong
//   });

//   connectListener(guid_id, isHonst);
// }

// // 連線
// const { signIn, dbOnline, dbUsers, dbConnect, test } = require('./communication/firebase.js');
// signIn('xxfox0010@gmail.com', 'dgca4080') // 登入google帳號，以使用firebase
//   .then((guid) => {
//     /**
//      * User: 處理登入部份， 先上線提供登入資訊
//      */
//     const { onlineListener, clientLogin, clientRegist } = require('./login/user.js');
//     // 登完firebase 就開監聽使用者是否上線
//     onlineListener();

//     // const guid_id = (Math.round(Math.random() * 1000000000000)).toString(16);
//     // const hPingpong = new pingpong(true, guid_id);
//     // const cPingpong = new pingpong(false, guid_id);
//     // dbConnect.applicate(guid_id, 'ping', Date.now());

//     // TEST
//     // const guid = 'ZjNqTz0f28bVa2olOyrS3uiOj2j2', id = '-Mm1IoieueJXkbIwB4-6';
//     // TEST user.getUserData
//     // getUsersData(guid).then((d)=>console.log('user data:', d));
//     // getUsersData().then((d)=>console.log('user data:', d));
//     // TEST upload & dbOnline.listen
//     // dbOnline.listen((d)=>{
//     //   const result = d[`${guid}::${id}`];
//     //   console.log('result:', result);
//     // });
//     // dbOnline.status(guid, id, 'xxx');
//     // setTimeout(()=>dbOnline.status(guid, id, null), 1000);
//     // TEST read
//     // dbUsers.getIds(guid).then((d)=>console.log(d));
//     // TEST notify listener
//     // const { addDispatcher, connectListener, removeDispatcher } = require('./communication/bridge.js');
//     // const guid_id = `${guid}::${id}`;
//     // connectListener(guid_id);//clietn, honst 要補isHonst
//     // addDispatcher(guid_id, this, {
//     //   'seven': (guid_id, key, value)=> console.log(('seven trace:', guid_id, key, value)),
//     // });
//     // // removeDispatcher(guid_id, this);
//     // setTimeout(()=>dbConnect.applicate(guid_id, 'seven', Date.now()), 1000);//client

//     // TEST connection
//     // const id = userRegist(guid);//註冊
//     // console.log('Regist:', id);
//     const id = '-NGqI3VI6fMBqFlDi_mN';
//     const pw = 'pw_1234';
//     clientLogin(guid, id, pw);
//     // const localStorage = require('localStorage');
//     // // localStorage.setItem('skey', 'aaabbbcccdddd');
//     // localStorage.clear();
//     // console.log(localStorage.getItem('skey', '?'));

//     // const n = '2';
//     // test.r(n).then((data)=>Object.keys(data).map(k=>data[k]))
//     //   .then((ary)=>test.w(n, ary));
//     // test.r().then((data)=>console.log(data)).catch((err)=>console.log(err));
//     // test.w('3', ddd);
//   })
//   .catch((err) => console.log(err));

const DexExchange = require("./trade/dex/DexExchange");
const Ema = require("./trade/dex/Ema");

// let dexROUL = new DexExchange();
// // dexROUL.addBottomAlert(0.011);
// dexROUL.addBottomAlert(0.007);
// dexROUL.addTopAlert(0.02);
// const a = () => dexROUL.load('0xb5ffc69bfe0388f3cf13d9ad4833ed32d283095b', 'arbitrum', 'ROUL');
// a();
// setInterval(a, 60000);
// 0.0185793 ↑ (0.01252175 - 0.01869814 [200/200])

// let dexGST = new DexExchange();
// // dexGST.addTopAlert(1.38);
// dexGST.addTopAlert(2.5);
// // dexGST.addBottomAlert(1.33);
// const b = () => dexGST.load('0xc0f05732d1cda6f59487ceeef4390abcad86ea3e', 'arbitrum','GST');
// const b = () => dexGST.load('5NLeMabMyuJQUbvXNfVyUPbtYKwTXBesfmFmDswbgqUz', 'arbitrum','GST');
// https://www.dextools.io/shared/data/pair?address=5NLeMabMyuJQUbvXNfVyUPbtYKwTXBesfmFmDswbgqUz&chain=solana
// b();
// setInterval(b, 60000);

// const DiscordWebhook = require("./communication/discordWebhook");
// let webhook = new DiscordWebhook();
// webhook.sendDiscordMessage('Hello, Discord! This message was sent via webhook.');

let dexOREO = new DexExchange();
dexOREO.addBottomAlert(0.4);
dexOREO.addTopAlert(0.96);
const c = () => dexOREO.load('0xbf6a0418e31f90b60ae3d19c56a659ad8b2f4d18', 'arbitrum', 'OREO');
c();
setInterval(c, 30000);

// 塞入 precisionRound
Math.precisionRound = function (val, precision = 8) {
    if (precision === 0) return Math.round(val);
    const expand = Math.pow(10, precision);
    return Math.round(val * expand) / expand;
}


// // TEST

// let closeingList = [3, 4, 3, 5, 4, 3, 4, 5, 4, 4, 5, 4, 4, 5, 5, 5, 5, 4, 3, 3, 3, 2, 3, 2, 2, 3, 4, 5, 5, 5, 4, 5, 4, 3, 4, 3, 5, 4, 3, 4, 5, 4, 4, 5, 4, 4, 5, 5, 5, 5, 4, 3, 3, 3, 2, 3, 2, 2, 3, 4, 5, 5, 5, 4, 5, 4, 3, 4, 3, 5, 4, 3, 4, 5, 4, 4, 5, 4, 4, 5, 5, 5, 5, 4, 3, 3, 3, 2, 3, 2, 2, 3, 4, 5, 5, 5, 4, 5, 4];
// // this.emaPrices = [7, 15, 25].map((unit) => closeingList.slice(0, unit).reduce((prev, curr) => prev + curr, 0) / unit);
// let fakeOreoKlines = closeingList.map((c) => ({ closing: c, highest: c + Math.random(), lowest: c - Math.random(), valume: Math.random() * 1000 }));
// // console.log('fakeOreoKlines:', fakeOreoKlines);

// // let currPriceX2 = 4*2;
// // [7, 25, 99].map((unit, idx) => (this.emaPrices[idx] * (unit - 1) + currPriceX2) / (unit + 1));
// const oreoEma = new Ema('OREO', fakeOreoKlines);
// console.log(oreoEma.emaPrices);
// let fakeOreoNewKline = { closing: 6, highest: c + Math.random(), lowest: c - Math.random(), valume: Math.random() * 1000 };
// fakeOreoKlines.push(fakeOreoNewKline);
// console.log(oreoEma.emaPrices);
// console.log('現價/ema均線比:', oreoEma.avgPriceEmaRate(4));
// console.log('ema均線整理率:', oreoEma.avgTidyRate(fakeOreoKlines.slice(0, 20)));
// console.log('valuem成長率:', oreoEma.avgValumeDiffRate(fakeOreoNewKline));
// oreoEma.addNew(fakeOreoNewKline);