const { connectListener, addDispatcher, aesEncrypt } = require('../communication/bridge.js');
const { dbUsers, dbConnect, dbRecord } = require('../communication/firebase.js');
const YellowCardHandler = require('../trade/YellowCardHandler.js');
const StatusHandler = require('./StatusHandler.js');
const onlineListener = function () {
    // Process login status
    // const statusHandler = new StatusHandler();
    // Connection
    let connections = {};
    let connectCnt = 0;
    // Listener
    dbConnect.listen(function (data) {
        Object.keys(data).forEach((guid_id) => {
            const { status } = data[guid_id];
            if (status) {
                const cmd = status.split(' ');
                // console.log(guid_id, cmd);
                switch (cmd[0]) {
                    case 'helo':
                        dbRecord.download('SKEY', guid_id)
                            .then((sKey) => {
                                // console.log('sKey', sKey, '\n', cmd[1]);
                                // console.log('get session key:::', getSessionKey(cmd[1], cmd[2]));
                                // sessionKey
                                if (sKey === cmd[1]) dbConnect.status(guid_id, 'oleh SUCCESS');
                                // id+pw
                                else if (cmd[2]) {
                                    const sessionKey = getSessionKey(cmd[1], cmd[2]);
                                    if (sessionKey === sKey) dbConnect.status(guid_id, `session ${sessionKey}`);
                                    else if (!sKey) dbConnect.status(guid_id, `session ${sessionKey}`);
                                }
                                // fail
                                else dbConnect.status(guid_id, 'oleh FAIL_INPUT');
                            });
                        break;
                    case 'connecting':
                        // console.log('connecting connections[', guid_id, ']', connections[guid_id]);
                        if (!connections[guid_id]) {
                            const connection = new YellowCardHandler(guid_id, true);
                            connections[guid_id] = connection;
                            connectListener(guid_id, true);
                            connectCnt++;
                        }
                        dbConnect.status(guid_id, 'connected');
                        break;
                    case 'disconnect':
                        //清 connections 中已斷線的
                        // if (connections[guid_id]) {
                        //     statusHandler.finish(guid_id);
                        //     dbConnect.disconnect(guid_id);
                        //     connections[guid_id].leaveRoom();
                        //     delete connections[guid_id];
                        //     connectCnt--;
                        // }
                        break;
                    default:
                        // statusHandler.userOnlineStatus(guid_id, status, cmd);
                        break;
                }
                // console.log('connectCnt:', connectCnt);

                // if (connections[guid_id]) {
                //     connections[guid_id].userOnlineStatus(status);
                // } else {
                //     const split = guid_id.split('::');
                //     const guid = split[0];
                //     const id = split[1];
                //     dbUsers.getIds(guid).then((data) => {
                //         console.log('data:', data, id);
                //         // 檢查有無此帳號
                //         if (Object.keys(data).some((childId) => id === childId)) {
                //             const connection = new ConnectionHandler();
                //             connection.setHonstHandler(guid, id);
                //             connection.userOnlineStatus(status);
                //             connections[guid_id] = connection;
                //         }
                //     });
                // }
            }
        });
    });

};

const getSessionKey = function (id, password) {
    return aesEncrypt(`${id}_${password}`, '123456789987654321123456', 'f720b45f04e37c09');// todo 加密方式要改別的地方，不然會曝露
};
const userRegist = function (guid, registid = null) {
    const id = dbUsers.regist(guid, registid, Date.now());
    return id;
};
const clientLogin = function (guid, id, pw) {
    // const statusHandler = new StatusHandler();
    console.log('clientLogin:', guid, id, pw);
    let interval, cnt = 5;
    let connection;
    const guid_id = `${guid}::${id}`;
    const loginSchedule = function () {
        dbConnect.login(guid_id)
            .then((status) => {
                console.log('clientLogin status:', status);
                if (status) {
                    if (status === 'connected') {
                        if (!connection) {
                            connection = new YellowCardHandler(guid_id, false);
                            connectListener(guid_id, false);
                            // dbConnect.applicate(guid_id, 'ping', Date.now());
                            connection.testNewRoom();
                        }
                    } else {
                        // statusHandler.clientOnlineStatus(guid, id, status);

                        if (status.indexOf('oleh') === 0) {
                            const msg = status.split(' ')[1];
                            if (msg === 'SUCCESS') {
                                dbConnect.status(guid_id, 'connecting');
                            }
                        }
                        else if (status.indexOf('session') === 0) {
                            const skey = status.split(' ')[1];
                            const localStorage = require('localStorage');
                            let skeyData = JSON.parse(localStorage.getItem('skey') || '{}');
                            skeyData[guid_id] = skey;
                            localStorage.setItem('skey', JSON.stringify(skeyData));
                            // 這邊做guestid 登入
                            dbConnect.status(guid_id, `helo ${skey}`);
                        }

                        clearTimeout(interval);
                        interval = setTimeout(() => cnt > 0 && loginSchedule(), 1000);
                        cnt--;
                    }
                    // statusHandler.clientOnlineStatus(guid, id, status);

                    // if (!statusHandler.isConnecting) {
                    //     clearTimeout(interval);
                    //     interval = setTimeout(() => cnt > 0 && loginSchedule(), 1000);
                    // } else {
                    //     const connection = new YellowCardHandler(`${guid}::${id}`, false);
                    //     // connection.testNewRoom();
                    // }
                }
                else cnt--;
            });
    };
    loginSchedule();
    const skeyData = JSON.parse(require('localStorage').getItem('skey') || '{}');
    const skey = skeyData[guid_id];
    skey
        ? dbConnect.status(guid_id, `helo ${skey}`)
        : dbConnect.status(guid_id, `helo ${id} ${pw}`);
    // statusHandler.clientLogin(guid, id, pw);

    // const guid_id = `${guid}::${id}`;
    // dbConnect.connection(guid_id, (data) => {
    //     if (data) {
    //         const cmd = data.split(' ');
    //         if (cmd[0] === 'output') {

    //             const key = cmd[1];
    //             switch (key) {
    //             }
    //         }
    //     } else {
    //         // disconnect
    //     }
    // });
    // this.login = (isHonst, guid_id, key, value) => {

    //     if (value === 'SUCCESS') {
    //         dbConnect.applicate(guid_id, 'connecting');
    //     } else if (value === 'FAIL_INPUT') {

    //     }
    // };
    // this.session = (isHonst, guid_id, key, value) => {
    //     var skey = value;
    //     const localStorage = require('localStorage');
    //     let skeyData = JSON.parse(localStorage.getItem('skey') || '{}');
    //     skeyData[guid_id] = skey;
    //     localStorage.setItem('skey', JSON.stringify(skeyData));
    //     // 這邊做guestid 登入
    //     dbConnect.broadcast(guid_id, `login ${skey}`);
    // };
    // this.connected = (isHonst, guid_id, key, value) => {
    //     const connection = new YellowCardHandler(guid_id, false);
    //     // connectListener(guid_id, false);
    //     // dbConnect.applicate(guid_id, 'ping', Date.now());
    //     console.log('0-0-0-0-0-0-0-0-0-0--0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0');
    //     connection.testNewRoom();
    // };
    // addDispatcher(guid_id, clientLogin, {
    //     'login': this.login,
    //     'session': this.session,
    //     'connected': this.connected,
    // });

};

module.exports = {
    onlineListener,     // firebase 啟動時執行
    userRegist,
    clientLogin,        // client
};