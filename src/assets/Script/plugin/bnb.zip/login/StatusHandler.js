const { addDispatcher, removeDispatcher, aesEncrypt, connectListener, aesDecrypt } = require("../communication/bridge");
const { dbConnect, dbRecord } = require("../communication/firebase");
// const YellowCardHandler = require("../trade/YellowCardHandler");
// const YellowCardData = require("../trade/YellowCardData");

class ConnectionHandler {

    constructor() {
        // this._onlineStatus = '';
        this._onlineStatus = {};
        this._pastStatus = '';
        this.isConnecting = false;
    }

    // setId(guid, id) {
    //     this._guid = guid;
    //     this._id = id;
    //     this.uniquneid = `${guid}::${id}`;
    // }

    // setHonstHandler(guid, id) {
    //     this.setId(guid, id);
    //     this.connectionHandler = new YellowCardHandler();
    //     this.connectionData = new YellowCardData();
    //     this.connectionHandler.setConnectionData(this.connectionData);
    // }

    // setClientHandler() {
    //     this.connectionHandler = new YellowCardHandler();
    // }

    finish(guid_id) {
        // const split = guid_id.split('::');
        // const guid = split[0];
        // const id = split[1];
        // dbConnect.status(guid, id, 'disconnect');
        // removeDispatcher(guid_id, this);
        delete this._onlineStatus[guid_id];
    }

    /** HONST */
    userOnlineStatus(guid_id, status, cmd) {
        // 不處理連續同樣的 dbOnline.status
        if (this._onlineStatus[guid_id] === status) return;
        this._onlineStatus[guid_id] = status;

        // const cmd = status.split(' ');
        console.log('cmd:', cmd);
        switch (cmd[0]) {
            // 'helo ${loginId} ${loginPw}',// c->s new client login
            // 'helo ${skey}',// c->s quick login
            case 'helo':
                var skey = cmd[2]
                    ? this.getSessionKey(cmd[1], cmd[2])    // input {id,pw} to skey
                    : cmd[1]                                // skey
                this.login(guid_id, skey);
                break;

            // 'regist ${newId} ${password}',// c->s 做 id 的加入
            case 'regist':
                console.log('cmd regist');
                this.setSession(guid_id, this.getSessionKey(cmd[1], cmd[2]));
                break;

            // case 'connecting':
            //     this.isConnecting = cmd[1] == '0';// && this.addDispatchHonstNotifies();
            //     const split = guid_id.split('::');
            //     const guid = split[0];
            //     const id = split[1];
            //     console.log('honst conneting');
            //     this.isConnecting && dbConnect.status(guid, id, 'connecting 1');
            //     break;

            default:
                break;
        }
    }

    login(guid_id, sessionKey) {
        dbRecord.download('SKEY', guid_id)
            .then((sKey) => {
                // 296965b20395482db3722d1eba37bbfd8e2e570232b7618a50b63d41d66322ef
                // console.log('db:', aesDecrypt(sKey, '123456789987654321123456', 'f720b45f04e37c09'));
                // console.log('sessionKey:', aesDecrypt(sessionKey, '123456789987654321123456', 'f720b45f04e37c09'));
                console.log('login - sKey:', sKey, '\nsessionKey:', sessionKey);
                let msg = '';
                if (sKey === sessionKey) msg = 'SUCCESS';
                else if (!sKey) msg = 'NO_SESSION';
                else msg = 'FAIL_INPUT';

                const split = guid_id.split('::');
                const guid = split[0];
                const id = split[1];
                dbConnect.status(guid, id, `login ${msg}`);
            });
    }
    getSessionKey(id, password) {
        return aesEncrypt(`${id}_${password}`, '123456789987654321123456', 'f720b45f04e37c09');// todo 加密方式要改別的地方，不然會曝露
    }
    setSession(guid_id, sessionKey) {
        dbRecord.upload('SKEY', guid_id, sessionKey);
        console.log("setSession::::", guid_id, sessionKey);
        const split = guid_id.split('::');
        const guid = split[0];
        const id = split[1];
        dbConnect.status(guid, id, `setSession ${id} ${sessionKey}`);
    }
    // addDispatchHonstNotifies() {
    //     console.log('addDispatchHonstNotifies!!');
    //     addDispatcher(this.uniquneid, this, {
    //         'ping': this.notify_ping,
    //     });
    //     connectListener(this.uniquneid, true);// 只要做一次啟動監聽即可，其他地方 addDispatcher 就行了
    //     // 
    //     // this.connectionHandler = new YellowCardHandler(this.uniquneid, true);
    // }
    // notify_ping(guid_id, key, value) {
    //     // 每10秒檢查一次ping pong
    //     const delayMS = 10000;
    //     console.log('ping', value);

    //     // 連線檢查: client 要接pong，然後等 delayMS 的時間後再送出 ping 以保持連線確認
    //     dbConnect.broadcast(guid_id, 'pong', Date.now());

    //     // client 固定時間送出 ping ，計時未再送ping 的話就斷線 TODO: 看是不是多個幾次再斷線？
    //     const timestamp = parseInt(value, 10);
    //     this._timoutInterval && clearTimeout(this._timoutInterval);
    //     this._timoutInterval = setTimeout(() => {
    //         // 等待超時
    //         if (Date.now() - timestamp > delayMS) {
    //             console.log(guid_id, '等待超時');
    //             // 結束登入狀態
    //             this.finish();
    //         }
    //     }, delayMS + 1000);// 延遲時間再多1秒緩衝
    // }

    /** CLIENT */
    clientOnlineStatus(guid, id, status) {
        // 不處理連續同樣的 dbOnline.status
        if (this._pastStatus == status) return;
        this._pastStatus = status;

        const cmd = status.split(' ');
        switch (cmd[0]) {
            // 'oleh',// s->c 回應
            // case 'oleh':
            //     if (cmd[2]) {
            //         const loginId = cmd[1];
            //         const loginPw = cmd[2];
            //         console.log('oleh ---- id:', id, 'loginId:', loginId);
            //         dbConnect.status(guid, id, `regist ${loginId} ${loginPw}`);
            //     } else {
            //         var skey = cmd[1];
            //         dbConnect.status(guid, id, `helo ${skey}`);
            //     }
            //     break;

            // 'muti_login',// s->c 發現有重複登入，不過目前沒想到要怎麼處理
            // 'regist_fail',// s->c 可能是交易所那邊的key 連不上
            // 'setSession ${id} ${skey}',// s->c 成功了請client 把skey 存起來以後可以自動登入
            case 'setSession':
                // save skey (cmd[2])
                var skey = cmd[2];
                const localStorage = require('localStorage');
                let skeyData = JSON.parse(localStorage.getItem('skey') || '{}');
                skeyData[`${guid}::${id}`] = skey;
                localStorage.setItem('skey', JSON.stringify(skeyData));
                // 這邊做guestid 登入
                dbConnect.status(guid, id, `helo ${skey}`);
                break;

            case 'login':
                console.log('cmd[1]:', cmd[1]);
                if (cmd[1] === 'SUCCESS') {
                    // this.addDispatchClientNotifies();
                    // dbConnect.status(guid, id, 'connecting 0');
                    dbConnect.status(guid, id, 'connecting');
                }
                else if (cmd[1] === 'NO_SESSION') {
                    // console.error(status);
                    console.log('to regist');
                    dbConnect.status(guid, id, `regist ${id} ${this._password}`);
                } else if (cmd[1] === 'FAIL_INPUT') {
                    console.error(status);
                    console.log('id or pw is not correct');
                    console.log('input again');
                    // 可能session 消失或密碼帶錯
                }
                break;

            // case 'connecting':
            //     this.isConnecting = cmd[1] == '1';
            //     this.isConnecting && dbConnect.applicate(`${guid}::${id}`, 'ping', Date.now());
            //     break;

            default:
                break;
        }
    }
    clientRegist(guid, id, pw) {
        dbConnect.status(guid, id, `regist ${id} ${pw}`);
    }
    clientLogin(guid, id, pw) {
        // this.setId(guid, id);
        this._password = pw;

        const skeyData = JSON.parse(require('localStorage').getItem('skey') || '{}');
        const skey = skeyData[`${guid}::${id}`] || '';
        skey
            ? dbConnect.status(guid, id, `helo ${skey}`)
            : dbConnect.status(guid, id, `helo ${id} ${pw}`);
    }

    // addDispatchClientNotifies() {
    //     console.log('addDispatchClientNotifies!!');
    //     addDispatcher(this.uniquneid, this, {
    //         'pong': this.notify_pong,
    //     });
    //     connectListener(this.uniquneid);
    //     this.connectionHandler = new YellowCardHandler(this.uniquneid);
    // }
    // // client 這邊要做的，記得一開始要先送給Honst ping， 才會一直保持
    // notify_pong(guid_id, key, value) {
    //     console.log('pong');
    //     // 每10秒檢查一次ping pong
    //     const delayMS = 10000;
    //     setTimeout(() => {
    //         // 收到 delayMS 後回送
    //         dbConnect.applicate(guid_id, 'ping', Date.now());
    //     }, delayMS);
    // }
}

module.exports = ConnectionHandler;