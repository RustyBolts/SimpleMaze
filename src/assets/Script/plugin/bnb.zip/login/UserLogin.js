// const { addDispatcher, removeDispatcher, aesDecrypt, aesEncrypt, connectListener } = require('../communication/bridge.js');
// const { dbOnline, dbUsers, dbConnect } = require('../communication/firebase.js');
// const delayMS = 10000;    // 每10秒檢查一次ping pong

// class UserLogin {
//     // 建構時，用 guid 標別，後續登錄動作用 id (之後改 nickname)
//     constructor(guid) {
//         // 暫存該使用者的 google uid
//         this._guid = guid;
//         // 暫存前當前處理的 online status，可以避免重刷
//         this._onlineStatus = '';
//         // ping pong 用的 timeout 時間
//         this._timoutInterval;
//         // 正在登入的 id/nickname
//         this._onlineUsers = [];
//     }

//     updateOnlineStatus(id, status) {
//         // 不處理連續同樣的 dbOnline.status
//         if (this._onlineStatus === status) return;
//         this._onlineStatus = status;
//         console.log('status:', status);

//         // client 上線打招呼
//         if (status === 'helo') {
//             // 檢查是否為線上使用者：若否，則加入連線監聽
//             if (this._onlineUsers.indexOf(id) === -1) {
//                 // 回應client 的打招呼，讓client 可以開始連線後的工作了
//                 dbOnline.status(this._guid, id, 'oleh');
//                 // 開始連線
//                 this.begin(id);
//                 // 把id/nickname 暫存起來
//                 this._onlineUsers.push(id);
//             }
//             // 如果已經有連線(hello 時onlineUsers 已經有此id存在)，可能是重複登入
//             else {
//                 console.log('相同 id/nickname 重複登入');
//                 // TODO:可能client 做一下請求，把狀態丟一下通知id.output 為重複登入需要踢出
//                 dbOnline.status(this._guid, id, 'muti_login');
//             }
//         }
//         // regist 是用 guid
//         else if (status.indexOf('regist') === 0) {
//             // 用guid 註冊
//             let splitAry = status.split(' ');
//             let apiKey = splitAry[1];
//             let secretKey = splitAry[2];

//             // 沒帶齊必要的鍵值
//             if (!apiKey || !secretKey) return;

//             // client 用google 帳號登入，在這個帳號下申請 apiKey 的登入權限
//             let id = dbOnline.list(this._guid);
//             let updateStatus = (str) => dbOnline.status(this._guid, id, str);

//             // 去驗證鍵值是否能在交易所成功要資料
//             verifyExchangeAsync(id, apiKey, secretKey)
//                 .then((result) => {
//                     if (result) {
//                         // 驗證通過，client 那邊可以把回傳的值當作 sessionKey 存下來做自動登入使用
//                         updateStatus(`regist_success ${id} ${aesEncrypt(keys, '123456789987654321123456', 'f720b45f04e37c09')}`);

//                         // 第一次完成驗證，如果之前用別的裝置有完成驗證就不用再做
//                         !isVerify && dbUsers.regist(this._guid, id, Date.now());// 交易所登入成功後，改為完成現在時間

//                     }
//                     else {
//                         console.log('ping 失敗, key 是錯的!');
//                         updateStatus('regist_fail');
//                         // 用鍵值取資料失敗， TODO:要把localStorage 刪掉避免一直重複試錯
//                     }
//                 })
//                 .catch((error) => {
//                     console.log('ping 失敗error了!');
//                     updateStatus('regist_fail');
//                 });
//         }

//         //todo : 看是不是已登入下個狀態 dbOnline.status(id, 'logined');
//     }

//     // 用 id 進行登錄動作
//     begin(id) {
//         // 此id/nickname 是否完成驗證，未完成讓使用者再做一次驗證
//         dbUsers.verify(this._guid, id)
//             .then((data) => {
//                 console.log('isVerify:', data);
//                 const isVerify = data;
//                 isVerify                                // db 中是否完成第一次驗證
//                     ? this._connected(id)               // 新增為連線監聽對象，然後開始監聽並要求 client 跑 session_key 流程
//                     : dbOnline.status(this._guid, id, 'regist');       // 請使用者重走驗證流程 //TODO: 這個流程目前online 沒辦法聽到，查一下為什麼
//             });
//     }

//     _connected(id) {
//         addDispatcher(id, this, {
//             'session_key': this.cmd_session_key,            // 取得驗證後的 session key
//             'ping': this.cmd_ping,
//         });

//         // 開始監聽連線
//         connectListener(id);

//         // 做身份驗證，要把鍵值對過一遍，請client 送出 session_key
//         dbConnect.broadcast(id, 'session_key');


//         // client 這邊要做的
//         let client = true;//TEST
//         if (client) {
//             let skey = '123456';// 假的sessionKey，裡面是 apiKey 跟 scrietKey 加密後的字串
//             if (skey) {
//                 dbConnect.applicate(this._guid, id, `session_key ${skey}`);
//             }
//         }
//     }

//     finish(id) {
//         removeDispatcher(id, this);
//         this._disconnect(id);
//     }

//     _disconnect(id) {
//         // 移除上線狀態
//         dbOnline.status(this._guid, id, null);
//         // 發出通知給client
//         dbConnect.broadcast(id, 'disconnect');
//         // 從清單中移出
//         console.log('this._onlineUsers:', this._onlineUsers);
//         this._onlineUsers.find((userid, i) => {
//             if (userid === id) {
//                 this._onlineUsers.splice(i, 1);
//                 return true;
//             }
//         });

//         console.log('this._onlineUsers:', this._onlineUsers);
//     }

//     // 接收到 session_key 的 command : client 要主動送，server 檢查結果後回傳 登入驗證是否成功
//     cmd_session_key(id, key, value) {
//         console.log('session_key', value);
//         // if (value) {
//         //     // 解密 value 以取出鍵值
//         //     let inputKeys = JSON.parse(aesDecrypt(value, '123456789987654321123456', 'f720b45f04e37c09'));
//         //     // if (!inputKeys)
//         //     //     return;
//         //     console.log('inputKeys:', inputKeys);// 不知道回來是什麼樣子，會不會沒東西

//         //     // 從localStorage 拿id的暫存資料，沒通過驗證就拿不到，直接跳開
//         //     let { apiKey, secretKey } = localStorage.getItem(`session_keys`);
//         //     // 跟伺服本地資料比對 0失敗 1成功
//         //     let result = (apiKey === inputKeys.apiKey && secretKey === inputKeys.secretKey) ? '1' : '0';
//         //     // 通知client 登入結果
//         //     dbConnect.broadcast(id, 'login', result);


//         // // client 這邊要做的 notify_login
//         // let client = false;
//         // if (client) {
//         //     let success = result;// TODO: 其實這邊是 server 的 result ，要換回 notify_session_key 的 value
//         //     if (success) {
//         //         // 登入驗證成功
//         //         // dbConnect.applicate(id, 'login_connected');
//         //     } else {
//         //         // 登入驗證失敗，請使用者重新輸入 apiKey 跟 secretKey
//         //         // 第一次是自動送出，驗證失敗後要顯示輸入介面
//         //         // 正常來說client 沒有 skey 的話不應該執行自動送出而要直接顯示輸入介面；而自動送出也不應該會有登入驗證失敗的情況
//         //         const newIdsKey = push(child(usersRef)).key;
//         //         dbOnline.status(this._guid, newIdsKey, `regist ${apiKey} ${secretKey}`);
//         //         // 聽處理server 的結果
//         //         onlineList((data) => {
//         //             if (data.indexOf('regist_success') === 0) {
//         //                 let splitAry = data.split(' ');
//         //                 let newId = splitAry[2];
//         //                 // 存newId 與sessionKey 在client 本地
//         //                 let splitAry = data.split(' ');
//         //                 let sessionKey = splitAry[1];
//         //                 // {[newId]:sessionKey}
//         //             } else if (data === 'regist_fail') {

//         //             }

//         //         });
//         //     }
//         // }

//         //TEST client
//         dbConnect.applicate(id, 'ping', Date.now());
//     }

//     // 做 ping pong
//     cmd_ping(id, key, value) {
//         // 連線檢查: client 要接pong，然後等 delayMS 的時間後再送出 ping 以保持連線確認
//         dbConnect.broadcast(id, 'pong');

//         // client 固定時間送出 ping ，計時未再送ping 的話就斷線 TODO: 看是不是多個幾次再斷線？
//         let timestamp = parseInt(value, 10);
//         this._timoutInterval && clearTimeout(this._timoutInterval);
//         this._timoutInterval = setTimeout(() => {
//             // 等待超時
//             if (Date.now() - timestamp > delayMS) {
//                 console.log(id, '等待超時');
//                 // 結束登入狀態
//                 this.finish(id);
//             }
//         }, delayMS + 1000);// 延遲時間再多1秒緩衝


//         // client 這邊要做的，記得一開始要先送給server ping， 才會一直保持
//         let client = false;
//         if (client) {
//             // 收到就立刻回送
//             dbConnect.applicate(id, 'ping', Date.now());
//         }

//     }
// }

// // var UserLogin = function (guid) {

// //     // /**
// //     //  * 註冊新的api 帳號
// //     //  * @param {strin} guid google 使用者帳號
// //     //  */
// //     // this.regist = function (apiKey, secretKey) {
// //     //     if (!apiKey || !secretKey) {
// //     //         // client 用google 帳號登入，在這個帳號下申請 apiKey 的登入權限
// //     //         let id = onlineList(guid);

// //     //         // 去驗證鍵值是否能在交易所成功要資料，成功後 notify login 送2
// //     //         verifyKey(id, apiKey, secretKey);
// //     //         // return;
// //     //     }
// //     // };

// //     // // 建起來的時候開始監聽上線使用者
// //     // onlineListener();

// //     // 開始登入
// //     this.startLogin = function (id) {

// //         dbUsers.verify(guid, id, function (data) {
// //             // 做身份驗證，要把鍵值對過一遍
// //             dbConnect.broadcast(id, 'session_key');
// //             // 從User 資料中取得建立的時間戳
// //             isVerify = data;
// //         });
// //     };

// //     let buffNotify = '';
// //     this.updateOnlineStatus = function (status) {
// //         // 不處理連續同樣的notify
// //         if (buffNotify === status) return;

// //         buffNotify = status;
// //         // client 上線打招呼
// //         if (status === 'hello') {
// //             // 檢查是否為線上使用者：若否，則加入連線監聽
// //             if (onlineUsers.indexOf(id) === -1) {
// //                 setOnline(id, true);
// //             }
// //             // 如果已經有連線(hello 時onlineUsers 已經有此id存在)，可能是重複登入
// //             else {
// //                 console.log('重複登入');
// //                 // TODO:可能client 做一下請求，把狀態丟一下通知id.output 為重複登入需要踢出
// //                 dbOnline.status(this._guid, id, 'muti_login');
// //             }
// //         }
// //         // regist 是用 guid
// //         else if (status.indexOf('regist') === 0) {
// //             // 用guid 註冊
// //             let splitAry = status.split(' ');
// //             let apiKey = splitAry[1];
// //             let secretKey = splitAry[2];
// //             if (!apiKey || !secretKey) {
// //                 // client 用google 帳號登入，在這個帳號下申請 apiKey 的登入權限
// //                 let id = onlineList(guid);
// //                 // 去驗證鍵值是否能在交易所成功要資料，成功後 notify login 送2
// //                 verifyExchangeAsync(id, apiKey, secretKey);
// //             }
// //         }
// //     }

// //     // //TEST: output session_key 後 client 要送出的
// //     // let clientKeyData = JSON.stringify({ apiKey: 'AAA', secretKey: 'BBB' });
// //     // let encryptData = aesEncrypt(clientKeyData, '123456789987654321123456', 'f720b45f04e37c09');
// //     // dbConnect.applicate(id, 'session_key', encryptData);

// //     this.notify_session_key = function (id, key, value) {
// //         if (value) {
// //             // 解密 value 以取出鍵值
// //             let inputKeys = JSON.parse(aesDecrypt(value, '123456789987654321123456', 'f720b45f04e37c09'));
// //             if (!inputKeys)
// //                 return;

// //             // 從localStorage 拿id的暫存資料，沒通過驗證就拿不到，直接跳開
// //             let { apiKey, secretKey };

// //             // 跟伺服本地資料比對 0失敗 1成功
// //             let result = (apiKey === inputKeys.apiKey && secretKey === inputKeys.secretKey) ? '1' : '0';
// //             // 通知client 登入結果
// //             dbConnect.broadcast(id, 'login', result);
// //         }
// //     };

// //     // 完成連線流程
// //     this.notify_connected = function () {
// //         removeDispatcher(this);
// //     };

// //     addDispatcher(this, {
// //         'session_key': this.notify_session_key,     // 取得驗證後的 session key
// //         'connected': this.notify_connected,         // 完成連線流程後，登入器不需要一直維持連線
// //     });
// // };


// // // 線上使用者
// // var onlineUsers = [];
// // const setOnline = function (id, boo) {
// //     if (boo) {
// //         // 回應client 的打招呼，讓client 可以開始連線後的工作了
// //         dbOnline.status(guid, id, 'olleh');
// //         // 新增為連線監聽對象
// //         connectListener(id);
// //         //
// //         onlineUsers.push(id);
// //     }
// //     else {
// //         // 移除上線狀態
// //         dbOnline.status(guid, id, null);
// //         // 發出通知給client
// //         dbConnect.broadcast(id, 'disconnect');
// //         // 從清單中移出
// //         onlineUsers.find((userid, i) => {
// //             if (userid === id) {
// //                 onlineUsers.splice(i, 1);
// //                 return true;
// //             }
// //         });
// //     }
// //     console.log('onlineUsers:', onlineUsers);
// // };

// // 驗證傳來的鍵值
// const verifyExchangeAsync = function (id, apiKey, secretKey) {
//     // TODO: 鍵值用localStorage 暫存的，這邊要暫存進去，讓api 那邊直接讀
//     let keys = { apiKey, secretKey };
//     JSON.stringify(keys);

//     // 鍵有缺失，用client 傳來的去跟交易所做登入動作，試送一個ping 值看是否成功連上
//     let api = require('../../data/binance/api');
//     return api.ping(id);
// };

// module.exports = UserLogin;