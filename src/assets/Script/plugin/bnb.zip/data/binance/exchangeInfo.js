const api = require('./api'),
    LocalStorage = require('node-localstorage').LocalStorage,
    localStorage = new LocalStorage('./scratch');
let tradeRules = null;
const update = function (ownerId, forceUpdate = false) {
    // 非強制更新時，優先使用本地的暫存資料
    if (!forceUpdate) {
        if (tradeRules) {
            return Promise.resolve(tradeRules);
        }
        let data = localStorage.getItem('bnb_exchange_info');
        if (data) {
            tradeRules = JSON.parse(data);
            return Promise.resolve(tradeRules);
        }
    }
    return api.exchangeInfo(ownerId)
        .then((raw) => {
            // raw = {
            //     "timezone": "UTC",
            //     "serverTime": 1508631584636,
            //     "rateLimits": [{
            //         "rateLimitType": "REQUESTS_WEIGHT",
            //         "interval": "MINUTE",
            //         "intervalNum": 1,
            //         "limit": 1200 //每分钟调用的所有接口权重之和不得超过1200
            //     }, {
            //         "rateLimitType": "ORDERS",
            //         "interval": "SECOND",
            //         "intervalNum": 1,
            //         "limit": 10 //每秒钟所有订单/撤单次数不得超过10
            //     }, {
            //         "rateLimitType": "ORDERS",
            //         "interval": "DAY",
            //         "intervalNum": 1,
            //         "limit": 100000 //每天订单/撤单不得超过10万
            //     }, {
            //         "rateLimitType": "RAW_REQUESTS",
            //         "interval": "MINUTE",
            //         "intervalNum": 5,
            //         "limit": 5000 //每5分钟调用订单次数不得超过5000
            //     }],
            //     "exchangeFilters": [],
            //     "symbols": [{
            //         // "symbol": "ETHBTC",
            //         "symbol": "BNBBUSD",
            //         "status": "TRADING",
            //         "baseAsset": "ETH",
            //         "quoteAsset": "BTC",
            //         "baseAssetPrecision": 8,
            //         "quotePrecision": 8,
            //         "orderTypes": ["LIMIT", "MARKET"],
            //         "icebergAllowed": false,
            //         "filters": [{
            //             "filterType": "PRICE_FILTER",
            //             "minPrice": "0.00000100",
            //             "maxPrice": "100000.00000000",
            //             "tickSize": "0.00000100"
            //         }, {
            //             "filterType": "LOT_SIZE",
            //             "minQty": "0.00100000",
            //             "maxQty": "100000.00000000",
            //             "stepSize": "0.00100000"
            //         }, {
            //             "filterType": "MIN_NOTIONAL",
            //             "minNotional": "0.00100000",
            //             "applyToMarket": true,
            //             "avgPriceMins": 5
            //         }]
            //     }]
            // };
            let getStringArray = (value) => value ? value.map(v => v.toString()) : [];
            let getFilterInfo = (value) => {
                let { minPrice, maxPrice, tickSize } = value.find(v => v.filterType == 'PRICE_FILTER');
                let { minQty, maxQty, stepSize } = value.find(v => v.filterType == 'LOT_SIZE');
                let priceMinFilter = value.find(v => v.filterType == 'MIN_NOTIONAL');
                // let orderMaxFilter = value.find(v => v.filterType == 'MAX_NUM_ORDERS');
                // let algoMaxFilter = value.find(v => v.filterType == 'MAX_NUM_ALGO_ORDERS');
                return {
                    price: {
                        min: parseFloat(minPrice),                      // 最小訂單價格
                        max: parseFloat(maxPrice),                      // 最大訂單價格
                        step: parseFloat(tickSize),                     // 增減的差距大小
                        // precision: tickSize.length > 1 ? tickSize.split('.')[1].length : 0, // 精度
                        precision: Math.max(0, tickSize.indexOf('1') - 1),// 精度
                    },
                    quantity: {
                        min: parseFloat(minQty),                        // 最小訂單數量
                        max: parseFloat(maxQty),                        // 最大訂單數量
                        step: parseFloat(stepSize),                     // 增減的差距大小
                        // precision: stepSize.length > 1 ? stepSize.split('.')[1].length : 0,// 精度
                        precision: Math.max(0, stepSize.indexOf('1') - 1),// 精度
                    },
                    // payMin: parseFloat(priceMinFilter.minNotional),     // 訂單最低金額，金额的单位是quoteAsset，可以通过 price * quantity得到。(必要時可參考applyToMarket 定義)
                    // orderMax: getInt(orderMaxFilter.maxNumOrders),  // 交易对最多允许的挂单数量（不包括已关闭的订单） 普通订单与条件订单均计算在内
                    // alogMax: getInt(algoMaxFilter.maxNumAlgoOrders),// 多条件单数：訂單最多允许的条件单数量（不包括已关闭的订单）
                };
            };
            const getExchangeInfo = (value) => ({
                // symbol: value.symbol,
                status: value.status,
                orderTypes: getStringArray(value.orderTypes),           // 把訂單可處理類型列出來: LIMIT (限價單) 
                filters: getFilterInfo(value.filters),                  // 把訂單的處理條件列出來
            });
            tradeRules = {};
            raw.symbols.forEach((rawData) => {
                let { status, symbol } = rawData;
                // 只紀錄能交易的
                if (status === 'TRADING') {
                    tradeRules[symbol] = getExchangeInfo(rawData);
                }
            });
            // 將處理好的資料存入本地，下次重複使用就不必再處理
            const data = JSON.stringify(tradeRules);
            localStorage.setItem('bnb_exchange_info', data);
            return tradeRules;
        });
};
/**
 * 指定 symbol 後取得資訊，或是全部回傳
 * @param {string} symbol 指定的交易對資料，不指定時會回傳全部的交易所規則資料
 * @returns 
 */
const getTradeRules = function (symbol) {
    // 未指定，全部丟回去
    if (!symbol) return tradeRules;
    // 回傳指定交易對的規則
    return tradeRules && tradeRules[symbol];
};
/**
 * 依交易幣種，將代入的 Base asset 轉為交易所能接受的精度
 * @param {number} symbol 
 * @param {number} value 
 * @param {number} setpFix 間距修正，如果掛單希望向上/下拉一點價格時，填入希望間格多少 step (要用整數)
 * @returns 
 */
const getPrecisionPrice = function (symbol, value, setpFix = 0) {
    const filters = getTradeRules(symbol).filters;
    if (filters.price.step == 0) {
        console.log('好像會有filters.price.step == 0 的情況，代表不限制，所以這邊擋一下 filters.price:', filters.price);
        return precisionFloor(value + setpFix, filters.price);
    }
    return precisionFloor(value + setpFix * filters.price.step, filters.price);
};
const getPrecisionVariation = function (symbol, value) {
    const filters = getTradeRules(symbol).filters;
    if (filters.price.step == 0) {
        console.log('好像會有filters.price.step == 0 的情況，代表不限制，所以這邊擋一下 filters.price:', filters.price);
        return precisionRound(value, filters.price);
    }
    return precisionRound(value, filters.price);
};
/**
 * 依交易幣種，將代入的 Quantity asset 轉為交易所能接受的精度
 * @param {string} symbol 
 * @param {number} value 
 * @returns 
 */
const getPrecisionQuanity = function (symbol, value) {
    return precisionFloor(value, getTradeRules(symbol).filters.quantity);
};
/**
 * 代入後取適合該幣交易的小數點無條件捨去
 * @param {number} value 
 * @param {number} param1 exchangeInfo 拿到的 filter
 * @returns 
 */
const precisionFloor = function (value, { precision }) {
    if (precision === 0) return value;
    return parseFloat(value.toFixed(precision));
}
/**
 * 代入後取適合該幣交易的小數點最大位數四捨五入
 * @param {number} value 帶入要抓出小數點位數的值
 * @param {number} param1 exchangeInfo 拿到的 filter
 * @returns 
 */
const precisionRound = function (value, { precision }) {
    if (precision === 0) return Math.round(value);
    const expand = Math.pow(10, precision);
    return Math.round(value * expand) / expand;
};
module.exports = {
    update,
    getTradeRules,              // 取得交易所的交易限制規範
    getPrecisionPrice,          // 取得合乎交易所精度的價格
    getPrecisionVariation,      // 取得價格變動值，四捨五入後合適的精度
    getPrecisionQuanity,        // 取得合乎交易所精度的倉位大小
};