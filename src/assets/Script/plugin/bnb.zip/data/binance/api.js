/**
 * https://github.com/binance/binance-spot-api-docs/blob/master/rest-api_CN.md
 */
const request = require('./request');
const { SecurityType, Interval, EndPoints } = request;
var difftime = 0;
// 
const ping = function (ownerId) {
    return request.send(ownerId, EndPoints.PING);
};
// 伺服器時間
const servertime = function (ownerId) {
    return request.send(ownerId, EndPoints.TIME)
        .then((raw) => {
            // raw = {
            //     "serverTime": 1499827319559
            // };
            const serverTime = parseInt(raw.serverTime, 10);
            difftime = serverTime - Date.now();
            return serverTime;
        });
};
// 交易规范信息
const exchangeInfo = function (ownerId) {
    return request.send(ownerId, EndPoints.EXCHANGE_INFO);
};
/**
 * 深度圖 1-100	權重 1
 * @param {string} ownerId 
 * @param {string} symbol 
 * @param {number} limit 默认 100; 最大 5000. 可选值:[5, 10, 20, 50, 100, 500, 1000, 5000] limit=0 返回全部orderbook，但数据量会非常非常非常非常大！
 * @returns 
 */
const depth = function (ownerId, symbol, limit = 100) {
    return request.send(ownerId, EndPoints.DEPTH, { symbol, limit });
};
/**
 * 近期成交
 * @param {String} symbol 
 * @param {Number} limit Default 500; max 1000.
 */
const trades = function (ownerId, symbol, limit = 5) {
    return request.send(ownerId, EndPoints.TRADES, { symbol, limit });
};
/**
 * 查询历史成交
 * @param {String} symbol 
 * @param {Number} limit Default 500; max 1000.
 * @param {Number} fromId 从哪一条成交id开始返回. 缺省返回最近的成交记录
 */
const historicalTrades = function (ownerId, symbol, limit = 5, fromId) {
    return request.send(ownerId, EndPoints.HISTORICAL_TRADES, { symbol, limit, fromId });
};
/**
 * // 近期成交(归集)：与trades的区别是，同一个taker在同一时间同一价格与多个maker的成交会被合并为一条记录
 * @param {String} symbol 
 * @param {Number} limit 默认 500; 最大 1000
 * @param {Number} fromId 从包含fromID的成交开始返回结果
 * @param {Number} startTime 从该时刻之后的成交记录开始返回结果
 * @param {Number} endTime 返回该时刻为止的成交记录
 */
const aggTrades = function (ownerId, symbol, limit = 5, fromId, startTime, endTime) {
    return request.send(ownerId, EndPoints.AGG_TRADES, { symbol, limit, fromId });
};
/**
 * K線圖 权重: 1
 * @param {String} symbol 
 * @param {String} interval 間隔
 * @param {Number} limit 筆數     Default 500; max 1000.
 * @param {Number} startTime 設定時間區隔
 * @param {Number} endTime 設定時間區隔
 */
const kline = function (ownerId, symbol, interval, limit = 20, startTime, endTime) {
    return request.send(ownerId, EndPoints.KLINE, { symbol, interval, limit, startTime, endTime });
};
// 当前平均价格
const averagePrice = function (ownerId, symbol) {
    return request.send(ownerId, EndPoints.AVERAGE_PRICE, { symbol });
};
// 24hr价格变动情况 權重1
// type : FULL or MINI.如果不提供, 默认值为 FULL
const ticker24hr = function (ownerId, symbol, type) {
    // 不携带symbol参数会返回全部交易对数据，不仅数据庞大，而且权重极高 (40)
    return request.send(ownerId, EndPoints.TICKER_24HR, { symbol, type });
};
// 1-20	權重 1
// const ticker24hr = function (ownerId, symbols, type) {
// 最新价格接口
const tickerPrice = function (ownerId, symbol) {
    return request.send(ownerId, EndPoints.TICKER_PRICE, { symbol });
};
// 下單: type 對應需要送的參數，要參考一下文件
const order = function (ownerId, symbol, side, type, timeInForce, quantity, price, recvWindow) {
    if (!symbol) {
        console.log('=======下單測試=====');
        // return request.send(ownerId, EndPoints.TEST_ORDER, {})
        return new Promise((resolve) => {
            resolve({
                symbol: "NAERTTEST",
                "orderId": Math.round(Math.random() * 1000000),
                "orderListId": Math.round(Math.random() * 1000000),
                "clientOrderId": Math.round(Math.random() * 1000000),
                // "transactTime": Date.now(),
                "transactTime": Date.now() - 11 * 60 * 1000,//撤單用的
                "price": price,
                "origQty": quantity,
                "executedQty": quantity / 2,
                "status": "PARTIALLY_FILLED",
                // "executedQty": quantity,
                // "status": "FILLED",
                "cummulativeQuoteQty": quantity,
                "timeInForce": timeInForce,
                "type": type,
                "side": side,
            });
        });
    }
    const timestamp = Date.now() + difftime;
    return request.send(ownerId, EndPoints.ORDER, { symbol, side, type, timeInForce, quantity, price, recvWindow, timestamp });
};
/**
 * 撤單
 * @param {String} symbol 
 * @param {String} orderId 或origClientOrderId 其一要送 
 * @param {String} origClientOrderId 
 * @param {String} newClientOrderId     用户自定义的本次撤销操作的ID(注意不是被撤销的订单的自定义ID)。如无指定会自动赋值。
 * @param {Number} recvWindow 不能大于 60000
 */
const deleteOrder = function (ownerId, symbol, orderId, origClientOrderId, newClientOrderId, recvWindow) {
    // orderId 或origClientOrderId 其一要送
    if (!orderId && !origClientOrderId)
        return Promise.reject('fail orderId or origClientOrderId!');
    const timestamp = Date.now() + difftime;
    return request.send(ownerId, EndPoints.DELETE_ORDER, { symbol, orderId, origClientOrderId, newClientOrderId, recvWindow, timestamp });
};
/**
 * 撤消挂单再下单
 * @param {string} ownerId 
 * @param {string} symbol 
 * @param {string} side 
 * @param {string} type 
 * @param {string} cancelReplaceMode 指定类型: STOP_ON_FAILURE - 如果撤消订单失败将不会继续重新下单; ALLOW_FAILURE - 不管撤消订单是否成功都会继续重新下单。
 * @param {string} timeInForce 定义了订单多久能够失效: GTC 成交为止，订单会一直有效，直到被成交或者取消;  IOC    无法立即成交的部分就撤销，订单在失效前会尽量多的成交; FOK 无法全部立即成交就撤销，如果无法全部成交，订单会失效。
 * @param {number} quantity 
 * @param {number} quoteOrderQty 
 * @param {number} price 
 * @param {string} cancelNewClientOrderId 
 * @param {string} cancelOrigClientOrderId 
 * @param {string} cancelOrderId 
 * @param {string} newClientOrderId 
 * @param {number} strategyId 
 * @param {string} strategyType 
 * @param {string} stopPrice 
 * @param {*} trailingDelta  用于 STOP_LOSS, STOP_LOSS_LIMIT, TAKE_PROFIT, 和 TAKE_PROFIT_LIMIT 类型的订单.
 * @param {*} icebergQty 仅有限价单(包括条件限价单与限价做事单)可以使用该参数，含义为创建冰山订单并指定冰山订单的尺寸
 * @param {*} newOrderRespType 指定响应类型 ACK, RESULT, or FULL; MARKET 与 LIMIT 订单默认为FULL, 其他默认为ACK.
 * @param {*} selfTradePreventionMode   允许的 ENUM 取决于交易对的配置。支持的值有 EXPIRE_TAKER，EXPIRE_MAKER，EXPIRE_BOTH，NONE
 * @param {number} recvWindow 不能大于 60000
 * @returns 
 */
const replaceOrder = function (ownerId, symbol, side, type, cancelReplaceMode, timeInForce, quantity, quoteOrderQty, price,
    cancelNewClientOrderId, cancelOrigClientOrderId, cancelOrderId, newClientOrderId, strategyId, strategyType,
    stopPrice, trailingDelta, icebergQty, newOrderRespType, selfTradePreventionMode, recvWindow) {
    const timestamp = Date.now() + difftime;
    return request.send(ownerId, EndPoints.CANCEL_REPLACE_ORDER, {
        symbol, side, type, cancelReplaceMode, timeInForce, quantity, quoteOrderQty, price,
        cancelNewClientOrderId, cancelOrigClientOrderId, cancelOrderId, newClientOrderId, strategyId, strategyType,
        stopPrice, trailingDelta, icebergQty, newOrderRespType, selfTradePreventionMode, recvWindow, timestamp
    });
};
/**
 * 最近的訂單
 * @param {String} symbol 
 * @param {Number} recvWindow 回應時間，不能高於5000
 */
const openOrders = function (ownerId, symbol, recvWindow) {
    const timestamp = Date.now() + difftime;
    return request.send(ownerId, EndPoints.OPEN_ORDERS, { symbol, recvWindow, timestamp });
};
/**
 * 最近的訂單
 * @param {String} symbol 
 * @param {String} orderId 或origClientOrderId 其一要送 
 * @param {String} origClientOrderId
 * @param {Number} recvWindow 回應時間，不能高於5000
 */
const checkOrder = function (ownerId, symbol, orderId, origClientOrderId, recvWindow) {
    const timestamp = Date.now() + difftime;
    // orderId 或origClientOrderId 其一要送
    if (!orderId && !origClientOrderId)
        return Promise.reject('fail orderId or origClientOrderId!');
    return request.send(ownerId, EndPoints.CHECK_ORDER, { symbol, orderId, origClientOrderId, recvWindow, timestamp });
};
// 查询所有订单（包括历史订单）
const allOrders = function (ownerId, symbol, limit, orderId, startTime, endTime, recvWindow) {
    // orderId 只返回此orderID之后的订单，缺省返回最近的订单
    const timestamp = Date.now() + difftime;
    return request.send(ownerId, EndPoints.ALL_ORDERS, { symbol, limit, orderId, startTime, endTime, recvWindow, timestamp });
};
// 账户信息
const account = function (ownerId, recvWindow) {
    const timestamp = Date.now() + difftime;
    // console.log('account timestamp:', timestamp);
    return request.send(ownerId, EndPoints.ACCOUNT, { recvWindow, timestamp });
};
// 账户成交历史
const myTrades = function (ownerId, symbol, limit, fromId, startTime, endTime, recvWindow) {
    const timestamp = Date.now() + difftime;
    return request.send(ownerId, EndPoints.MY_TRADES, { symbol, limit, fromId, startTime, endTime, recvWindow, timestamp });
};
module.exports = {
    ping,
    servertime,
    /** exchangeInfo */
    exchangeInfo,
    /** historical */
    kline,
    depth,
    trades,
    /** ticket */
    averagePrice,
    ticker24hr,
    tickerPrice,
    order,
    // testOrder,
    deleteOrder,
    replaceOrder,
    openOrders,
    checkOrder,
    allOrders,
    /** account */
    account,
}