const { getPrecisionPrice, getPrecisionQuanity, getTradeRules } = require('./exchangeInfo');
const { Interval } = require('./request');
const market = require('./market');

const oscillation = function (ownerId, symbol, interval, limit) {
    let lastUpdateTime = 0;
    let currTime = Date.now();
    let onlyResult = true;
    const precision = getTradeRules(symbol).filters.price.precision;
    return market.kline(ownerId, symbol, lastUpdateTime, currTime, interval, limit, onlyResult)
        .then((rawData) => {
            let klineData = rawData.map((data) => {
                // console.log('data', data);
                const opening = data[market.KLINE.Opening];     // 开盘价 
                const highest = data[market.KLINE.Highest];     // 最高价 
                const lowest = data[market.KLINE.Lowest];       // 最低价 
                const closing = data[market.KLINE.Closing];     // 收盘价(当前K线未结束的即为最新价) 
                const valume = data[market.KLINE.Valume];       // 成交量 
                const variation = highest - lowest;            // 振盪變動量 
                const rise = parseFloat(((closing - opening) / opening).toFixed(4));  // 漲幅 
                // console.log('closing:', closing, 'opening:', opening, "/variation:", variation, '=', rise);
                // const time = new Date(data[0]);
                // console.log(time.getHours(), ':', time.getMinutes(), ':', time.getSeconds());
                return { opening, highest, lowest, closing, valume, variation, rise };
            });
            const setQuarterLevel = (values, hub, precision) => {
                let highValues = [], lowValues = [];
                values.forEach(x => x > hub ? highValues.push(x) : lowValues.push(x));
                const top = Math.max(...highValues);
                const bottom = Math.min(...lowValues);
                return [
                    parseFloat(top.toFixed(precision)),
                    parseFloat((highValues.length > 0 ? highValues.reduce((sum, v) => sum + v, 0) / highValues.length : top).toFixed(precision)),
                    parseFloat((lowValues.length > 0 ? lowValues.reduce((sum, v) => sum + v, 0) / lowValues.length : bottom).toFixed(precision)),
                    parseFloat(bottom.toFixed(precision))
                ];
            };
            const highestPrice = Math.max(...klineData.map(x => x.highest)),
                lowestPrice = Math.min(...klineData.map(x => x.lowest));
            const variations = klineData.map(x => x.variation),
                hubVariation = variations.reduce((sum, v) => sum + v, 0) / variations.length,
                variationQuaterLevel = setQuarterLevel(variations, hubVariation, precision);
            const riseQuarterLevel = setQuarterLevel(klineData.map(x => x.rise), 0, 4);
            const hubPrice = parseFloat((klineData.map(x => x.closing).reduce((sum, v) => sum + v, 0) / klineData.length + hubVariation).toFixed(precision));
            const valume = klineData.reduce((sum, x) => sum + x.valume, 0);
            // todo 交易量可能用在跟 quoteVolume24hr 做比較，看是準備算平均的方式還是加總，要再想一下 ---> 用這邊的加總，24hr 的跟這邊加總不同且可能不一定是我需要的
            // 
            return { symbol, valume, price: [highestPrice, hubPrice, lowestPrice], variationQuaterLevel, riseQuarterLevel, closing: klineData[klineData.length-1].closing };
        });
}
const captureOscillation = function (ownerId, symbol, interval) {
    switch (interval) {
        case Interval.DAYS_1: return oscillation(ownerId, symbol, Interval.HOURS_02, 12);
        case Interval.HOURS_12: return oscillation(ownerId, symbol, Interval.HOURS_01, 12);
        case Interval.HOURS_08: return oscillation(ownerId, symbol, Interval.MINUTES_30, 16);
        case Interval.HOURS_02: return oscillation(ownerId, symbol, Interval.MINUTES_15, 16);
        case Interval.HOURS_01: return oscillation(ownerId, symbol, Interval.MINUTES_05, 12);
        case Interval.MINUTES_15: return oscillation(ownerId, symbol, Interval.MINUTES_01, 15);
        default:
            interval = Interval.MINUTES_05;
            console.log(interval, '非預設時間，請進行設定:目前回傳', interval);
            return oscillation(ownerId, symbol, Interval.HOURS_01, 5);
    }
}
const riseRateFilter = function (ownerId, symbol, highRate, lowRate) {
    // 最高區間2小時吧，再多可能就不適合交易，可以休息2小時再看看 (中間做鯉躍龍門的檢查)；或是可以直接找別的交易對
    const intervals = [Interval.MINUTES_15, Interval.HOURS_01, Interval.HOURS_02];
    return new Promise((resolve, reject) => {
        const loop = (index) => new Promise((resolve2) => {
            captureOscillation(ownerId, symbol, intervals[index])
                .then(oscillation => {
                    let [highestRate, topRate, bottomRate, lowestRate] = oscillation.riseQuarterLevel;
                    if (topRate >= highRate && bottomRate <= lowRate) {
                        console.log('ok:', intervals[index], oscillation);
                        resolve2({ interval: intervals[index], oscillation });
                    } else {
                        index++;
                        if (index < intervals.length)
                            loop(index);
                        else
                            resolve2({ interval: intervals[index], oscillation });
                    }
                })
                .catch((error) => reject(error));
        });
        return loop(0);
    });
}

// 找出短線波大最大的
// const getOscillationRiseMax = function (ownerId) {
//     // var rule = getTradeRules();
//     var symbols = Object.keys(getTradeRules()).filter((symbol) => symbol.indexOf('USDT') > -1);
//     // var oscillationList = [];

//     return Promise.all(symbols.map((symbol) => captureOscillation(ownerId, symbol, Interval.MINUTES_15)))
//         .then((list) => {
//             console.log("length:", list.length);
//             var riseRate = Math.max(...list.map(({ riseQuarterLevel }) => riseQuarterLevel[0] + riseQuarterLevel[3]));
//             return list.find(({ riseQuarterLevel }) => riseQuarterLevel[0] + riseQuarterLevel[3] == riseRate);
//         });

// };

const findTopList = function (ownerId, symbols, length) {
    return Promise.all(symbols.map((symbol) => oscillation(ownerId, symbol, Interval.MINUTES_05, 48)))
        .then((list) => {
            return list.sort((a, b) => {//大到小排序
                // { symbol, valume, price: [highestPrice, hubPrice, lowestPrice], variationQuaterLevel, riseQuarterLevel }
                // 不要用[0]的最大值，而要用[1]的大於均值的平均值；另外再乘以價格，不然價值不高但看似波動很大，其實賺沒多少
                return b.riseQuarterLevel[1] * b.price[1] - a.riseQuarterLevel[1] * a.price[1];
            })
                .slice(0, length * 5) // 多抓一些來處理(守住用價值抓出來的前段班)
                .sort((a, b) => b.riseQuarterLevel[1] - a.riseQuarterLevel[1])
                .slice(0, length * 2)
                .sort((a, b) => b.valume * b.price[1] - a.valume * a.price[1])
                .slice(0, length)
                // 因為最後是用交易總價排序，所以可能漲跌不是那麼好看。再做一次排序，取最佳的前 length 筆
                .sort((a, b) => b.riseQuarterLevel[1] - a.riseQuarterLevel[1]);
        });


    // 檢查4小時的內容
    return Promise.all(symbols.map((symbol) => oscillation(ownerId, symbol, Interval.MINUTES_05, 48)))
        .then((list) => {
            symbols = list.sort((a, b) => {//大到小排序
                // { symbol, valume, price: [highestPrice, hubPrice, lowestPrice], variationQuaterLevel, riseQuarterLevel }
                // 不要用[0]的最大值，而要用[1]的大於均值的平均值；另外再乘以價格，不然價值不高但看似波動很大，其實賺沒多少
                return b.riseQuarterLevel[1] * b.price[1] - a.riseQuarterLevel[1] * a.price[1];
            })
                .slice(0, length * 5) // 多抓一些來處理
                .map(x => x.symbol);

            console.log('第一次處理結果，有', length * 5, '筆但還是先列', length, '就好:', symbols.slice(0, length));
            return Promise.all(symbols.map((symbol) => oscillation(ownerId, symbol, Interval.MINUTES_30, 8)))
        })
        .then((list) => {
            // 第二次處理，也是4小時，但kline 抓30分鐘的，所以漲跌應該比較大 todo 看是不是有必要，不然就用前面每1分鐘處理的漲跌就好
            return list.sort((a, b) => {//大到小排序
                // { symbol, valume, price: [highestPrice, hubPrice, lowestPrice], variationQuaterLevel, riseQuarterLevel }
                // 不要用[0]的最大值，而要用[1]的大於均值的平均值；跟上面不同，只看漲跌大的，不看價值了
                return b.riseQuarterLevel[1] - a.riseQuarterLevel[1];
            }).slice(0, length) // 只回傳指定要的數量
        });

};


module.exports = {
    oscillation,
    captureOscillation,
    // getOscillationRiseMax,
    riseRateFilter,
    findTopList,
};