const api = require('./api');
const { getPrecisionQuanity } = require('./exchangeInfo');
const tickerPrice = function (ownerId, symbol) {
    return api.tickerPrice(ownerId, symbol)
        .then((result) => {
            // result = {
            //     price: this._fakeOrderPrice,
            // };
            if (result.code) {
                return Promise.reject(result);
            }
            return parseFloat(result.price);
        });
};
const order = function (ownerId, symbol, side, quantity, price, recvWindow) {
    const timeInForce = 'GTC', type = 'MARKET';
    return api.order(ownerId, symbol, side, type, timeInForce, quantity, price, recvWindow)
        .then((result) => {
            // Response RESULT: 返回速度居中，返回吃单成交的少量信息
            // result = {
            //     "symbol": symbol,//"BTCUSDT",
            //     "orderId": Math.round(Math.random() * 1000000),
            //     "clientOrderId": "6gCrw2kRUAF9CvJDGP16IP",
            //     "transactTime": Date.now(),//1507725176595,
            //     "price": price,//"1.00000000",
            //     "origQty": "10.00000000",
            //     "executedQty": Math.random() * 10000 % this._fakeOrderNum,//"10.00000000",
            //     "cummulativeQuoteQty": "10.00000000",
            //     "status": "FILLED",
            //     "timeInForce": "GTC",
            //     "type": "MARKET",
            //     "side": side,//"SELL"
            // };
            // cc.log('可出單並產生隨機掛單', symbol, side, '訂單:[', result.orderId, ']:', price);
            if (result.code) {
                return Promise.reject(result);
            }
            // 返回orderId
            return orderTicketData('ORDER', result);
        });
};
const cancel = function (ownerId, symbol, orderId) {
    return api.deleteOrder(ownerId, symbol, orderId)
        .then((result) => {
            // result = {
            //     clientOrderId: "OBuEzZgsO5tF1DruPIgCSM",
            //     cummulativeQuoteQty: "0.00000000",
            //     executedQty: "0.00000000",
            //     orderId: 131973573,
            //     orderListId: -1,
            //     origClientOrderId: "MHCk8hseTsFiO4lZEOHtsP",
            //     origQty: "10.00000000",
            //     price: "36.00000000",
            //     side: "SELL",
            //     status: "CANCELED",
            //     symbol: "BNBBUSD",
            //     timeInForce: "GTC",
            //     type: "LIMIT",
            //     transactTime": 1507725176595,//TODO:這個好像沒複製到，有空測試時可以確認一下
            // }//TODO: 如果這單已經被刪過再重複傳就會回傳error400，看怎麼處理盡量不要發生這種情況
            // return {
            //     orderId: getString(result.orderId),
            //     side: getString(result.side),
            //     transactTime: getInt(result.transactTime),
            // };
            if (result.code) {
                return Promise.reject(result);
            }
            // 返回orderId
            return orderTicketData('DELETE_ORDER', result);
        });
};
const replace = function (ownerId, symbol, orderTicket, price) {
    const side = orderTicket.side;
    const quantity = orderTicket.origQty - orderTicket.executedQty;
    // quoteOrderQty???
    const cancelOrderId = orderTicket.orderId;
    const timeInForce = 'GTC', type = 'MARKET', newOrderRespType = 'RESULT';
    return api.replaceOrder(ownerId, symbol, side, type, 'STOP_ON_FAILURE', timeInForce, quantity, quoteOrderQty, price,
        cancelNewClientOrderId, cancelOrigClientOrderId, cancelOrderId, newClientOrderId, strategyId, strategyType,
        stopPrice, trailingDelta, icebergQty, newOrderRespType, selfTradePreventionMode, recvWindow)
        .then((result) => {
            // Response RESULT: 返回速度居中，返回吃单成交的少量信息
            // result = {
            //     // 撤单和下单都成功
            //     "cancelResult": "SUCCESS",
            //     "newOrderResult": "SUCCESS",
            //     "cancelResponse": {
            //         "symbol": "BTCUSDT",
            //         "origClientOrderId": "DnLo3vTAQcjha43lAZhZ0y",
            //         "orderId": 9,
            //         "orderListId": -1,
            //         "clientOrderId": "osxN3JXAtJvKvCqGeMWMVR",
            //         "price": "0.01000000",
            //         "origQty": "0.000100",
            //         "executedQty": "0.00000000",
            //         "cummulativeQuoteQty": "0.00000000",
            //         "status": "CANCELED",
            //         "timeInForce": "GTC",
            //         "type": "LIMIT",
            //         "side": "SELL"
            //     },
            //     "newOrderResponse": {
            //         "symbol": "BTCUSDT",
            //         "orderId": 10,
            //         "orderListId": -1,
            //         "clientOrderId": "wOceeeOzNORyLiQfw7jd8S",
            //         "transactTime": 1652928801803,
            //         "price": "0.02000000",
            //         "origQty": "0.040000",
            //         "executedQty": "0.00000000",
            //         "cummulativeQuoteQty": "0.00000000",
            //         "status": "NEW",
            //         "timeInForce": "GTC",
            //         "type": "LIMIT",
            //         "side": "BUY",
            //         "fills": []
            //     }
            // };
            // 选择了STOP_ON_FAILURE, 撤单出现错误
            // result = {
            //     "code": -2022,
            //     "msg": "Order cancel-replace failed.",
            //     "data": {
            //         "cancelResult": "FAILURE",
            //         "newOrderResult": "NOT_ATTEMPTED",
            //         "cancelResponse": {
            //             "code": -2011,
            //             "msg": "Unknown order sent."
            //         },
            //         "newOrderResponse": null
            //     }
            // }
            // cc.log('可出單並產生隨機掛單', symbol, side, '訂單:[', result.orderId, ']:', price);
            if (result.code) {
                return Promise.reject(result);
            }
            // 返回orderId
            return orderTicketData('ORDER', result);
        });
};
// 查看账户当前挂单
const list = function (ownerId, symbol) {
    return api.openOrders(ownerId, symbol)
        .then((result) => {
            // result = [{
            //     clientOrderId: "and_fde7b3b5ae7a4d97960d60d25c8b4d13",
            //     cummulativeQuoteQty: "0.00000000",
            //     // executedQty: "0.00000000",
            //     executedQty: this._fakeOrderNum,
            //     icebergQty: "0.00000000",
            //     isWorking: true,
            //     // orderId: 2874623,
            //     orderId: this._fakeOrderId,
            //     orderListId: -1,
            //     origQty: "4433.00000000",
            //     origQuoteOrderQty: "0.00000000",
            //     // price: "0.04000000",
            //     price: this._fakeOrderPrice,
            //     // side: "SELL",
            //     side: this._fakeOrderSide,
            //     status: "NEW",
            //     stopPrice: "0.00000000",
            //     symbol: "ALPHABUSD",
            //     time: 1603718592389,
            //     timeInForce: "GTC",
            //     type: "LIMIT",
            //     updateTime: 1603718592389,
            // }];
            if (result.code) {
                return Promise.reject(result);
            }
            // 返回orderId array
            return result.map(rawData => orderTicketData('OPEN_ORDERS', rawData));
        });
};
const check = function (ownerId, symbol, orderId) {
    return api.checkOrder(ownerId, symbol, orderId)
        .then((result) => {
            // result = {
            //     clientOrderId: "zO0cx3kPlim838EyUsYEAh",
            //     cummulativeQuoteQty: "62.85000000",
            //     executedQty: this._fakeOrderNum,//"2.00000000",
            //     icebergQty: "0.00000000",
            //     isWorking: true,
            //     orderId: this._fakeOrderId,//143721795,
            //     orderListId: -1,
            //     origQty: "2.00000000",
            //     origQuoteOrderQty: "0.00000000",
            //     price: this._fakeOrderPrice,//"31.42500000",
            //     side: this._fakeOrderSide,//"SELL",
            //     status: "FILLED",
            //     stopPrice: "0.00000000",
            //     symbol: "BNBBUSD",
            //     time: 1606783117178,
            //     timeInForce: "GTC",
            //     type: "LIMIT",
            //     updateTime: 1606783160329,
            // };
            if (result.code) {
                return Promise.reject(result);
            }
            // 返回orderId
            return orderTicketData('CHECK_ORDER', result);
        });
};
const orderTicketData = function (type, rawData) {
    // console.log(type, ':', rawData);
    let orderId = rawData.orderId;
    let orderTicket = {
        orderId: orderId,
        symbol: rawData.symbol,
        clientOrderId: rawData.clientOrderId,
        orderListId: parseInt(rawData.orderListId, 10),
        price: parseFloat(rawData.price),
        side: rawData.side,
        type: rawData.type,
        status: rawData.status,
        timeInForce: rawData.timeInForce,
        cummulativeQuoteQty: parseFloat(rawData.cummulativeQuoteQty),
        executedQty: parseFloat(rawData.executedQty),
        origQty: parseFloat(rawData.origQty),
        // filledQty: 0,// 暫存已填入倉位數量，進 OrderTicketData.set 後會把暫存進度塞在這邊
    };
    switch (type) {
        case 'ORDER':
            orderTicket.transactTime = parseInt(rawData.transactTime, 10);
            break;
        case 'DELETE_ORDER':
            orderTicket.origClientOrderId = rawData.origClientOrderId;
            orderTicket.transactTime = parseInt(rawData.transactTime, 10);
            break;
        case 'OPEN_ORDERS':
        case 'CHECK_ORDER':
            orderTicket.isWorking = rawData.isWorking;
            orderTicket.icebergQty = parseFloat(rawData.icebergQty);
            orderTicket.origQuoteOrderQty = parseFloat(rawData.origQuoteOrderQty);
            orderTicket.stopPrice = parseFloat(rawData.stopPrice);
            orderTicket.updateTime = parseInt(rawData.updateTime, 10);
            orderTicket.time = parseInt(rawData.time, 10);
            break;
        case 'ALL_ORDERS':
            orderTicket.isWorking = rawData.isWorking;
            orderTicket.icebergQty = parseFloat(rawData.icebergQty);
            orderTicket.stopPrice = parseFloat(rawData.stopPrice);
            orderTicket.updateTime = parseInt(rawData.updateTime, 10);
            orderTicket.time = parseInt(rawData.time, 10);
            break;
    };
    // console.log('type:', type, 'orderId:', orderId);
    return orderTicket;
};
/**
 *  
 * 測試時使用
 * 
 */
/**
 * 測試下訂單
 * @param {string} ownerId 
 * @param {string} symbol 
 * @param {string} side 
 * @param {string} type 
 * @param {number} quantity 
 * @param {number} price 
 * @returns 
 */
const testOrder = function (ownerId, symbol, side, quantity, price) {
    const timeInForce = 'GTC', type = 'MARKET';
    // return api.order(ownerId)
    return Promise.resolve()
        .then(() => {
            // 測試用的
            let executedQty = getPrecisionQuanity(symbol, Math.max(0, (Math.random() - 0.2) * 10000 % quantity));
            // 建起來未完成交易是"NEW"
            let status = 'NEW';
            if (executedQty === quantity) status = 'FILLED';
            else if (executedQty > 0) status = 'PARTIALLY_FILLED';
            console.log(side, '==order==', executedQty, '/', quantity, '====', status);
            return orderTicketData('ORDER', {
                "symbol": symbol,
                "orderId": Math.round(Math.random() * 1000000),
                "transactTime": Date.now(),
                "price": price.toString(),
                "origQty": quantity.toString(),
                "executedQty": executedQty.toString(),
                "status": status,
                "timeInForce": timeInForce,
                "cummulativeQuoteQty": "0.0",
                "clientOrderId": "aaabbbcccdddd",
                "orderListId": -1,
                "icebergQty": "0.00000000",
                "type": type,
                "side": side,
            });
        });
};

/**
 * 測試檢查訂單狀態
 * @param {string} symbol 
 * @param {object} orderTicket 
 * @returns 
 */
const testCheck = function (ownerId, symbol, orderTicket) {
    return Promise.resolve()
        .then(() => {
            let { orderId, origQty, price, side, executedQty, type } = orderTicket;
            let quantity = getPrecisionQuanity(symbol, origQty);
            // 測試用的，隨機的數字如果太小就不動
            // let filledQty = executedQty + Math.random() * 10000 % quantity;
            let filledQty = quantity;
            console.log('filledQty:', filledQty);
            executedQty = Math.min(filledQty, quantity);
            executedQty = getPrecisionQuanity(symbol, executedQty);
            // 建起來未完成交易是"NEW"
            let status = 'NEW';
            if (executedQty === quantity) status = 'FILLED';
            else if (executedQty > 0) status = 'PARTIALLY_FILLED';
            console.log(side, '==check==', executedQty, '/', quantity, '====', status);
            // 返回orderId
            return orderTicketData('CHECK_ORDER', {
                cummulativeQuoteQty: "0.00000000",
                executedQty: executedQty,
                isWorking: true,
                orderId: orderId,
                orderListId: -1,
                origQty: origQty,
                origQuoteOrderQty: "0.00000000",
                price: price,
                side: side,
                status: status,
                stopPrice: "0.00000000",
                symbol: symbol,
                time: 1606783117178,
                timeInForce: "GTC",
                icebergQty: "0.00000000",
                clientOrderId: "abcdefg",
                type: type,
                updateTime: Date.now(),
            });
        });
};
/**
 * 測試撤單
 * @param {string} ownerId 
 * @param {string} symbol 
 * @param {object} orderTicket 
 * @returns 
 */
const testCancel = function (ownerId, symbol, orderTicket) {
    // return api.testOrder(ownerId)
    return Promise.resolve()
        .then(() => {
            let { orderId, origQty, price, side, executedQty } = orderTicket;
            let quantity = getPrecisionQuanity(symbol, origQty);
            // 測試用的，隨機讓它跑 已/未 買/賣 的情況
            executedQty += getPrecisionQuanity(symbol, Math.min(origQty, Math.max(0, (Math.random() - 0.9) * 10000 % quantity)));
            // {//實際撤掉的一單
            //     symbol: 'EPSBUSD',
            //     origClientOrderId: 'and_aad7afe60ccc4f2db52e3f1ce8d57847',
            //     orderId: 55076687,
            //     orderListId: -1,
            //     clientOrderId: 'Yy9tDSYugx7KjPaQ3QQiLQ',
            //     price: '0.21860000',
            //     origQty: '56931.00000000',
            //     executedQty: '0.00000000',
            //     cummulativeQuoteQty: '0.00000000',
            //     status: 'CANCELED',
            //     timeInForce: 'GTC',
            //     type: 'LIMIT',
            //     side: 'BUY'
            //   }
            // {//實際撤掉掛了一半有執行的一單
            //     symbol: 'EPSBUSD',
            //     origClientOrderId: 'and_4f5c0af34d4e49e5991e2a054ef882f4',
            //     orderId: 54987781,
            //     orderListId: -1,
            //     clientOrderId: 'q04g4xn5mxr48uwTUTgbp4',
            //     price: '0.23200000',
            //     origQty: '98067.00000000',
            //     executedQty: '1854.00000000',
            //     cummulativeQuoteQty: '430.12800000',
            //     status: 'CANCELED',
            //     timeInForce: 'GTC',
            //     type: 'LIMIT',
            //     side: 'SELL'
            //   }
            return orderTicketData('DELETE_ORDER', {
                executedQty: executedQty.toString(),
                orderId: orderId,
                orderListId: -1,
                origQty: origQty.toString(),
                price: price.toString(),
                side: side,
                status: "CANCELED",
                symbol: symbol,
                timeInForce: "GTC",
                type: "LIMIT",
                cummulativeQuoteQty: "0.0",
                clientOrderId: "abcdefg",
                origClientOrderId: 'and_aad7afe60ccc4f2db52e3f1ce8d57847',
                transactTime: Date.now(),//TODO:這個好像沒複製到，有空測試時可以確認一下
            });//TODO: 如果這單已經被刪過再重複傳就會回傳error400，看怎麼處理盡量不要發生這種情況);
        });
};
module.exports = {
    tickerPrice,
    order,
    cancel,
    replace,
    check,
    list,           // 查看帳戶訂單
    /** 測試專用 */
    testOrder,      // 測試下單
    testCheck,      // 測試更新訂單
    testCancel,     // 測試撤單
};