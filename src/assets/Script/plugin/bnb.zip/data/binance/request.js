const qs = require('qs'),
    crypto = require('crypto'),
    LocalStorage = require('node-localstorage').LocalStorage,
    localStorage = new LocalStorage('./scratch');
const BASE_ENDPOINT = 'https://api.binance.com';
// 鑑權  
const SecurityType = {
    NONE: 0,                   // 不需要鉴权的接口  
    TRADE: 1,                  // 需要有效的API-KEY和签名  
    USER_DATA: 2,              // 需要有效的API-KEY和签名  
    USER_STREAM: 3,            // 需要有效的API-KEY  
    MARKET_DATA: 4,            // 需要有效的API-KEY  
};
// 時間間距  
const Interval = {
    MINUTES_01: '1m',
    MINUTES_03: '3m',
    MINUTES_05: '5m',
    MINUTES_15: '15m',
    MINUTES_30: '30m',
    HOURS_01: '1h',
    HOURS_02: '2h',
    HOURS_04: '4h',
    HOURS_06: '6h',
    HOURS_08: '8h',
    HOURS_12: '12h',
    DAYS_1: '1d',
    DAYS_3: '3d',
    WEEK_1: '1w',
    MONTH_1: '1M',
};
const DelayMins = {
    [Interval.MINUTES_01]: 1,
    [Interval.MINUTES_03]: 3,
    [Interval.MINUTES_05]: 5,
    [Interval.MINUTES_15]: 15,
    [Interval.MINUTES_30]: 30,
    [Interval.HOURS_01]: 60,
    [Interval.HOURS_02]: 2 * 60,
    [Interval.HOURS_04]: 4 * 60,
    [Interval.HOURS_06]: 6 * 60,
    [Interval.HOURS_08]: 8 * 60,
    [Interval.HOURS_12]: 12 * 60,
    [Interval.DAYS_1]: 24 * 60,
    [Interval.DAYS_3]: 3 * 24 * 60,
    [Interval.WEEK_1]: 7 * 24 * 60,
};
const EndPoints = {
    /**  
     * 通用接口  
     */
    // 测试服务器连通性 PING  
    PING: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v1/ping',
    },
    // 获取服务器时间  
    TIME: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v1/time',
    },
    // 交易规范信息  
    EXCHANGE_INFO: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v1/exchangeInfo',
    },
    // 账户接口  
    // 下單  
    ORDER: {
        security: SecurityType.TRADE,
        method: 'POST',
        path: '/api/v3/order',
    },
    // 测试下单接口: 用于测试订单请求，但不会提交到撮合引擎  
    TEST_ORDER: {
        security: SecurityType.TRADE,
        method: 'POST',
        path: '/api/v3/order/test',
    },
    // 查询订单: 至少需要发送 orderId 与 origClientOrderId中的一个  
    CHECK_ORDER: {
        security: SecurityType.USER_DATA,
        method: 'GET',
        path: '/api/v3/order',
    },
    // 撤销订单  
    DELETE_ORDER: {
        security: SecurityType.TRADE,
        method: 'DELETE',
        path: '/api/v3/order',
    },
    // 撤消挂单再下单 
    CANCEL_REPLACE_ORDER: {
        security: SecurityType.TRADE,
        method: 'POST',
        path: '/api/v3/order/cancelReplace',
    },
    // 查看账户当前挂单  
    OPEN_ORDERS: {
        security: SecurityType.USER_DATA,
        method: 'GET',
        path: '/api/v3/openOrders',
    },
    // 查询所有订单（包括历史订单）  
    ALL_ORDERS: {
        security: SecurityType.USER_DATA,
        method: 'GET',
        path: '/api/v3/allOrders',
    },
    // 账户信息  
    ACCOUNT: {
        security: SecurityType.USER_DATA,
        method: 'GET',
        path: '/api/v3/account',
    },
    // 账户成交历史  
    MY_TRADES: {
        security: SecurityType.USER_DATA,
        method: 'GET',
        path: '/api/v3/myTrades',
    },
    /**  
     * 行情接口  
     */
    // 深度信息  
    DEPTH: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v1/depth',
    },
    // 近期成交  
    TRADES: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v1/trades',
    },
    // 查询历史成交  
    HISTORICAL_TRADES: {
        security: SecurityType.MARKET_DATA,
        method: 'GET',
        path: '/api/v1/historicalTrades',
    },
    // 近期成交(归集)：与trades的区别是，同一个taker在同一时间同一价格与多个maker的成交会被合并为一条记录  
    AGG_TRADES: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v1/aggTrades',
    },
    // 交易规范信息  
    KLINE: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v1/klines',
    },
    // 当前平均价格  
    AVERAGE_PRICE: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v3/avgPrice',
    },
    // 24hr价格变动情况  
    TICKER_24HR: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v1/ticker/24hr',
    },
    // 最新价格接口  
    TICKER_PRICE: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v3/ticker/price',
    },
    // 最优挂单接口  
    TICKER_BOOK_TICKER: {
        security: SecurityType.NONE,
        method: 'GET',
        path: '/api/v3/ticker/bookTicker',
    },
};
// 是否凍結：請求資料時被回應違法，先做凍結避免被鎖apikey  
var _isFreeze = false;
var apiSkeys;
// api 請求  
var sendRequest = (ownerId, endpoint, params = {}) => {
    // 找個對的地方setItem，格式是 {[oid]:{"apiKey":"XXX","secretKey":"YYYY"}} 
    apiSkeys = apiSkeys || JSON.parse(localStorage.getItem('secret_api_keys'));
    // console.log('apiSkeys[', ownerId, ']:' + apiSkeys[ownerId]); 
    if (!apiSkeys[ownerId])
        return Promise.reject('無' + ownerId + '的暫存api Key 資料, 必須先填入後才能請求交易所');
    if (_isFreeze)
        return Promise.reject('API 安全凍結');
    var query = qs.stringify(params);
    var config = {
        url: BASE_ENDPOINT + endpoint.path,
        method: endpoint.method,
        headers: {
            'Target-URL': BASE_ENDPOINT + endpoint.path + '?' + query,
        },
        params: params
    };
    // 不同的鑑權需要多帶參數  
    switch (endpoint.security) {
        case SecurityType.TRADE:                  // 需要有效的API-KEY和签名  
        case SecurityType.USER_DATA:              // 需要有效的API-KEY和签名  
            let { secretKey } = apiSkeys[ownerId];
            let signature = crypto.createHmac('sha256', secretKey).update(query).digest('hex');
            config.headers['Target-URL'] += '&signature=' + signature;
            config.params['signature'] = signature;
        case SecurityType.USER_STREAM:            // 需要有效的API-KEY  
        case SecurityType.MARKET_DATA:            // 需要有效的API-KEY  
            let { apiKey } = apiSkeys[ownerId];
            config.headers['X-MBX-APIKEY'] = apiKey;
            break;
        default:
            break;
    }
    return require('axios')(config)
        .then((raw) => {
            // console.log('raw:', raw); 
            let status = raw.status;
            // if (raw.request.readyState == 4) { 
            if (status >= 200 && status < 400) {
                return raw.data;
            }
        })
        .catch((error) => {
            // console.log('error:', error);
            if (!error.response) {
                let { status, code, config } = error;
                console.log('Error!!', code, 'errno:', error.errno);
                return { status, code, config };
            }
            // check this 
            // https://github.com/binance/binance-spot-api-docs/blob/master/errors.md 
            // let msg = '未預期的錯誤'; 
            let { config, status, data } = error.response;
            let { code, msg } = data;
            // 4XX: 错误码用于指示错误的请求内容、行为、格式。  
            // console.log("error", error); 
            if (status == 400) {
                // {"code":-1111,"msg":"Precision is over the maximum defined for this asset."}//應該是要重跑一下過濾器，送出去的值比過濾限制的還小(小數點精度過高)  
                // {"code":-1021,"msg":"Timestamp for this request is outside of the recvWindow."}//回應超過時間  
                // {"code":-2010,"msg":"Account has insufficient balance for requested action." }//交易餘額不足  
                // {"code":-2013,"msg":"Order does not exist."}//找不到這單，可能清掉還怎樣，看能不能用歷史掛單去找出來結算掉  
                // msg = `${code} ${msg}`; 
                // console.log('xxx:', config.url, config.method, status, statusText, data); 
            }
            // 4XX: 错误码用于指示错误的请求内容、行为、格式。  
            else if (status == 401) {
                msg = '401 時間戳過期';
                // Request failed with status code 400  
                // todo use code 
                if (code === -2014)
                    msg = '未經授權';
            }
            else if (status == 429) {
                msg = '429 错误码表示警告访问频次超限,即将被封IP';
                // TODO: 先做一個彈出警告並凍結所有送出請求的動作  
                _isFreeze = true;
            }
            else if (status == 418) {
                msg = '418 表示收到429后继续访问,于是被封了';
                // TODO: 看是不是送個信之類的，無論如何都無法繼續了  
                _isFreeze = true;
            }
            // 5XX: 错误码用于指示Binance服务侧的问题。  
            else if (status == 504) {
                msg = '504 表示API服务端已经向业务核心提交了请求但未能获取响应,特别需要注意的是504代码不代表请求失败,而是未知。';
                // 很可能已经得到了执行，也有可能执行失败，需要做进一步确认。  
                // 每个接口都有可能抛出异常，异常响应格式如下：  
                // {  
                //     "status": -1121,  
                //     "msg": "Invalid symbol."  
                // }  
                code = raw.data.code;
                msg += '\n(code:' + code + ' ' + raw.data.msg + ')';
            }
            else console.log(error.response);
            // } 
            // return Promise.reject(msg);  
            return { status, code, msg, config };
        });
};
module.exports = {
    SecurityType: SecurityType, // 鑑權  
    Interval: Interval,         // 時間間距：limit
    DelayMins: DelayMins,       // 對應時間間距，換算出來的延遲時間(分鐘)
    EndPoints: EndPoints,       // API接口資訊 
    send: sendRequest,          // 送出請求  
};