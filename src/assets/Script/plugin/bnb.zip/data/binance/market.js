const api = require('./api');
const LocalStorage = require('node-localstorage').LocalStorage,
    localStorage = new LocalStorage('./scratch');
const { Interval } = require('./request');
const KLINE = {
    Opening: 1,     // 開盤價 
    Highest: 2,     // 最高價 
    Lowest: 3,      // 最低價 
    Closing: 4,     // 收盤價 
    Valume: 5,      // 成交額 
    // todo 其他參數可以再補入，這邊單純是Array 的順序 
};
// const { getDecimalStorage } = require('./exchangeInfo'); 
const kline = function (ownerId, symbol, lastUpdateTime, currTime, interval, limit, onlyResult = false) {
    // 如果不想一直做本機讀取，外面就要用 if (currTime - lastUpdateTime < 60 * 1000) 來擋時間 
    var klines = {};//JSON.parse(localStorage.getItem('bnb_kline') || '{}');
    var klineData = [];
    if (klines[symbol] && klines[symbol].interval === interval) {
        klineData = klines[symbol].kline || [];
        // // 如果沒有另外帶最後更新時間的話
        // if (!lastUpdateTime) {
        //     lastUpdateTime = klines[symbol].lastUpdateTime;
        //     currTime = Date.now();
        //     console.log('lastUpdateTime:', lastUpdateTime, klines[symbol].lastUpdateTime, 'currTime:', currTime);
        // }
        // else if (klines[symbol].lastUpdateTime > lastUpdateTime) {
        //     // 暫存的內容比較新
        //     lastUpdateTime = klines[symbol].lastUpdateTime;
        // }
        // todo 反正都只花1權重，看要不要乾脆不存…
    }
    return (lastUpdateTime
        ? api.kline(ownerId, symbol, interval, limit, lastUpdateTime, currTime)
        : api.kline(ownerId, symbol, interval, limit)
    ).then((result) => {
        // result = [[ 
        //     1499040000000,      // 0开盘时间 
        //     "0.01634790",       // 1开盘价 
        //     "0.80000000",       // 2最高价 
        //     "0.01575800",       // 3最低价 
        //     "0.01577100",       // 4收盘价(当前K线未结束的即为最新价) 
        //     "148976.11427815",  // 5成交量 
        //     1499644799999,      // 6收盘时间 
        //     "2434.19055334",    // 7成交额 
        //     308,                // 8成交笔数 
        //     "1756.87402397",    // 9主动买入成交量 
        //     "28.46694368",      // 10主动买入成交额 
        //     "17928899.62484339" // 请忽略该参数 
        // ]]; 
        // console.log(klineData.map(x=>x[KLINE.Closing]), ' concat ', result.map(x=>x[KLINE.Closing])); 
        // console.log('----', result.map(x=>new Date(x[6]).getMinutes()+':'+new Date(x[6]).getSeconds())); 
        //  
        let rawData = result.map((raw) => raw.map((d) => parseFloat(d)));
        klineData = klineData.splice(result.length).concat(rawData);
        klines[symbol] = {
            kline: klineData,
            lastUpdateTime: currTime,
            interval,
        };
        // 暫存 
        // localStorage.setItem('bnb_kline', JSON.stringify(klines));
        if (onlyResult)
            return rawData;
        return klineData;
    });
};
const depth = function (ownerId, symbol, limit) {
    return api.depth(ownerId, symbol, limit)
        .then((result) => {
            // result = { 
            //     "lastUpdateId": 1027024, 
            //     "bids": [ 
            //         [ 
            //             "4.00000000",     // 价位 
            //             "431.00000000",   // 挂单量 
            //             []                // 请忽略. 
            //         ] 
            //     ], 
            //     "asks": [ 
            //         [ 
            //             "4.00000200", 
            //             "12.00000000", 
            //             [] 
            //         ] 
            //     ] 
            // }; 
            // 價格計算 
            const bidVolumes = result.bids.map((x) => x[1] / this.quoteVolume);
            const askVolumes = result.asks.map((x) => x[1] / this.quoteVolume);
            console.log('bidVolume:', bidVolumes, 'askVolume:', askVolumes);
            let sumVolume = 0;
            for (let i = 0; i < limit; i++) {
                sumVolume += bidVolumes[i] - askVolumes[i];
                console.log(i, 'depth:', bidVolumes[i] - askVolumes[i]);
                console.log(result.bids[i][0], '~', result.asks[i][0], 'sum depth:', sumVolume);
                // todo 整理一個需要的資料 
            }
        });
};
const ticker24hr = function (ownerId, symbol) {
    return api.ticker24hr(ownerId, symbol, 'MINI')
        .then((result) => {
            // // MINI 
            // result = { 
            //     "symbol": "BNBBTC",          // 交易对 
            //     "openPrice": "99.00000000",     // 间隔开盘价 
            //     "highPrice": "100.00000000",    // 间隔最高价 
            //     "lowPrice": "0.10000000",      // 间隔最低价 
            //     "lastPrice": "4.00000200",      // 间隔收盘价 
            //     "volume": "8913.30000000",   // 总交易量 (base asset) 
            //     "quoteVolume": "15.30000000",     // 总交易量 (quote asset) 
            //     "openTime": 1499783499040,     // ticker间隔的开始时间 
            //     "closeTime": 1499869899040,     // ticker间隔的结束时间 
            //     "firstId": 28385,             // 统计时间内的第一笔trade id 
            //     "lastId": 28460,             // 统计时间内的最后一笔trade id 
            //     "count": 76                 // 统计时间内交易笔数 
            // }; 
            return result;
        });
};
module.exports = {
    kline,
    KLINE,
    depth,
    ticker24hr,
};