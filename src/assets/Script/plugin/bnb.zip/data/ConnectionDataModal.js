const YellowCardData = require("../trade/YellowCardData");
const data = {};

addNewRoom = function () {
    const connectionData = new YellowCardData();
    return data[connectionData.rNum] = connectionData;
};

delEmptyRoom = function (rNum) {
    // todo 雖然叫空房間但目前還沒處理空房時才刪除的檢查
    delete data[rNum];
}

getRoomInfo = function (rNum) {
    console.log('getRoomInfo:', rNum, data);
    return data[rNum];
};

module.exports = {
    addNewRoom,
    delEmptyRoom,
    getRoomInfo,
}